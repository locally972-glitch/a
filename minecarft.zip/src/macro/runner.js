'use strict';
/* Macro runner (engine + walk + bot helpers). One macro at a time;
   progress streams through the 'status' event. */
const { EventEmitter } = require('events');
const MAX_STEPS = 20000;
const GOTO_TIMEOUT_MS = 70000;
const GOTO_ARRIVE_DIST = 2;
const clampNum = (v, lo, hi, fb) => {
  const n = Number(v);
  if (!Number.isFinite(n)) return fb;
  return Math.max(lo, Math.min(hi, n));
};
const clampInt = (v, lo, hi, fb) => Math.round(clampNum(v, lo, hi, fb));
const cleanStr = (v, max = 64) => String(v === undefined || v === null ? '' : v).trim().slice(0, max);
function createRunner({ getBotManager }) {
  const emitter = new EventEmitter();
  let current = null;
  const emit = (s) => { try { emitter.emit('status', s); } catch (_) {} };
  function status() {
    if (!current) return { running: false };
    return { running: true, runId: current.runId, macroId: current.macroId, macroName: current.macroName, nodeId: current.nodeId };
  }
  function compile(graph) {
    const g = graph && typeof graph === 'object' ? graph : {};
    const nodeMap = new Map();
    for (const n of g.nodes || []) {
      if (n && n.id && n.type) nodeMap.set(String(n.id), n);
    }
    const starts = [...nodeMap.values()].filter((n) => n.type === 'start');
    if (!starts.length) return { ok: false, error: 'Add a Start node first.' };
    const out = new Map();
    for (const e of g.edges || []) {
      if (!e || !nodeMap.has(String(e.from)) || !nodeMap.has(String(e.to))) continue;
      const from = String(e.from);
      const port = String(e.out || 'flow');
      if (!out.has(from)) out.set(from, {});
      const ports = out.get(from);
      (ports[port] = ports[port] || []).push(String(e.to));
    }
    return { ok: true, nodeMap, out, startId: starts[0].id };
  }
  function run(macro) {
    if (current) return { ok: false, error: 'A macro is already running - stop it first.' };
    if (!macro || !macro.graph) return { ok: false, error: 'Macro not found.' };
    const t = compile(macro.graph);
    if (!t.ok) return t;
    const bm = typeof getBotManager === 'function' ? getBotManager() : null;
    if (!bm || bm.state !== 'connected' || !bm.bot) {
      return { ok: false, error: 'The bot is not in a server - start it first.' };
    }
    const runId = 'run_' + Date.now().toString(36);
    const ctx = { runId, macroId: macro.id, macroName: macro.name || 'Macro',
      cancel: false, steps: 0, repeat: {}, nodeId: null, timers: new Set(), chatWaiters: new Set() };
    current = ctx;
    emit({ runId, macroId: ctx.macroId, macroName: ctx.macroName, state: 'started', nodeId: null, label: ctx.macroName, message: 'Started ' + ctx.macroName });
    execute(ctx, t).catch((err) => {
      emit({ runId, macroId: ctx.macroId, macroName: ctx.macroName, state: 'error', nodeId: ctx.nodeId, message: (err && err.message) || String(err) });
    }).finally(() => { if (current === ctx) current = null; });
    return { ok: true, runId };
  }
  function stop() {
    if (!current) return { ok: false, error: 'No macro is running.' };
    current.cancel = true;
    for (const t of current.timers) clearTimeout(t);
    current.timers.clear();
    for (const w of current.chatWaiters) { try { w(); } catch (_) {} }
    current.chatWaiters.clear();
    try { haltBot(); } catch (_) {}
    return { ok: true, runId: current.runId };
  }
  async function execute(ctx, t) {
    let nodeId = t.startId;
    while (nodeId && !ctx.cancel) {
      if (++ctx.steps > MAX_STEPS) {
        emit({ runId: ctx.runId, macroId: ctx.macroId, macroName: ctx.macroName, state: 'error', nodeId, message: 'Step budget exceeded - a Repeat loop never ends.' });
        return;
      }
      const node = t.nodeMap.get(nodeId);
      if (!node) break;
      ctx.nodeId = nodeId;
      const label = nodeLabel(node);
      emit({ runId: ctx.runId, macroId: ctx.macroId, macroName: ctx.macroName, state: 'node', nodeId, label, message: label });
      let res;
      try { res = await execNode(ctx, node); }
      catch (err) {
        emit({ runId: ctx.runId, macroId: ctx.macroId, macroName: ctx.macroName, state: 'error', nodeId, label, message: (err && err.message) || String(err) });
        return;
      }
      if (ctx.cancel) break;
      if (!res || res.end) break;
      if (res.note) {
        emit({ runId: ctx.runId, macroId: ctx.macroId, macroName: ctx.macroName, state: 'note', nodeId, label, message: res.note });
      }
      const ports = t.out.get(nodeId) || {};
      const next = ports[res.port] || ports.flow || null;
      nodeId = next && next.length ? next[0] : null;
    }
    if (ctx.cancel) {
      emit({ runId: ctx.runId, macroId: ctx.macroId, macroName: ctx.macroName, state: 'stopped', nodeId: ctx.nodeId, message: 'Stopped.' });
    } else {
      emit({ runId: ctx.runId, macroId: ctx.macroId, macroName: ctx.macroName, state: 'done', nodeId: null, message: ctx.macroName + ' finished.' });
    }
  }
  function nodeLabel(node) {
    const p = (node && node.params) || {};
    switch (node.type) {
      case 'goto': return 'Go to ' + (p.x || 0) + ', ' + (p.z || 0);
      case 'say': return 'Say ' + cleanStr(p.message, 40);
      case 'wait': return 'Wait ' + (p.seconds || 1) + 's';
      case 'mineone': return 'Mine ' + (p.block || '?');
      case 'attack': return 'Attack ' + (p.target || 'nearest') + ' x' + (p.times || 1);
      case 'follow': return 'Follow ' + (p.player || '?');
      case 'guard': return 'Guard ' + (p.player || '?');
      case 'drop': return 'Drop ' + (p.name || '?');
      case 'equip': return 'Equip ' + (p.name || '?');
      case 'look': return 'Look ' + (p.x || 0) + ' ' + (p.y || 0) + ' ' + (p.z || 0);
      case 'repeat': return 'Repeat x' + (p.times || 1);
      case 'onchat': return 'On chat ' + cleanStr(p.contains, 30);
      case 'movekeys': return 'Hold keys';
      case 'note': return cleanStr(p.text, 50) || 'Note';
      default: return String(node.type || 'node');
    }
  }
  function bm() { return typeof getBotManager === 'function' ? getBotManager() : null; }
  function liveBot() {
    const m = bm();
    return m && m.state === 'connected' && m.bot ? m : null;
  }
  function stopBehaviours(m) {
    try { if (typeof m.setFollow === 'function') m.setFollow({ enabled: false }); } catch (_) {}
    try { if (typeof m.setGuard === 'function') m.setGuard({ enabled: false }); } catch (_) {}
    try { if (typeof m.setMining === 'function') m.setMining({ enabled: false }); } catch (_) {}
    try { if (typeof m.setFarm === 'function') m.setFarm(false); } catch (_) {}
  }
  function releaseKeys(m) {
    try { if (typeof m.setDrive === 'function') m.setDrive({ forward: false, back: false, left: false, right: false, jump: false, sneak: false }); } catch (_) {}
    try { if (typeof m.stopGoto === 'function') m.stopGoto(); } catch (_) {}
    try { if (typeof m.stopDrive === 'function') m.stopDrive(); } catch (_) {}
    try { if (m.bot && typeof m.bot.clearControlStates === 'function') m.bot.clearControlStates(); } catch (_) {}
  }
  function haltBot() {
    const m = bm();
    if (!m) return;
    stopBehaviours(m);
    releaseKeys(m);
  }
  function sleep(ctx, ms) {
    return new Promise((resolve) => {
      if (ctx.cancel) return resolve(false);
      const t = setTimeout(() => { ctx.timers.delete(t); resolve(true); }, Math.max(0, ms));
      ctx.timers.add(t);
    });
  }
  async function execNode(ctx, node) {
    const p = (node && node.params) || {};
    switch (node.type) {
      case 'start':
      case 'note':
        return { port: 'flow' };
      case 'stop':
        return { end: true };
      case 'wait': {
        await sleep(ctx, clampNum(p.seconds, 0.1, 3600, 1) * 1000);
        return { port: 'flow' };
      }
      case 'repeat': {
        const times = clampInt(p.times, 1, 1000, 2);
        ctx.repeat[node.id] = (ctx.repeat[node.id] || 0) + 1;
        if (ctx.repeat[node.id] > times) {
          delete ctx.repeat[node.id];
          return { port: 'done' };
        }
        return { port: 'loop' };
      }
      case 'goto': {
        const m = liveBot();
        if (!m) throw new Error('Bot left the server.');
        const x = Number(p.x);
        const z = Number(p.z);
        if (!Number.isFinite(x) || !Number.isFinite(z)) throw new Error('Go to X Z needs numbers.');
        stopBehaviours(m);
        const r = m.driveTo(x, z, { jump: !!p.jump, sneak: !!p.sneak });
        if (!r || !r.ok) return { port: 'stuck', note: (r && r.error) || 'Could not start walking.' };
        const t0 = Date.now();
        for (;;) {
          if (ctx.cancel) { releaseKeys(m); return { end: true }; }
          const pos = m.bot && m.bot.entity && m.bot.entity.position;
          if (!pos) { releaseKeys(m); return { port: 'stuck', note: 'Lost the bot position.' }; }
          const dx = pos.x - x;
          const dz = pos.z - z;
          if (dx * dx + dz * dz <= GOTO_ARRIVE_DIST * GOTO_ARRIVE_DIST) break;
          if (Date.now() - t0 > GOTO_TIMEOUT_MS) { releaseKeys(m); return { port: 'stuck', note: 'Could not reach the spot (stuck?).' }; }
          await sleep(ctx, 400);
        }
        releaseKeys(m);
        return { port: 'flow' };
      }
      case 'movekeys': {
        const m = liveBot();
        if (!m) throw new Error('Bot left the server.');
        stopBehaviours(m);
        const keys = { forward: !!p.forward, back: !!p.back, left: !!p.left, right: !!p.right, jump: !!p.jump, sneak: !!p.sneak };
        if (p.sprint && m.bot) { try { m.bot.setControlState('sprint', true); } catch (_) {} }
        let note = null;
        const r = typeof m.setDrive === 'function' ? m.setDrive(keys) : null;
        if (!r || !r.ok) note = (r && r.error) || 'Keys refused (another behaviour is driving).';
        await sleep(ctx, clampNum(p.seconds, 0.2, 120, 2) * 1000);
        if (m.bot) { try { m.bot.setControlState('sprint', false); } catch (_) {} }
        releaseKeys(m);
        return { port: 'flow', note };
      }
      case 'follow': {
        const m = liveBot();
        if (!m) throw new Error('Bot left the server.');
        const player = cleanStr(p.player, 32);
        if (!player) throw new Error('Follow needs a player name.');
        stopBehaviours(m);
        m.setFollow({ enabled: true, player, mode: p.mode === 'op' ? 'op' : 'survival', radius: clampInt(p.radius, 1, 128, 5) });
        return { port: 'flow' };
      }
      case 'unfollow': {
        const m = bm();
        if (m && typeof m.setFollow === 'function') m.setFollow({ enabled: false });
        return { port: 'flow' };
      }
      case 'guard': {
        const m = liveBot();
        if (!m) throw new Error('Bot left the server.');
        const player = cleanStr(p.player, 32);
        if (!player) throw new Error('Guard needs a player name.');
        stopBehaviours(m);
        m.setGuard({ enabled: true, player, mode: p.mode === 'op' ? 'op' : 'survival',
          radius: clampInt(p.radius, 1, 128, 5), attackRange: clampInt(p.range, 2, 16, 8) });
        return { port: 'flow' };
      }
      case 'unguard': {
        const m = bm();
        if (m && typeof m.setGuard === 'function') m.setGuard({ enabled: false });
        return { port: 'flow' };
      }
      case 'stopmove': {
        const m = bm();
        if (m) { stopBehaviours(m); releaseKeys(m); }
        return { port: 'flow' };
      }
      case 'look': {
        const m = liveBot();
        if (!m) throw new Error('Bot left the server.');
        const x = Number(p.x);
        const y = Number(p.y);
        const z = Number(p.z);
        if (!Number.isFinite(x) || !Number.isFinite(y) || !Number.isFinite(z)) throw new Error('Look needs X Y Z numbers.');
        try {
          const Vec3 = require('vec3');
          await m.bot.lookAt(new Vec3(x, y, z), true);
        } catch (err) { throw new Error('Look failed: ' + ((err && err.message) || err)); }
        return { port: 'flow' };
      }
      case 'jump': {
        const m = liveBot();
        if (!m) throw new Error('Bot left the server.');
        const times = clampInt(p.times, 1, 20, 1);
        for (let i = 0; i < times; i++) {
          if (ctx.cancel) return { end: true };
          try { m.bot.setControlState('jump', true); } catch (_) {}
          await sleep(ctx, 350);
          try { m.bot.setControlState('jump', false); } catch (_) {}
          await sleep(ctx, 250);
        }
        return { port: 'flow' };
      }
      case 'attack': {
        const m = liveBot();
        if (!m) throw new Error('Bot left the server.');
        const target = cleanStr(p.target, 32);
        const times = clampInt(p.times, 1, 50, 1);
        let okCount = 0;
        for (let i = 0; i < times; i++) {
          if (ctx.cancel) return { end: true };
          try {
            const r = await m.attackEntity(target || undefined);
            if (r && r.ok) okCount++;
          } catch (_) {}
          if (i + 1 < times) await sleep(ctx, 600);
        }
        if (!okCount) return { port: 'failed', note: 'Nothing to attack nearby.' };
        return { port: 'flow' };
      }
      case 'equip': {
        const m = liveBot();
        if (!m) throw new Error('Bot left the server.');
        const name = cleanStr(p.name, 64).replace(/^minecraft:/, '');
        if (!name) throw new Error('Equip needs an item name.');
        try {
          const item = (m.bot.inventory.items() || []).find((i) => i && i.name === name);
          if (!item) return { port: 'failed', note: 'No ' + name + ' in the inventory.' };
          await m.bot.equip(item, 'hand');
        } catch (err) { return { port: 'failed', note: 'Equip failed: ' + ((err && err.message) || err) }; }
        return { port: 'flow' };
      }
      case 'mineone': {
        const m = liveBot();
        if (!m) throw new Error('Bot left the server.');
        const block = cleanStr(p.block, 64);
        if (!block) throw new Error('Mine needs a block name.');
        const r = await m.mineBlock(block);
        if (!r || !r.ok) return { port: 'failed', note: (r && r.error) || 'Could not mine it.' };
        return { port: 'flow' };
      }
      case 'minestart': {
        const m = liveBot();
        if (!m) throw new Error('Bot left the server.');
        stopBehaviours(m);
        m.setMining({ enabled: true, mode: p.mode === 'stair' ? 'stair' : 'straight' });
        return { port: 'flow' };
      }
      case 'minestop': {
        const m = bm();
        if (m && typeof m.setMining === 'function') m.setMining({ enabled: false });
        return { port: 'flow' };
      }
      case 'eat': {
        const m = liveBot();
        if (!m) throw new Error('Bot left the server.');
        const r = await m.eat();
        if (!r || !r.ok) return { port: 'failed', note: (r && r.error) || 'Nothing to eat.' };
        return { port: 'flow' };
      }
      case 'drop': {
        const m = liveBot();
        if (!m) throw new Error('Bot left the server.');
        const name = cleanStr(p.name, 64);
        if (!name) throw new Error('Drop needs an item name.');
        const r = await m.dropItem(name, clampInt(p.count, 1, 2304, 64));
        if (!r || !r.ok) return { port: 'failed', note: (r && r.error) || 'Could not drop it.' };
        return { port: 'flow' };
      }
      case 'dropall': {
        const m = liveBot();
        if (!m) throw new Error('Bot left the server.');
        const r = await m.dropAll();
        if (!r || !r.ok) return { port: 'failed', note: (r && r.error) || 'Could not drop.' };
        return { port: 'flow' };
      }
      case 'say': {
        const m = liveBot();
        if (!m) throw new Error('Bot left the server.');
        const msg = cleanStr(p.message, 256);
        if (!msg) throw new Error('Say needs a message.');
        if (!m.sendChat(msg)) return { port: 'failed', note: 'Chat failed.' };
        return { port: 'flow' };
      }
      case 'sleep': {
        const m = liveBot();
        if (!m) throw new Error('Bot left the server.');
        const r = await m.sleep();
        if (!r || !r.ok) return { port: 'failed', note: (r && r.error) || 'Could not sleep.' };
        return { port: 'flow' };
      }
      case 'wake': {
        const m = liveBot();
        if (!m) throw new Error('Bot left the server.');
        try { await m.wake(); } catch (_) {}
        return { port: 'flow' };
      }
      case 'onchat': {
        const m = liveBot();
        if (!m) throw new Error('Bot left the server.');
        const needle = cleanStr(p.contains, 64).toLowerCase();
        if (!needle) throw new Error('On Chat needs a keyword.');
        const heard = await new Promise((resolve) => {
          let done = false;
          const finish = (v) => {
            if (done) return;
            done = true;
            ctx.chatWaiters.delete(finish);
            try { m.removeListener('game-chat', onChat); } catch (_) {}
            clearTimeout(timer);
            resolve(v);
          };
          const onChat = ({ message }) => {
            if (String(message || '').toLowerCase().includes(needle)) finish(true);
          };
          const timer = setTimeout(() => finish(false), clampNum(p.timeout, 1, 600, 30) * 1000);
          ctx.chatWaiters.add(() => finish(false));
          m.on('game-chat', onChat);
        });
        if (ctx.cancel) return { end: true };
        return heard ? { port: 'heard' } : { port: 'timeout', note: 'Keyword never heard.' };
      }
      default:
        return { port: 'flow' };
    }
  }
  return { run, stop, status, on: (ev, cb) => emitter.on(ev, cb) };
}
module.exports = { createRunner };
