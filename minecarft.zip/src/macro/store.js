'use strict';

/* ============================================================
   Macro — visual-script storage (macros.json)
   ------------------------------------------------------------
   A macro is a node graph drawn on the Macro page:
     { id, name, runOnConnect, updatedAt,
       graph: { nodes: [{ id, type, x, y, params }],
                edges: [{ from, out, to }] } }
   Nodes carry no logic here — the runner (runner.js) interprets
   them. Validation stays structural (counts + shapes); unknown
   node types are rejected so a saved macro always runs.
   ============================================================ */

const fs = require('fs');
const path = require('path');

const MACROS_PATH = process.env.DATA_DIR
  ? path.join(process.env.DATA_DIR, 'macros.json')
  : path.join(__dirname, '..', '..', 'macros.json');

const MAX_MACROS = 50;
const MAX_NODES = 200;
const MAX_EDGES = 400;
const MAX_NAME = 48;

// Every node type the runner can execute (mirrors the editor palette).
const NODE_TYPES = new Set([
  'start', 'note', 'wait', 'repeat', 'stop', 'onchat',
  'goto', 'movekeys', 'follow', 'unfollow', 'guard', 'unguard',
  'stopmove', 'look', 'jump',
  'attack', 'equip',
  'mineone', 'minestart', 'minestop',
  'eat', 'drop', 'dropall', 'say', 'sleep', 'wake'
]);

function readFile() {
  try {
    if (fs.existsSync(MACROS_PATH)) {
      const raw = JSON.parse(fs.readFileSync(MACROS_PATH, 'utf8'));
      if (raw && Array.isArray(raw.macros)) return raw.macros;
    }
  } catch (err) {
    console.error(`[macro] Could not read macros.json (${err.message}). Starting empty.`);
  }
  return [];
}

function writeFile(macros) {
  fs.writeFileSync(MACROS_PATH, JSON.stringify({ macros }, null, 2), 'utf8');
}

function init() {
  try {
    if (!fs.existsSync(MACROS_PATH)) writeFile([]);
  } catch (err) {
    console.error(`[macro] Could not create macros.json (${err.message}).`);
  }
}

function list() {
  return readFile().map((m) => ({
    id: m.id,
    name: m.name,
    runOnConnect: !!m.runOnConnect,
    updatedAt: m.updatedAt || null,
    nodes: Array.isArray(m.graph && m.graph.nodes) ? m.graph.nodes.length : 0
  }));
}

function get(id) {
  return readFile().find((m) => m && m.id === id) || null;
}

function sanitizeGraph(graph) {
  const g = graph && typeof graph === 'object' ? graph : {};
  const nodes = Array.isArray(g.nodes) ? g.nodes.slice(0, MAX_NODES) : [];
  const edges = Array.isArray(g.edges) ? g.edges.slice(0, MAX_EDGES) : [];
  const cleanNodes = [];
  const ids = new Set();
  for (const n of nodes) {
    if (!n || typeof n !== 'object') continue;
    const id = String(n.id || '').slice(0, 32);
    const type = String(n.type || '');
    if (!id || ids.has(id) || !NODE_TYPES.has(type)) continue;
    ids.add(id);
    cleanNodes.push({
      id,
      type,
      x: Math.max(0, Math.min(3000, Math.round(Number(n.x) || 0))),
      y: Math.max(0, Math.min(3000, Math.round(Number(n.y) || 0))),
      params: n.params && typeof n.params === 'object' ? n.params : {}
    });
  }
  const cleanEdges = [];
  const seen = new Set();
  for (const e of edges) {
    if (!e || typeof e !== 'object') continue;
    const from = String(e.from || '');
    const to = String(e.to || '');
    const out = String(e.out || 'flow').slice(0, 24);
    if (!ids.has(from) || !ids.has(to) || from === to) continue;
    const key = `${from}>${out}>${to}`;
    if (seen.has(key)) continue;
    seen.add(key);
    cleanEdges.push({ from, out, to });
  }
  return { nodes: cleanNodes, edges: cleanEdges };
}

/** Create or update a macro. { id?, name, graph, runOnConnect } */
function save(input = {}) {
  const name = String(input.name || '').trim().slice(0, MAX_NAME);
  if (!name) return { ok: false, error: 'Give the macro a name.' };
  const graph = sanitizeGraph(input.graph);
  if (!graph.nodes.some((n) => n.type === 'start')) {
    return { ok: false, error: 'Add a Start node first.' };
  }
  const macros = readFile();
  const now = new Date().toISOString();
  const id = String(input.id || '');
  const existing = id ? macros.findIndex((m) => m && m.id === id) : -1;
  if (existing >= 0) {
    macros[existing] = { ...macros[existing], name, graph, runOnConnect: !!input.runOnConnect, updatedAt: now };
    writeFile(macros);
    return { ok: true, macro: macros[existing] };
  }
  if (macros.length >= MAX_MACROS) return { ok: false, error: `Too many macros (max ${MAX_MACROS}).` };
  const macro = {
    id: 'm_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 7),
    name,
    graph,
    runOnConnect: !!input.runOnConnect,
    updatedAt: now
  };
  macros.push(macro);
  writeFile(macros);
  return { ok: true, macro };
}

function remove(id) {
  const macros = readFile();
  const next = macros.filter((m) => !m || m.id !== id);
  if (next.length === macros.length) return { ok: false, error: 'Macro not found.' };
  writeFile(next);
  return { ok: true };
}

module.exports = { init, list, get, save, remove, sanitizeGraph, NODE_TYPES, MACROS_PATH };
