'use strict';

/**
 * Crop table for the Farming behaviour (BotManager farm loop + Farming page).
 *
 * kind 'grow'  — age-staged plants (wheat, carrots, potatoes, beetroot,
 *                nether wart). Ripe when the block's age state reaches
 *                ripeAge; breaking a ripe plant drops produce + seeds.
 * kind 'fruit' — melon / pumpkin blocks. The fruit block itself is broken
 *                (no age check); the stem regrows the next one.
 *
 * soil  — the block seeds may be planted on (farmland / soul sand).
 * seed  — item consumed when planting (carrots/potatoes plant themselves).
 * produce — item the deposit run carries to the chest.
 */
const CROPS = {
  wheat:      { key: 'wheat',      label: 'Wheat',       kind: 'grow',  block: 'wheat',       soil: 'farmland',  ripeAge: 7, seed: 'wheat_seeds',    produce: 'wheat' },
  carrot:     { key: 'carrot',     label: 'Carrots',     kind: 'grow',  block: 'carrots',     soil: 'farmland',  ripeAge: 7, seed: 'carrot',         produce: 'carrot' },
  potato:     { key: 'potato',     label: 'Potatoes',    kind: 'grow',  block: 'potatoes',    soil: 'farmland',  ripeAge: 7, seed: 'potato',         produce: 'potato' },
  beetroot:   { key: 'beetroot',   label: 'Beetroot',    kind: 'grow',  block: 'beetroots',   soil: 'farmland',  ripeAge: 3, seed: 'beetroot_seeds', produce: 'beetroot' },
  netherwart: { key: 'netherwart', label: 'Nether wart', kind: 'grow',  block: 'nether_wart', soil: 'soul_sand', ripeAge: 3, seed: 'nether_wart',    produce: 'nether_wart' },
  melon:      { key: 'melon',      label: 'Melons',      kind: 'fruit', block: 'melon',       soil: 'farmland',  ripeAge: 0, seed: 'melon_seeds',    produce: 'melon_slice' },
  pumpkin:    { key: 'pumpkin',    label: 'Pumpkins',    kind: 'fruit', block: 'pumpkin',     soil: 'farmland',  ripeAge: 0, seed: 'pumpkin_seeds',  produce: 'pumpkin' }
};

const CROP_LIST = Object.values(CROPS);

/**
 * Pick one crop def from the plantable candidates using the dashboard's
 * plant-ratio weights ({ wheat: 50, carrot: 25, ... }). Missing / empty
 * ratios fall back to an even random pick.
 */
function pickWeightedRatio(cands, ratios) {
  if (!cands || !cands.length) return null;
  if (!ratios || typeof ratios !== 'object') return cands[Math.floor(Math.random() * cands.length)];
  let total = 0;
  const weights = cands.map((d) => {
    const w = Math.max(0, Number(ratios[d.key]) || 0);
    total += w;
    return w;
  });
  if (total <= 0) return cands[Math.floor(Math.random() * cands.length)];
  let roll = Math.random() * total;
  for (let i = 0; i < cands.length; i++) {
    roll -= weights[i];
    if (roll <= 0) return cands[i];
  }
  return cands[cands.length - 1];
}

module.exports = { CROPS, CROP_LIST, pickWeightedRatio };
