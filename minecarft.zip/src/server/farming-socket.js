'use strict';
/* Farming socket API.
   Client -> server: farm:get | farm:save | farm:start | farm:stop
                     farm:craft:start | farm:craft:stop | holes:get | holes:set
   Server -> client: farm:status (live loop status) | farm:craft (hoe-run
                     progress) | holes:status (3D hole highlighter) */
const { saveConfig } = require('../config/store');
const { CROPS } = require('../farming/crops');

function isAdmin(socket) {
  return socket.data && socket.data.user && socket.data.user.role === 'admin';
}

function respond(ack, payload) {
  if (typeof ack === 'function') ack(payload);
}

const VALID_CROPS = ['all', ...Object.keys(CROPS)];

/** Normalize the plant-ratio map ({ wheat: 50, ... }) or null when empty. */
function cleanRatios(v) {
  if (!v || typeof v !== 'object') return null;
  const out = {};
  for (const k of Object.keys(CROPS)) {
    const n = Number(v[k]);
    if (Number.isFinite(n) && n > 0) out[k] = Math.min(100, Math.max(0, Math.round(n)));
  }
  return Object.keys(out).length ? out : null;
}

/** Pull the dashboard's farming options out of a socket payload. */
function farmOptsFrom(d) {
  return {
    crop: VALID_CROPS.includes(d.crop) ? d.crop : 'all',
    harvest: d.harvest !== false,
    replant: d.replant !== false,
    hoe: !!d.hoe,
    ratios: cleanRatios(d.ratios),
    deposit: !!d.deposit
  };
}

function registerFarmingSocketHandlers(io, botManager) {
  botManager.on('farm', (s) => io.emit('farm:status', s));
  botManager.on('farm:craft', (s) => io.emit('farm:craft', s));
  botManager.on('holes', (s) => io.emit('holes:status', s));

  io.on('connection', (socket) => {
    socket.emit('farm:status', botManager.getFarmStatus());
    socket.emit('holes:status', botManager.getHoleStatus());

    socket.on('farm:get', (data, ack) => {
      if (typeof ack !== 'function') ack = typeof data === 'function' ? data : undefined;
      respond(ack, { ok: true, farm: botManager.getFarmStatus() });
    });

    // Save options (persisted to config.json + live-applied to a running loop).
    socket.on('farm:save', (data, ack) => {
      if (typeof ack !== 'function') ack = typeof data === 'function' ? data : undefined;
      if (!isAdmin(socket)) return respond(ack, { ok: false, errors: ['Admin permission required.'] });
      const d = data && typeof data === 'object' ? data : {};
      const o = farmOptsFrom(d);
      const saved = saveConfig({
        farmCrop: o.crop,
        farmHarvest: o.harvest,
        farmReplant: o.replant,
        farmHoe: o.hoe,
        farmRatios: o.ratios,
        farmDeposit: o.deposit
      });
      if (botManager.farm.enabled) {
        botManager.farm.crop = o.crop;
        botManager.farm.harvest = o.harvest;
        botManager.farm.replant = o.replant;
        botManager.farm.hoe = o.hoe;
        botManager.farm.ratios = o.ratios;
        botManager.farm.deposit = o.deposit;
        botManager.emitFarmStatus();
      }
      respond(ack, { ok: true, config: saved, farm: botManager.getFarmStatus() });
    });

    socket.on('farm:start', (data, ack) => {
      if (typeof ack !== 'function') ack = typeof data === 'function' ? data : undefined;
      if (!isAdmin(socket)) return respond(ack, { ok: false, errors: ['Admin permission required.'] });
      const d = data && typeof data === 'object' ? data : {};
      const o = farmOptsFrom(d);
      saveConfig({
        farmEnabled: true,
        farmCrop: o.crop,
        farmHarvest: o.harvest,
        farmReplant: o.replant,
        farmHoe: o.hoe,
        farmRatios: o.ratios,
        farmDeposit: o.deposit
      });
      const err = botManager.setFarm(true, o);
      if (err) return respond(ack, { ok: false, errors: [err] });
      respond(ack, { ok: true, farm: botManager.getFarmStatus() });
    });

    socket.on('farm:stop', (data, ack) => {
      if (typeof ack !== 'function') ack = typeof data === 'function' ? data : undefined;
      if (!isAdmin(socket)) return respond(ack, { ok: false, errors: ['Admin permission required.'] });
      saveConfig({ farmEnabled: false });
      botManager.setFarm(false);
      respond(ack, { ok: true, farm: botManager.getFarmStatus() });
    });

    // Craft-a-hoe pipeline (runs on its own; progress via farm:craft).
    socket.on('farm:craft:start', (data, ack) => {
      if (typeof ack !== 'function') ack = typeof data === 'function' ? data : undefined;
      if (!isAdmin(socket)) return respond(ack, { ok: false, errors: ['Admin permission required.'] });
      botManager
        .startCraftHoe()
        .then((err) => {
          if (err) respond(ack, { ok: false, errors: [err] });
          else respond(ack, { ok: true });
        })
        .catch((err) => respond(ack, { ok: false, errors: [(err && err.message) || String(err)] }));
    });

    socket.on('farm:craft:stop', (data, ack) => {
      if (typeof ack !== 'function') ack = typeof data === 'function' ? data : undefined;
      if (!isAdmin(socket)) return respond(ack, { ok: false, errors: ['Admin permission required.'] });
      botManager.cancelCraftHoe();
      respond(ack, { ok: true });
    });

    // 3D map hole highlighter (admin only — it draws in the shared viewer).
    socket.on('holes:get', (data, ack) => {
      if (typeof ack !== 'function') ack = typeof data === 'function' ? data : undefined;
      respond(ack, { ok: true, holes: botManager.getHoleStatus() });
    });

    socket.on('holes:set', (data, ack) => {
      if (typeof ack !== 'function') ack = typeof data === 'function' ? data : undefined;
      if (!isAdmin(socket)) return respond(ack, { ok: false, errors: ['Admin permission required.'] });
      const d = data && typeof data === 'object' ? data : {};
      botManager.setHoleHighlight(!!d.enabled);
      respond(ack, { ok: true, holes: botManager.getHoleStatus() });
    });
  });
}

module.exports = { registerFarmingSocketHandlers };
