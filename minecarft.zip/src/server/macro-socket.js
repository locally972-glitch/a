'use strict';
/* Macro socket API.
   Client -> server: macro:list | macro:get | macro:save | macro:delete | macro:run | macro:stop | macro:status
   Server -> client: macro:status (live run progress) | macro:updated (library changed) */
function isAdmin(socket) {
  return socket.data && socket.data.user && socket.data.user.role === 'admin';
}
function respond(ack, payload) {
  if (typeof ack === 'function') ack(payload);
}
function registerMacroSocketHandlers(io, store, runner, botManager) {
  runner.on('status', (s) => io.emit('macro:status', s));
  const broadcast = () => io.emit('macro:updated', { list: store.list() });
  // Auto-run macros flagged "run on connect" (first connected transition).
  let wasConnected = false;
  if (botManager && typeof botManager.on === 'function') {
    botManager.on('state', (snap) => {
      const now = !!(snap && snap.state === 'connected');
      if (now && !wasConnected) {
        wasConnected = true;
        try {
          for (const m of store.list()) {
            if (!m.runOnConnect) continue;
            const full = store.get(m.id);
            if (!full) continue;
            const r = runner.run(full);
            if (!r.ok) break; // one macro at a time; the rest wait for a manual run
          }
        } catch (_) {}
      } else if (!now) {
        wasConnected = false;
      }
    });
  }
  io.on('connection', (socket) => {
    socket.emit('macro:list', { ok: true, list: store.list(), status: runner.status() });
    socket.on('macro:list', (data, ack) => {
      if (typeof ack !== 'function') ack = typeof data === 'function' ? data : undefined;
      respond(ack, { ok: true, list: store.list(), status: runner.status() });
    });
    socket.on('macro:get', (data, ack) => {
      if (typeof ack !== 'function') ack = typeof data === 'function' ? data : undefined;
      const d = data && typeof data === 'object' ? data : {};
      const m = store.get(String(d.id || ''));
      if (!m) return respond(ack, { ok: false, errors: ['Macro not found.'] });
      respond(ack, { ok: true, macro: m });
    });
    socket.on('macro:save', (data, ack) => {
      if (typeof ack !== 'function') ack = typeof data === 'function' ? data : undefined;
      if (!isAdmin(socket)) return respond(ack, { ok: false, errors: ['Admin permission required.'] });
      const d = data && typeof data === 'object' ? data : {};
      const r = store.save({ id: d.id, name: d.name, graph: d.graph, runOnConnect: d.runOnConnect });
      if (!r.ok) return respond(ack, { ok: false, errors: [r.error] });
      broadcast();
      respond(ack, { ok: true, macro: r.macro });
    });
    socket.on('macro:delete', (data, ack) => {
      if (typeof ack !== 'function') ack = typeof data === 'function' ? data : undefined;
      if (!isAdmin(socket)) return respond(ack, { ok: false, errors: ['Admin permission required.'] });
      const d = data && typeof data === 'object' ? data : {};
      const r = store.remove(String(d.id || ''));
      if (!r.ok) return respond(ack, { ok: false, errors: [r.error] });
      broadcast();
      respond(ack, { ok: true });
    });
    socket.on('macro:run', (data, ack) => {
      if (typeof ack !== 'function') ack = typeof data === 'function' ? data : undefined;
      if (!isAdmin(socket)) return respond(ack, { ok: false, errors: ['Admin permission required.'] });
      const d = data && typeof data === 'object' ? data : {};
      const m = store.get(String(d.id || ''));
      if (!m) return respond(ack, { ok: false, errors: ['Save the macro first.'] });
      const r = runner.run(m);
      if (!r.ok) return respond(ack, { ok: false, errors: [r.error] });
      respond(ack, { ok: true, runId: r.runId });
    });
    socket.on('macro:stop', (data, ack) => {
      if (typeof ack !== 'function') ack = typeof data === 'function' ? data : undefined;
      const r = runner.stop();
      if (!r.ok) return respond(ack, { ok: false, errors: [r.error] });
      respond(ack, { ok: true });
    });
    socket.on('macro:status', (data, ack) => {
      if (typeof ack !== 'function') ack = typeof data === 'function' ? data : undefined;
      respond(ack, { ok: true, status: runner.status() });
    });
  });
}
module.exports = { registerMacroSocketHandlers };
