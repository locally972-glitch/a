'use strict';

/* ============================================================
   MineBot — AI key store
   Persists saved AI provider keys to ai-keys.json (gitignored).
   Multiple keys allowed; names must be unique (case-insensitive).
   ============================================================ */

const fs = require('fs');
const path = require('path');

// DATA_DIR lets tests run against a throwaway directory so the user's real
// ai-keys.json is never touched. Falls back to the project root when unset.
const KEYS_FILE = process.env.DATA_DIR
  ? path.join(process.env.DATA_DIR, 'ai-keys.json')
  : path.join(__dirname, '..', '..', 'ai-keys.json');

const PROVIDERS = ['gemini', 'groq', 'nvidia', 'custom'];

// Best CURRENT free models — verified against provider docs (Sept 2026):
//  - Gemini free tier: gemini-3.8-flash (GA 2 Sept 2026, 1M context)
//  - Groq:             openai/gpt-oss-120b (production flagship, 131k context)
//  - NVIDIA NIM:       nvidia/nemotron-3-super-120b-a12b (free tier, 262k context)
//  - Custom:           user-supplied endpoint/model
const DEFAULT_MODELS = { gemini: 'gemini-3.8-flash', groq: 'openai/gpt-oss-120b', nvidia: 'nvidia/nemotron-3-super-120b-a12b', custom: '' };

// Previous-generation defaults. Keys still holding one of these are migrated
// to the matching new default on init() — user-typed custom models are never
// touched (only an exact old-default match for that provider migrates).
const OLD_DEFAULT_MODELS = { gemini: 'gemini-3.6-flash', groq: 'llama-3.3-70b-versatile', nvidia: 'meta/llama-3.3-70b-instruct' };

const DEFAULT_TOKENS = { maxInputTokens: 131072, maxOutputTokens: 8192 };

// Per-provider output caps: NVIDIA NIM's free tier limits llama-3.3-70b
// replies to 4,096 tokens — keys saved without an explicit output limit
// (e.g. via the API) must not default to 8192 or the Test button fails.
const PROVIDER_OUTPUT_DEFAULT = { gemini: 8192, groq: 8192, nvidia: 4096, custom: 8192 };

// keys: [{ id, name, provider, apiKey, model, endpoint, maxInputTokens, maxOutputTokens, stream, createdAt, updatedAt }]
let keys = [];

function init() {
  if (fs.existsSync(KEYS_FILE)) {
    try {
      keys = JSON.parse(fs.readFileSync(KEYS_FILE, 'utf8'));
    } catch (_) {
      keys = [];
    }
  } else {
    keys = [];
  }
  // Migrate keys that still hold a previous-generation default model to the
  // current default for their provider (custom user-typed models untouched).
  let migrated = false;
  for (const k of keys) {
    if (!k || typeof k.model !== 'string') continue;
    const oldDef = OLD_DEFAULT_MODELS[k.provider];
    const newDef = DEFAULT_MODELS[k.provider];
    if (oldDef && newDef && k.model === oldDef) {
      k.model = newDef;
      k.updatedAt = new Date().toISOString();
      migrated = true;
    }
  }
  // Custom keys without an explicit stream flag get streaming ON by default
  // (Atria / Inception etc. are OpenAI-compatible SSE endpoints that support
  // stream:true). Existing installs migrate here once.
  let migratedStream = false;
  for (const k of keys) {
    if (k && typeof k.stream !== 'boolean') {
      k.stream = true;
      migratedStream = true;
    }
  }
  if (migratedStream) migrated = true;
  if (migrated) {
    try { save(); } catch (_) { /* ignore */ }
  }
  return keys;
}

function save() {
  fs.writeFileSync(KEYS_FILE, JSON.stringify(keys, null, 2), 'utf8');
}

function list() {
  return [...keys];
}

function byName(name) {
  const n = String(name || '').trim().toLowerCase();
  return keys.find((k) => k.name.toLowerCase() === n) || null;
}

function byId(id) {
  return keys.find((k) => k.id === id) || null;
}

function normalize(input) {
  const inpTok = Number(input.maxInputTokens);
  const outTok = Number(input.maxOutputTokens);
  return {
    name: String(input.name || '').trim(),
    provider: String(input.provider || '').trim().toLowerCase(),
    apiKey: String(input.apiKey || '').trim(),
    model: String(input.model || '').trim(),
    endpoint: String(input.endpoint || '').trim(),
    // Missing/invalid token values fall back to sensible defaults (input is
    // provider-agnostic; output respects the provider's reply cap).
    maxInputTokens: Number.isFinite(inpTok) && inpTok >= 1 ? Math.floor(inpTok) : DEFAULT_TOKENS.maxInputTokens,
    maxOutputTokens: Number.isFinite(outTok) && outTok >= 1
      ? Math.floor(outTok)
      : (PROVIDER_OUTPUT_DEFAULT[String(input.provider || '').toLowerCase()] || DEFAULT_TOKENS.maxOutputTokens),
    stream: typeof input.stream === 'boolean' ? input.stream : true
  };
}

function validate(input, existingName) {
  const errors = [];
  const v = normalize(input);

  if (v.name.length < 1 || v.name.length > 32) {
    errors.push('Name must be 1–32 characters.');
  } else if (keys.some((k) => k.name.toLowerCase() === v.name.toLowerCase() && k.name !== existingName)) {
    errors.push(`An AI key named "${v.name}" already exists — names must be unique.`);
  }

  if (!PROVIDERS.includes(v.provider)) errors.push('Provider must be gemini, groq, nvidia or custom.');
  if (!v.apiKey) errors.push('API key is required.');
  if (!v.model) errors.push('Model is required (e.g. gemini-3.8-flash, openai/gpt-oss-120b, nvidia/nemotron-3-super-120b-a12b).');
  if (v.provider === 'custom' && !/^https?:\/\//i.test(v.endpoint)) {
    errors.push('Custom provider needs a full endpoint URL (https://…).');
  }
  if (!Number.isInteger(v.maxInputTokens) || v.maxInputTokens < 1 || v.maxInputTokens > 2000000) {
    errors.push('Input tokens must be a number between 1 and 2,000,000.');
  }
  if (!Number.isInteger(v.maxOutputTokens) || v.maxOutputTokens < 1 || v.maxOutputTokens > 200000) {
    errors.push('Output tokens must be a number between 1 and 200,000.');
  }

  return { ok: errors.length === 0, errors, value: v };
}

function add(input) {
  const r = validate(input);
  if (!r.ok) return r;
  const now = new Date().toISOString();
  const key = {
    id: 'k_' + Math.random().toString(36).slice(2, 10),
    ...r.value,
    createdAt: now,
    updatedAt: now
  };
  keys.push(key);
  save();
  return { ok: true, key };
}

function update(name, input) {
  const existing = byName(name);
  if (!existing) return { ok: false, error: 'Key not found.' };
  const r = validate({ ...existing, ...input }, existing.name);
  if (!r.ok) return r;
  Object.assign(existing, r.value, { updatedAt: new Date().toISOString() });
  save();
  return { ok: true, key: existing };
}

function remove(name) {
  const before = keys.length;
  keys = keys.filter((k) => k.name.toLowerCase() !== String(name || '').trim().toLowerCase());
  if (keys.length === before) return { ok: false, error: 'Key not found.' };
  save();
  return { ok: true };
}

module.exports = { init, list, byName, byId, add, update, remove, PROVIDERS, DEFAULT_MODELS, DEFAULT_TOKENS, PROVIDER_OUTPUT_DEFAULT };
