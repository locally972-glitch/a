'use strict';

/* ============================================================
   Building — AI design validator
   ------------------------------------------------------------
   Validates + normalizes a block list designed by the AI from its
   own knowledge ([tool:build:generate]) so it can feed straight
   into builder.startGeneratedBuild:

     - accepts a raw model reply (bare JSON array, ```json fenced,
       or prose with an embedded array) or an already-parsed array
     - drops air / unknown block names (checked against
       minecraft-data for the bot's version when available)
     - dedupes repeated positions (last wins), shifts the design so
       its minimum corner sits at the origin, caps the block count
       (bottom-up survivors) and the overall extent

   Pure + exported so the logic is unit-testable without a bot.
   ============================================================ */

const MAX_GENERATED_BLOCKS = 800; // fits an ~8K-token model reply
const MAX_GENERATED_EXTENT = 48; // blocks on any axis after shifting
const AIR_NAMES = new Set(['air', 'cave_air', 'void_air']);

function extractJsonArray(raw) {
  const text = String(raw || '');
  // 1. The whole reply is the array.
  try {
    const direct = JSON.parse(text);
    if (Array.isArray(direct)) return direct;
  } catch (_) {
    /* try the looser shapes below */
  }
  // 2. A fenced code block (```json ... ``` or ``` ... ```).
  const fence = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fence) {
    try {
      const parsed = JSON.parse(fence[1]);
      if (Array.isArray(parsed)) return parsed;
    } catch (_) {
      /* fall through */
    }
  }
  // 3. An array embedded in prose — first '[' to last ']'.
  const start = text.indexOf('[');
  const end = text.lastIndexOf(']');
  if (start !== -1 && end > start) {
    const parsed = JSON.parse(text.slice(start, end + 1));
    if (Array.isArray(parsed)) return parsed;
  }
  throw new Error('no JSON array found');
}

/** minecraft-data block-name registry for a version (null when unknown). */
function blocksByNameFor(version) {
  try {
    const mc = require('minecraft-data')(version);
    return (mc && mc.blocksByName) || null;
  } catch (_) {
    return null;
  }
}

function cleanProperties(props) {
  if (!props || typeof props !== 'object' || Array.isArray(props)) return undefined;
  const out = {};
  for (const k of Object.keys(props)) {
    const v = props[k];
    if (typeof v === 'string' || typeof v === 'number' || typeof v === 'boolean') {
      out[String(k)] = v;
    }
  }
  return Object.keys(out).length ? out : undefined;
}

/**
 * Validate a model-designed block list.
 * Returns { ok:true, blocks, size:{x,y,z}, dropped, truncated } or
 * { ok:false, error }. blocks are origin-shifted { x, y, z, name,
 * properties? } entries ready for startGeneratedBuild.
 */
function validateGeneratedBlocks(raw, mcVersion) {
  let arr = raw;
  if (typeof arr === 'string') {
    try {
      arr = extractJsonArray(arr);
    } catch (_) {
      return { ok: false, error: 'no block list found in the design' };
    }
  }
  if (!Array.isArray(arr) || !arr.length) {
    return { ok: false, error: 'the design is empty' };
  }

  const registry = mcVersion ? blocksByNameFor(mcVersion) : null;
  const byPos = new Map(); // "x,y,z" -> block (last wins)
  let dropped = 0;
  for (const e of arr) {
    if (!e || typeof e !== 'object') {
      dropped += 1;
      continue;
    }
    const x = Math.floor(Number(e.x));
    const y = Math.floor(Number(e.y));
    const z = Math.floor(Number(e.z));
    const name = String(e.name || '').trim().toLowerCase().replace(/^minecraft:/, '');
    if (!Number.isFinite(x) || !Number.isFinite(y) || !Number.isFinite(z)) {
      dropped += 1;
      continue;
    }
    if (!/^[a-z0-9_]+$/.test(name) || AIR_NAMES.has(name)) {
      dropped += 1;
      continue;
    }
    if (registry && !registry[name]) {
      dropped += 1; // not a real block on this MC version
      continue;
    }
    const block = { x, y, z, name };
    const props = cleanProperties(e.properties);
    if (props) block.properties = props;
    byPos.set(`${x},${y},${z}`, block);
  }
  if (!byPos.size) {
    return { ok: false, error: 'no usable blocks left after validation' };
  }

  // Shift the design so its minimum corner sits at the origin.
  let minX = Infinity;
  let minY = Infinity;
  let minZ = Infinity;
  for (const b of byPos.values()) {
    if (b.x < minX) minX = b.x;
    if (b.y < minY) minY = b.y;
    if (b.z < minZ) minZ = b.z;
  }
  let blocks = [...byPos.values()].map((b) => ({ ...b, x: b.x - minX, y: b.y - minY, z: b.z - minZ }));

  const size = {
    x: Math.max(...blocks.map((b) => b.x)) + 1,
    y: Math.max(...blocks.map((b) => b.y)) + 1,
    z: Math.max(...blocks.map((b) => b.z)) + 1
  };
  if (size.x > MAX_GENERATED_EXTENT || size.y > MAX_GENERATED_EXTENT || size.z > MAX_GENERATED_EXTENT) {
    return { ok: false, error: `design too spread out (${size.x}x${size.y}x${size.z} — max ${MAX_GENERATED_EXTENT} per axis)` };
  }

  // Over the cap: keep the bottom-up survivors so the foundation stands.
  let truncated = false;
  if (blocks.length > MAX_GENERATED_BLOCKS) {
    blocks = [...blocks]
      .sort((a, b) => a.y - b.y || a.z - b.z || a.x - b.x)
      .slice(0, MAX_GENERATED_BLOCKS);
    truncated = true;
  }
  return { ok: true, blocks, size, dropped, truncated };
}

module.exports = { validateGeneratedBlocks, MAX_GENERATED_BLOCKS, MAX_GENERATED_EXTENT };
