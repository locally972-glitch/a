'use strict';

/* ============================================================
   MineBot — Farming page logic
   ============================================================ */

const $ = (id) => document.getElementById(id);

function escapeHtml(s) {
  return String(s === undefined || s === null ? '' : s).replace(/[&<>"']/g, (c) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  }[c]));
}

const CROPS = [
  { key: 'wheat', label: 'Wheat', color: '#eab308' },
  { key: 'carrot', label: 'Carrots', color: '#f97316' },
  { key: 'potato', label: 'Potatoes', color: '#a3a380' },
  { key: 'beetroot', label: 'Beetroot', color: '#e11d48' },
  { key: 'netherwart', label: 'Nether wart', color: '#991b1b' },
  { key: 'melon', label: 'Melons', color: '#22c55e' },
  { key: 'pumpkin', label: 'Pumpkins', color: '#ea580c' }
];

const els = {
  crop: $('farm-crop'),
  harvest: $('farm-harvest'),
  replant: $('farm-replant'),
  hoe: $('farm-hoe'),
  deposit: $('farm-deposit'),
  saveBtn: $('farm-save'),
  saveHint: $('farm-save-hint'),
  startBtn: $('farm-start-btn'),
  stopBtn: $('farm-stop-btn'),
  stateBadge: $('farm-state-badge'),
  botBadge: $('farm-bot-badge'),
  liveIcon: $('farm-live-icon'),
  liveTitle: $('farm-live-title'),
  liveSub: $('farm-live-sub'),
  statHarvested: $('stat-harvested'),
  statPlanted: $('stat-planted'),
  statHoed: $('stat-hoed'),
  statDeposited: $('stat-deposited'),
  pie: $('farm-pie'),
  legend: $('farm-pie-legend'),
  ratios: $('farm-ratios'),
  craftBtn: $('crafthoe-btn'),
  craftStage: $('crafthoe-stage'),
  craftLog: $('crafthoe-log'),
  userBadge: $('user-badge'),
  toasts: $('toasts'),
  sidebar: $('sidebar'),
  overlay: $('sidebar-overlay'),
  menuBtn: $('menu-btn'),
  connPillSidebar: $('conn-pill-sidebar'),
  connPillMobile: $('conn-pill-mobile')
};

let me = null;
let socket = null;
let craftActive = false;
const ratioInputs = {};

/* ---------- Auth ---------- */

async function init() {
  buildRatioSliders();
  const res = await fetch('/api/auth/me');
  const data = await res.json();
  if (!data.ok) {
    window.location.replace('/login.html');
    return;
  }
  me = data.user;
  els.userBadge.innerHTML = mbIco('user') + ' ' + escapeHtml(me.username) + ' · ' + (me.role === 'admin' ? 'Admin' : 'Guest');

  // Guests can view + stop farming but not change anything.
  if (me.role !== 'admin') {
    for (const b of [els.saveBtn, els.startBtn, els.craftBtn]) {
      b.disabled = true;
      b.title = 'Admin permission required.';
    }
    for (const input of [els.crop, els.harvest, els.replant, els.hoe, els.deposit, ...Object.values(ratioInputs)]) {
      input.disabled = true;
    }
    els.saveHint.textContent = 'Read-only — an admin can save farming options.';
  }

  connectSocket();
}

/* ---------- Socket ---------- */

function connectSocket() {
  socket = io({ path: '/socket.io' });

  socket.on('connect', () => {
    setConnPill(true);
    // (Re)connect — pull fresh state (also covers server restarts).
    socket.emit('farm:get', (d) => {
      if (d && d.ok && d.farm) applyFarm(d.farm);
    });
  });
  socket.on('disconnect', () => setConnPill(false));
  socket.on('connect_error', () => setConnPill(false));

  // Live pushes refresh the status card only — never the option controls,
  // so typing/dragging sliders while the farm runs doesn't get clobbered.
  socket.on('farm:status', (f) => {
    if (!f) return;
    renderStatus(f);
    if (f.craftHoe) renderCraft({ active: f.craftHoe.active, stage: f.craftHoe.stage });
  });
  socket.on('farm:craft', (c) => {
    if (c) renderCraft(c);
  });

  socket.on('bot:state', (snap) => {
    const state = snap && snap.state ? snap.state : 'stopped';
    els.botBadge.innerHTML =
      state === 'connected' ? mbIco('circle-check') + ' Bot connected' : state === 'connecting' ? mbIco('refresh') + ' Connecting…' : mbIco('plug') + ' Bot offline';
    els.botBadge.className =
      'badge ' + (state === 'connected' ? 'badge-emerald' : state === 'connecting' ? 'badge-amber' : 'badge-slate') + ' shrink-0';
  });
}

function setConnPill(up) {
  const cls = up ? 'text-emerald-400' : 'text-slate-500';
  const txt = up ? '● Online' : '○ Offline';
  els.connPillSidebar.className = 'text-xs font-bold ' + cls;
  els.connPillSidebar.textContent = txt;
  els.connPillMobile.className = 'text-xs font-bold ' + cls;
  els.connPillMobile.textContent = up ? '●' : '○';
}

/* ---------- Farm state ---------- */

function applyFarm(f) {
  els.crop.value = f.crop || 'all';
  els.harvest.checked = f.harvest !== false;
  els.replant.checked = f.replant !== false;
  els.hoe.checked = !!f.hoe;
  els.deposit.checked = !!f.deposit;
  applyRatios(f.ratios);
  renderStatus(f);
  if (f.craftHoe) renderCraft({ active: f.craftHoe.active, stage: f.craftHoe.stage });
}

function renderStatus(f) {
  const on = !!f.enabled;
  els.stateBadge.textContent = on ? (f.busy ? 'Working…' : 'Running') : 'Off';
  els.stateBadge.className = 'badge shrink-0 ' + (on ? 'badge-emerald' : 'badge-slate');
  els.liveIcon.textContent = on ? '🚜' : '🌾';
  els.liveTitle.textContent = on ? 'Farming ' + cropLabel(f.crop) : 'Farming is off';
  els.liveSub.textContent = on ? f.status || 'Working…' : 'Pick a crop and press Start to put the bot to work.';
  const s = f.stats || {};
  els.statHarvested.textContent = s.harvested || 0;
  els.statPlanted.textContent = s.planted || 0;
  els.statHoed.textContent = s.hoed || 0;
  els.statDeposited.textContent = s.deposited || 0;
}

function cropLabel(key) {
  if (!key || key === 'all') return 'all nearby crops';
  const c = CROPS.find((x) => x.key === key);
  return c ? c.label.toLowerCase() : key;
}

function collect() {
  return {
    crop: els.crop.value,
    harvest: els.harvest.checked,
    replant: els.replant.checked,
    hoe: els.hoe.checked,
    deposit: els.deposit.checked,
    ratios: collectRatios()
  };
}

els.saveBtn.addEventListener('click', () => {
  if (me.role !== 'admin') return toast('Admin permission required.', 'error');
  els.saveBtn.disabled = true;
  socket.emit('farm:save', collect(), (res) => {
    els.saveBtn.disabled = false;
    if (res && res.ok) {
      toast('Farming options saved', 'success');
      if (res.farm) applyFarm(res.farm);
    } else {
      toast((res && res.errors && res.errors[0]) || 'Could not save farming options.', 'error');
    }
  });
});

els.startBtn.addEventListener('click', () => {
  if (me.role !== 'admin') return toast('Admin permission required.', 'error');
  els.startBtn.disabled = true;
  socket.emit('farm:start', collect(), (res) => {
    els.startBtn.disabled = false;
    if (res && res.ok) {
      toast('Farming started', 'success');
      if (res.farm) applyFarm(res.farm);
    } else {
      toast((res && res.errors && res.errors[0]) || 'Could not start farming.', 'error');
    }
  });
});

els.stopBtn.addEventListener('click', () => {
  els.stopBtn.disabled = true;
  socket.emit('farm:stop', (res) => {
    els.stopBtn.disabled = false;
    if (res && res.ok) {
      toast('Farming stopped', 'success');
      if (res.farm) applyFarm(res.farm);
    } else {
      toast((res && res.errors && res.errors[0]) || 'Could not stop farming.', 'error');
    }
  });
});

/* ---------- Plant ratio + pie ---------- */

function buildRatioSliders() {
  els.ratios.innerHTML = '';
  for (const c of CROPS) {
    const row = document.createElement('div');
    row.className = 'flex items-center gap-3';
    row.innerHTML =
      '<span class="w-2.5 h-2.5 rounded-full shrink-0" style="background:' + c.color + '"></span>' +
      '<span class="text-xs text-slate-300 w-24 shrink-0">' + escapeHtml(c.label) + '</span>' +
      '<input type="range" min="0" max="100" value="14" class="flex-1 accent-emerald-400" aria-label="' + escapeHtml(c.label) + ' weight" />' +
      '<span class="text-xs font-bold text-slate-200 w-8 text-right tabular-nums">14</span>';
    const input = row.querySelector('input');
    const val = row.querySelectorAll('span')[2];
    input.addEventListener('input', () => {
      val.textContent = input.value;
      renderPie(collectRatios());
    });
    els.ratios.appendChild(row);
    ratioInputs[c.key] = input;
  }
}

function collectRatios() {
  const out = {};
  for (const c of CROPS) out[c.key] = Number(ratioInputs[c.key].value) || 0;
  return out;
}

function applyRatios(ratios) {
  // null/empty from the server means "even split".
  const even = Math.floor(100 / CROPS.length);
  for (const c of CROPS) {
    const v = ratios && Number.isFinite(Number(ratios[c.key])) ? Math.max(0, Math.min(100, Math.round(Number(ratios[c.key])))) : even;
    ratioInputs[c.key].value = v;
    ratioInputs[c.key].closest('div').querySelectorAll('span')[2].textContent = v;
  }
  renderPie(collectRatios());
}

function renderPie(ratios) {
  const total = CROPS.reduce((n, c) => n + (Number(ratios[c.key]) || 0), 0);
  const svg = els.pie;
  svg.innerHTML = '';
  const NS = 'http://www.w3.org/2000/svg';
  if (total <= 0) {
    const circle = document.createElementNS(NS, 'circle');
    circle.setAttribute('cx', '60');
    circle.setAttribute('cy', '60');
    circle.setAttribute('r', '54');
    circle.setAttribute('fill', 'none');
    circle.setAttribute('stroke', '#334155');
    circle.setAttribute('stroke-width', '12');
    svg.appendChild(circle);
  } else {
    let angle = -90;
    for (const c of CROPS) {
      const w = Number(ratios[c.key]) || 0;
      if (w <= 0) continue;
      const sweep = (w / total) * 360;
      const large = sweep > 180 ? 1 : 0;
      const a0 = (angle * Math.PI) / 180;
      const a1 = ((angle + sweep) * Math.PI) / 180;
      const path = document.createElementNS(NS, 'path');
      path.setAttribute(
        'd',
        'M60,60 L' + (60 + 54 * Math.cos(a0)).toFixed(2) + ',' + (60 + 54 * Math.sin(a0)).toFixed(2) +
          ' A54,54 0 ' + large + ',1 ' + (60 + 54 * Math.cos(a1)).toFixed(2) + ',' + (60 + 54 * Math.sin(a1)).toFixed(2) + ' Z'
      );
      path.setAttribute('fill', c.color);
      path.setAttribute('stroke', '#070b12');
      path.setAttribute('stroke-width', '1.5');
      svg.appendChild(path);
      angle += sweep;
    }
  }
  els.legend.innerHTML = CROPS.map((c) => {
    const w = Number(ratios[c.key]) || 0;
    const pct = total > 0 ? Math.round((w / total) * 100) : Math.floor(100 / CROPS.length);
    return (
      '<div class="flex items-center gap-2">' +
      '<span class="w-2.5 h-2.5 rounded-full shrink-0" style="background:' + c.color + '"></span>' +
      '<span class="text-slate-300 flex-1">' + escapeHtml(c.label) + '</span>' +
      '<span class="font-bold text-slate-200 tabular-nums">' + pct + '%</span></div>'
    );
  }).join('');
}

/* ---------- Craft-a-hoe ---------- */

const STAGE_LABELS = {
  starting: 'Starting…',
  wood: 'Mining wood',
  planks: 'Planks & sticks',
  table: 'Crafting table',
  place: 'Placing table',
  hoe: 'Crafting hoe',
  done: 'Done',
  error: 'Failed'
};

function renderCraft(c) {
  craftActive = !!c.active;
  els.craftBtn.textContent = craftActive ? 'Stop hoe run' : 'Start hoe run';
  els.craftBtn.className = 'btn shrink-0 ' + (craftActive ? 'btn-ghost' : 'btn-cyan');
  if (!c.active && !c.stage) {
    els.craftStage.textContent = 'Idle';
    els.craftStage.className = 'badge badge-slate shrink-0';
    return;
  }
  els.craftStage.textContent = STAGE_LABELS[c.stage] || c.stage || (c.active ? 'Running' : 'Idle');
  els.craftStage.className =
    'badge shrink-0 ' + (c.stage === 'error' ? 'badge-red' : c.active ? 'badge-amber' : 'badge-emerald');
  if (c.log) appendCraftLog(c.log);
}

function appendCraftLog(line) {
  const empty = els.craftLog.querySelector('p.text-slate-500');
  if (empty && els.craftLog.children.length === 1) els.craftLog.innerHTML = '';
  const p = document.createElement('p');
  p.className = 'text-xs text-slate-300 leading-relaxed';
  p.textContent = line;
  els.craftLog.appendChild(p);
  while (els.craftLog.children.length > 60) els.craftLog.removeChild(els.craftLog.firstChild);
  els.craftLog.scrollTop = els.craftLog.scrollHeight;
}

els.craftBtn.addEventListener('click', () => {
  if (me.role !== 'admin') return toast('Admin permission required.', 'error');
  els.craftBtn.disabled = true;
  if (craftActive) {
    socket.emit('farm:craft:stop', (res) => {
      els.craftBtn.disabled = false;
      if (!(res && res.ok)) toast((res && res.errors && res.errors[0]) || 'Could not stop the hoe run.', 'error');
    });
  } else {
    els.craftLog.innerHTML = '';
    socket.emit('farm:craft:start', (res) => {
      els.craftBtn.disabled = false;
      if (res && res.ok) toast('Hoe run started', 'success');
      else toast((res && res.errors && res.errors[0]) || 'Could not start the hoe run.', 'error');
    });
  }
});

/* ---------- Sidebar (mobile) + logout ---------- */

function closeSidebar() {
  els.sidebar.classList.add('-translate-x-full');
  els.sidebar.classList.remove('translate-x-0');
  els.overlay.classList.add('hidden');
}

els.menuBtn.addEventListener('click', () => {
  if (els.sidebar.classList.contains('translate-x-0')) closeSidebar();
  else {
    els.sidebar.classList.remove('-translate-x-full');
    els.sidebar.classList.add('translate-x-0');
    els.overlay.classList.remove('hidden');
  }
});

els.overlay.addEventListener('click', closeSidebar);
document.querySelectorAll('[data-nav]').forEach((link) => link.addEventListener('click', closeSidebar));

$('logout-btn').addEventListener('click', async () => {
  await fetch('/api/auth/logout', { method: 'POST' });
  window.location.replace('/login.html');
});

/* ---------- Toasts ---------- */

function toast(message, type = 'info') {
  const icon = type === 'success' ? mbIco('circle-check') : type === 'error' ? mbIco('circle-x') : mbIco('info-circle');
  const el = document.createElement('div');
  el.className = 'toast ' + type;
  el.innerHTML = '<span class="select-none">' + icon + '</span><span>' + escapeHtml(message) + '</span>';
  els.toasts.appendChild(el);
  while (els.toasts.children.length > 4) els.toasts.firstChild.remove();
  setTimeout(() => {
    el.classList.add('out');
    setTimeout(() => el.remove(), 320);
  }, 3200);
}

/* ---------- Boot ---------- */

init();
