'use strict';
/* MineBot Macros - visual node editor client. */
const $ = (id) => document.getElementById(id);
const els = {
  select: $('macro-select'), name: $('macro-name'), autorun: $('macro-autorun'),
  btnNew: $('macro-new'), btnSave: $('macro-save'), btnRun: $('macro-run'),
  btnStop: $('macro-stop'), btnDelete: $('macro-delete'),
  palette: $('macro-palette'), viewport: $('macro-viewport'), canvas: $('macro-canvas'),
  edges: $('macro-edges'), pill: $('macro-run-pill'), statusbar: $('macro-statusbar'),
  log: $('macro-log'), dirty: $('macro-dirty'), hint: $('macro-hint'),
  toasts: $('toasts'), sidebar: $('sidebar'), overlay: $('sidebar-overlay'),
  menuBtn: $('menu-btn'), connPillSidebar: $('conn-pill-sidebar'),
  connPillMobile: $('conn-pill-mobile'), userBadge: $('user-badge'), logoutBtn: $('logout-btn')
};
const CATS = {
  trigger: { label: 'Trigger', color: '#34d399' },
  move: { label: 'Movement', color: '#38bdf8' },
  combat: { label: 'Combat', color: '#f87171' },
  mine: { label: 'Mining', color: '#fbbf24' },
  item: { label: 'Items', color: '#4ade80' },
  flow: { label: 'Flow', color: '#a78bfa' }
};
// Field: { k, label, t: text|number|check|select, ph, def, min, max, step, opts }
const NODE_DEFS = {
  start: { label: 'Start', cat: 'trigger', inputs: 0, outputs: ['flow'], fields: [] },
  onchat: { label: 'On Chat', cat: 'trigger', inputs: 1, outputs: ['heard', 'timeout'], fields: [
    { k: 'contains', label: 'Message contains', t: 'text', ph: 'keyword', def: '' },
    { k: 'timeout', label: 'Timeout (s)', t: 'number', min: 1, max: 600, def: 30 } ] },
  goto: { label: 'Go to X Z', cat: 'move', inputs: 1, outputs: ['flow', 'stuck'], fields: [
    { k: 'x', label: 'X', t: 'number', def: 0 }, { k: 'z', label: 'Z', t: 'number', def: 0 },
    { k: 'jump', label: 'Jump', t: 'check', def: false }, { k: 'sneak', label: 'Sneak', t: 'check', def: false } ] },
  movekeys: { label: 'Hold Keys', cat: 'move', inputs: 1, outputs: ['flow'], fields: [
    { k: 'forward', label: 'W', t: 'check', def: false }, { k: 'back', label: 'S', t: 'check', def: false },
    { k: 'left', label: 'A', t: 'check', def: false }, { k: 'right', label: 'D', t: 'check', def: false },
    { k: 'jump', label: 'Jump', t: 'check', def: false }, { k: 'sneak', label: 'Sneak', t: 'check', def: false },
    { k: 'sprint', label: 'Sprint', t: 'check', def: false },
    { k: 'seconds', label: 'Seconds', t: 'number', min: 0.2, max: 120, def: 2 } ] },
  follow: { label: 'Follow', cat: 'move', inputs: 1, outputs: ['flow'], fields: [
    { k: 'player', label: 'Player', t: 'text', ph: 'Steve', def: '' },
    { k: 'mode', label: 'Mode', t: 'select', opts: [['survival', 'Survival'], ['op', 'Operator (/tp)']], def: 'survival' },
    { k: 'radius', label: 'Radius', t: 'number', min: 1, max: 128, def: 5 } ] },
  unfollow: { label: 'Stop Follow', cat: 'move', inputs: 1, outputs: ['flow'], fields: [] },
  guard: { label: 'Guard', cat: 'move', inputs: 1, outputs: ['flow'], fields: [
    { k: 'player', label: 'Player', t: 'text', ph: 'Steve', def: '' },
    { k: 'mode', label: 'Mode', t: 'select', opts: [['survival', 'Survival'], ['op', 'Operator (/tp)']], def: 'survival' },
    { k: 'radius', label: 'Radius', t: 'number', min: 1, max: 128, def: 5 },
    { k: 'range', label: 'Attack range', t: 'number', min: 2, max: 16, def: 8 } ] },
  unguard: { label: 'Stop Guard', cat: 'move', inputs: 1, outputs: ['flow'], fields: [] },
  stopmove: { label: 'Stop Movement', cat: 'move', inputs: 1, outputs: ['flow'], fields: [] },
  look: { label: 'Look at XYZ', cat: 'move', inputs: 1, outputs: ['flow'], fields: [
    { k: 'x', label: 'X', t: 'number', def: 0 }, { k: 'y', label: 'Y', t: 'number', def: 64 }, { k: 'z', label: 'Z', t: 'number', def: 0 } ] },
  jump: { label: 'Jump', cat: 'move', inputs: 1, outputs: ['flow'], fields: [
    { k: 'times', label: 'Times', t: 'number', min: 1, max: 20, def: 1 } ] },
  attack: { label: 'Attack', cat: 'combat', inputs: 1, outputs: ['flow', 'failed'], fields: [
    { k: 'target', label: 'Target (empty = nearest)', t: 'text', ph: 'zombie', def: '' },
    { k: 'times', label: 'Times', t: 'number', min: 1, max: 50, def: 3 } ] },
  equip: { label: 'Equip Item', cat: 'combat', inputs: 1, outputs: ['flow', 'failed'], fields: [
    { k: 'name', label: 'Item', t: 'text', ph: 'diamond_sword', def: '' } ] },
  mineone: { label: 'Mine Block', cat: 'mine', inputs: 1, outputs: ['flow', 'failed'], fields: [
    { k: 'block', label: 'Block', t: 'text', ph: 'oak_log', def: '' } ] },
  minestart: { label: 'Start Tunnel', cat: 'mine', inputs: 1, outputs: ['flow'], fields: [
    { k: 'mode', label: 'Shape', t: 'select', opts: [['straight', 'Straight 1x2'], ['stair', 'Staircase']], def: 'straight' } ] },
  minestop: { label: 'Stop Tunnel', cat: 'mine', inputs: 1, outputs: ['flow'], fields: [] },
  eat: { label: 'Eat', cat: 'item', inputs: 1, outputs: ['flow', 'failed'], fields: [] },
  drop: { label: 'Drop Item', cat: 'item', inputs: 1, outputs: ['flow', 'failed'], fields: [
    { k: 'name', label: 'Item', t: 'text', ph: 'cobblestone', def: '' },
    { k: 'count', label: 'Count', t: 'number', min: 1, max: 2304, def: 64 } ] },
  dropall: { label: 'Drop All', cat: 'item', inputs: 1, outputs: ['flow', 'failed'], fields: [] },
  say: { label: 'Say', cat: 'item', inputs: 1, outputs: ['flow', 'failed'], fields: [
    { k: 'message', label: 'Message', t: 'text', ph: 'Hello!', def: '' } ] },
  sleep: { label: 'Sleep', cat: 'item', inputs: 1, outputs: ['flow', 'failed'], fields: [] },
  wake: { label: 'Wake', cat: 'item', inputs: 1, outputs: ['flow'], fields: [] },
  wait: { label: 'Wait', cat: 'flow', inputs: 1, outputs: ['flow'], fields: [
    { k: 'seconds', label: 'Seconds', t: 'number', min: 0.1, max: 3600, def: 2 } ] },
  repeat: { label: 'Repeat', cat: 'flow', inputs: 1, outputs: ['loop', 'done'], fields: [
    { k: 'times', label: 'Times', t: 'number', min: 1, max: 1000, def: 3 } ] },
  stop: { label: 'End', cat: 'flow', inputs: 1, outputs: [], fields: [] },
  note: { label: 'Note', cat: 'flow', inputs: 1, outputs: ['flow'], fields: [
    { k: 'text', label: 'Text', t: 'text', ph: 'comment...', def: '' } ] }
};
const nodes = new Map();
let edges = [];
let seq = 0;
let selectedId = null;
let macrosCache = [];
let dirty = false;
let linking = null;
let runningNode = null;
let currentUser = null;
const isGuest = () => currentUser && currentUser.role === 'guest';
/* ---------- palette ---------- */
function renderPalette() {
  els.palette.innerHTML = '';
  for (const [cat, meta] of Object.entries(CATS)) {
    const group = document.createElement('div');
    const title = document.createElement('p');
    title.className = 'pal-group';
    title.style.color = meta.color;
    const count = Object.values(NODE_DEFS).filter((d) => d.cat === cat).length;
    title.textContent = meta.label + '  -  ' + count;
    group.appendChild(title);
    const list = document.createElement('div');
    list.className = 'space-y-1.5';
    for (const [type, def] of Object.entries(NODE_DEFS)) {
      if (def.cat !== cat) continue;
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'pal-btn';
      b.style.color = meta.color;
      b.style.borderColor = meta.color + '33';
      b.innerHTML = '<span class="plus">+</span><span></span>';
      b.lastChild.textContent = def.label;
      b.title = 'Add ' + def.label;
      b.addEventListener('click', () => addNode(type));
      list.appendChild(b);
    }
    group.appendChild(list);
    els.palette.appendChild(group);
  }
}
/* ---------- nodes ---------- */
function defaultParams(type) {
  const p = {};
  for (const f of (NODE_DEFS[type] ? NODE_DEFS[type].fields : [])) {
    p[f.k] = f.def !== undefined ? f.def : (f.t === 'check' ? false : '');
  }
  return p;
}
function addNode(type, x, y, params, keepId) {
  if (isGuest()) return null;
  const def = NODE_DEFS[type];
  if (!def) return null;
  const id = keepId || ('n' + (++seq) + '_' + Date.now().toString(36));
  const vx = els.viewport.scrollLeft + 60 + (nodes.size % 6) * 40;
  const vy = els.viewport.scrollTop + 60 + (nodes.size % 6) * 40;
  const node = { id, type, x: Math.round(x !== undefined ? x : vx), y: Math.round(y !== undefined ? y : vy),
    params: { ...defaultParams(type), ...(params || {}) } };
  nodes.set(id, node);
  renderNode(node);
  drawEdges();
  setDirty(true);
  return node;
}
function fieldInput(node, f) {
  const val = node.params[f.k];
  if (f.t === 'select') {
    const s = document.createElement('select');
    s.dataset.k = f.k;
    for (const [v, label] of f.opts) {
      const o = document.createElement('option');
      o.value = v;
      o.textContent = label;
      if (String(val) === String(v)) o.selected = true;
      s.appendChild(o);
    }
    return s;
  }
  const inp = document.createElement('input');
  inp.dataset.k = f.k;
  if (f.t === 'number') {
    inp.type = 'number';
    if (f.min !== undefined) inp.min = f.min;
    if (f.max !== undefined) inp.max = f.max;
    inp.step = 'any';
    inp.value = val !== undefined && val !== '' ? val : (f.def !== undefined ? f.def : '');
  } else if (f.t === 'check') {
    inp.type = 'checkbox';
    inp.checked = !!val;
  } else {
    inp.type = 'text';
    inp.value = val !== undefined ? val : '';
    if (f.ph) inp.placeholder = f.ph;
  }
  return inp;
}
function renderNode(node) {
  const def = NODE_DEFS[node.type];
  document.querySelector('.mnode[data-id="' + node.id + '"]')?.remove();
  const el = document.createElement('div');
  el.className = 'mnode nd-' + def.cat + (runningNode === node.id ? ' running' : '');
  el.dataset.id = node.id;
  el.style.left = node.x + 'px';
  el.style.top = node.y + 'px';
  const head = document.createElement('div');
  head.className = 'mnode-head';
  const title = document.createElement('span');
  title.textContent = def.label;
  head.appendChild(title);
  if (!isGuest()) {
    const del = document.createElement('button');
    del.type = 'button';
    del.className = 'mnode-del';
    del.textContent = 'x';
    del.title = 'Delete node';
    del.addEventListener('click', (e) => { e.stopPropagation(); deleteNode(node.id); });
    head.appendChild(del);
  }
  el.appendChild(head);
  const cat = document.createElement('div');
  cat.className = 'mnode-cat';
  cat.textContent = CATS[def.cat].label;
  el.appendChild(cat);
  const fields = document.createElement('div');
  fields.className = 'mnode-fields';
  let checkWrap = null;
  for (const f of def.fields) {
    if (f.t === 'check') {
      if (!checkWrap) { checkWrap = document.createElement('div'); checkWrap.className = 'mnode-checks'; fields.appendChild(checkWrap); }
      const lab = document.createElement('label');
      lab.append(fieldInput(node, f));
      lab.append(document.createTextNode(f.label));
      checkWrap.appendChild(lab);
    } else {
      checkWrap = null;
      const lab = document.createElement('label');
      lab.append(document.createTextNode(f.label));
      lab.append(fieldInput(node, f));
      fields.appendChild(lab);
    }
  }
  for (const out of def.outputs) {
    const row = document.createElement('div');
    row.className = 'mout-row';
    const port = document.createElement('div');
    port.className = 'mport out' + (linking && linking.fromId === node.id && linking.out === out ? ' armed' : '');
    port.dataset.port = out;
    port.dataset.node = node.id;
    const lab = document.createElement('span');
    lab.className = 'mport-label';
    lab.textContent = out;
    port.appendChild(lab);
    port.addEventListener('click', (e) => { e.stopPropagation(); portClick(node.id, out); });
    row.appendChild(port);
    fields.appendChild(row);
  }
  el.appendChild(fields);
  if (def.inputs) {
    const inp = document.createElement('div');
    inp.className = 'mport in';
    inp.dataset.node = node.id;
    const lab = document.createElement('span');
    lab.className = 'mport-label';
    lab.textContent = 'flow';
    inp.appendChild(lab);
    inp.addEventListener('click', (e) => { e.stopPropagation(); inPortClick(node.id); });
    el.appendChild(inp);
  }
  fields.addEventListener('input', (e) => {
    const k = e.target && e.target.dataset ? e.target.dataset.k : null;
    if (!k) return;
    const f = def.fields.find((x) => x.k === k);
    if (!f) return;
    node.params[k] = f.t === 'check' ? e.target.checked : (f.t === 'number' ? Number(e.target.value) : e.target.value);
    setDirty(true);
  });
  if (isGuest()) fields.querySelectorAll('input,select').forEach((i) => { i.disabled = true; });
  head.addEventListener('pointerdown', (e) => { if (!e.target.closest('.mnode-del')) startDrag(e, node); });
  els.canvas.appendChild(el);
}
function deleteNode(id) {
  nodes.delete(id);
  edges = edges.filter((e) => e.from !== id && e.to !== id);
  document.querySelector('.mnode[data-id="' + id + '"]')?.remove();
  if (linking && linking.fromId === id) linking = null;
  drawEdges();
  setDirty(true);
}
/* ---------- edges ---------- */
function portCenter(nodeId, port, isIn) {
  const canvasRect = els.canvas.getBoundingClientRect();
  const sel = isIn ? '.mnode[data-id="' + nodeId + '"] .mport.in'
    : '.mnode[data-id="' + nodeId + '"] .mport.out[data-port="' + port + '"]';
  const p = document.querySelector(sel);
  if (!p) return null;
  const r = p.getBoundingClientRect();
  return { x: r.left - canvasRect.left + r.width / 2, y: r.top - canvasRect.top + r.height / 2 };
}
function drawEdges() {
  const NS = 'http://www.w3.org/2000/svg';
  els.edges.innerHTML = '';
  els.edges.setAttribute('viewBox', '0 0 2400 1600');
  for (const e of edges) {
    const a = portCenter(e.from, e.out, false);
    const b = portCenter(e.to, null, true);
    if (!a || !b) continue;
    const def = NODE_DEFS[(nodes.get(e.from) || {}).type];
    const color = def ? CATS[def.cat].color : '#34d399';
    const path = document.createElementNS(NS, 'path');
    const mx = Math.max(40, Math.abs(b.x - a.x) / 2);
    path.setAttribute('d', 'M ' + a.x + ' ' + a.y + ' C ' + (a.x + mx) + ' ' + a.y + ', ' + (b.x - mx) + ' ' + b.y + ', ' + b.x + ' ' + b.y);
    path.setAttribute('fill', 'none');
    path.setAttribute('stroke', color);
    path.setAttribute('stroke-width', '2.5');
    path.setAttribute('opacity', '0.9');
    if (!isGuest()) {
      path.addEventListener('click', () => {
        edges = edges.filter((x) => x !== e);
        drawEdges();
        setDirty(true);
        toast('Wire removed');
      });
    }
    els.edges.appendChild(path);
  }
}
function portClick(nodeId, out) {
  if (isGuest()) return;
  document.querySelectorAll('.mport.armed').forEach((p) => p.classList.remove('armed'));
  if (linking && linking.fromId === nodeId && linking.out === out) {
    linking = null;
    els.hint.textContent = 'Drag nodes to move them. Scroll to pan.';
    return;
  }
  linking = { fromId: nodeId, out };
  document.querySelector('.mnode[data-id="' + nodeId + '"] .mport.out[data-port="' + out + '"]')?.classList.add('armed');
  els.hint.textContent = 'Now click an input port (left dot) to connect "' + out + '". Esc cancels.';
}
function inPortClick(nodeId) {
  if (isGuest()) return;
  if (!linking) return;
  if (linking.fromId === nodeId) { toast('A node cannot connect to itself', 'error'); return; }
  edges = edges.filter((e) => !(e.from === linking.fromId && e.out === linking.out));
  edges.push({ from: linking.fromId, out: linking.out, to: nodeId });
  linking = null;
  document.querySelectorAll('.mport.armed').forEach((p) => p.classList.remove('armed'));
  els.hint.textContent = 'Drag nodes to move them. Scroll to pan.';
  drawEdges();
  setDirty(true);
}
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && linking) {
    linking = null;
    document.querySelectorAll('.mport.armed').forEach((p) => p.classList.remove('armed'));
    els.hint.textContent = 'Drag nodes to move them. Scroll to pan.';
  }
});
els.canvas.addEventListener('click', (e) => {
  if (e.target === els.canvas && linking) {
    linking = null;
    document.querySelectorAll('.mport.armed').forEach((p) => p.classList.remove('armed'));
    els.hint.textContent = 'Drag nodes to move them. Scroll to pan.';
  }
});
/* ---------- drag ---------- */
function startDrag(e, node) {
  if (isGuest()) return;
  if (e.button !== 0 && e.pointerType === 'mouse') return;
  e.preventDefault();
  const startX = e.clientX;
  const startY = e.clientY;
  const ox = node.x;
  const oy = node.y;
  const move = (ev) => {
    node.x = Math.max(0, Math.min(2180, Math.round(ox + (ev.clientX - startX))));
    node.y = Math.max(0, Math.min(1400, Math.round(oy + (ev.clientY - startY))));
    const el = document.querySelector('.mnode[data-id="' + node.id + '"]');
    if (el) { el.style.left = node.x + 'px'; el.style.top = node.y + 'px'; }
    drawEdges();
  };
  const up = () => {
    window.removeEventListener('pointermove', move);
    window.removeEventListener('pointerup', up);
    setDirty(true);
  };
  window.addEventListener('pointermove', move);
  window.addEventListener('pointerup', up);
}
/* ---------- serialize / load ---------- */
function serialize() {
  return {
    nodes: [...nodes.values()].map((n) => ({ id: n.id, type: n.type, x: n.x, y: n.y, params: n.params })),
    edges: edges.map((e) => ({ from: e.from, out: e.out, to: e.to }))
  };
}
function clearCanvas() {
  nodes.clear();
  edges = [];
  linking = null;
  runningNode = null;
  document.querySelectorAll('.mnode').forEach((n) => n.remove());
  drawEdges();
}
function loadGraph(graph) {
  clearCanvas();
  const g = graph && typeof graph === 'object' ? graph : {};
  for (const n of g.nodes || []) {
    if (!n || !NODE_DEFS[n.type]) continue;
    seq++;
    const node = { id: String(n.id || ('n' + seq)), type: n.type,
      x: Math.max(0, Math.min(2180, Math.round(Number(n.x) || 0))),
      y: Math.max(0, Math.min(1400, Math.round(Number(n.y) || 0))),
      params: { ...defaultParams(n.type), ...((n.params && typeof n.params === 'object') ? n.params : {}) } };
    nodes.set(node.id, node);
    renderNode(node);
  }
  edges = (g.edges || []).filter((e) => e && nodes.has(String(e.from)) && nodes.has(String(e.to)))
    .map((e) => ({ from: String(e.from), out: String(e.out || 'flow'), to: String(e.to) }));
  drawEdges();
  setDirty(false);
}
function setDirty(v) {
  dirty = v;
  els.dirty.classList.toggle('hidden', !v);
}
/* ---------- socket ---------- */
const socket = io();
socket.on('connect', () => setConnPills(true));
socket.on('disconnect', () => setConnPills(false));
socket.on('macro:list', (d) => {
  if (!d || !d.ok) return;
  refreshSelect(d.list || []);
  if (d.status && d.status.running) {
    setPill('running', 'badge-green');
    els.statusbar.textContent = 'Running: ' + (d.status.macroName || 'macro') + ' ...';
    setRunButtons(true);
  }
});
socket.on('macro:updated', (d) => refreshSelect((d && d.list) || macrosCache));
socket.on('macro:status', onMacroStatus);
function refreshSelect(list) {
  macrosCache = Array.isArray(list) ? list : [];
  const keep = selectedId;
  els.select.innerHTML = '';
  if (!macrosCache.length) {
    const o = document.createElement('option');
    o.value = '';
    o.textContent = 'No macros yet';
    els.select.appendChild(o);
    return;
  }
  for (const m of macrosCache) {
    const o = document.createElement('option');
    o.value = m.id;
    o.textContent = m.name + ' (' + (m.nodes || 0) + ' nodes)';
    els.select.appendChild(o);
  }
  if (keep && macrosCache.some((m) => m.id === keep)) {
    els.select.value = keep;
  } else if (!selectedId && macrosCache.length) {
    openMacro(macrosCache[0].id);
  }
}
function openMacro(id) {
  socket.emit('macro:get', { id }, (res) => {
    if (!res || !res.ok || !res.macro) {
      toast((res && res.errors && res.errors[0]) || 'Could not open macro', 'error');
      return;
    }
    selectedId = res.macro.id;
    els.select.value = selectedId;
    els.name.value = res.macro.name || '';
    els.autorun.checked = !!res.macro.runOnConnect;
    loadGraph(res.macro.graph);
  });
}
els.select.addEventListener('change', () => {
  if (els.select.value) openMacro(els.select.value);
});
els.name.addEventListener('input', () => setDirty(true));
els.autorun.addEventListener('change', () => setDirty(true));
els.btnNew.addEventListener('click', () => {
  if (isGuest()) return;
  selectedId = null;
  els.select.value = '';
  els.name.value = '';
  els.autorun.checked = false;
  clearCanvas();
  addNode('start', 120, 120);
  setDirty(false);
  toast('New macro - add nodes, wire them, Save, then Run');
});
function saveMacro() {
  return new Promise((resolve) => {
    const name = els.name.value.trim();
    if (!name) {
      toast('Give the macro a name first', 'error');
      return resolve(null);
    }
    socket.emit('macro:save', { id: selectedId, name, graph: serialize(), runOnConnect: els.autorun.checked }, (res) => {
      if (!res || !res.ok || !res.macro) {
        toast((res && res.errors && res.errors[0]) || 'Could not save', 'error');
        return resolve(null);
      }
      selectedId = res.macro.id;
      els.name.value = res.macro.name;
      setDirty(false);
      toast('Macro saved', 'success');
      resolve(res.macro);
    });
  });
}
els.btnSave.addEventListener('click', () => { if (!isGuest()) saveMacro(); });
els.btnDelete.addEventListener('click', () => {
  if (isGuest() || !selectedId) return;
  if (!window.confirm('Delete "' + els.name.value + '"?')) return;
  socket.emit('macro:delete', { id: selectedId }, (res) => {
    if (!res || !res.ok) {
      toast((res && res.errors && res.errors[0]) || 'Could not delete', 'error');
      return;
    }
    toast('Macro deleted');
    els.btnNew.click();
  });
});
els.btnRun.addEventListener('click', async () => {
  if (isGuest()) return;
  let id = selectedId;
  if (dirty || !id) {
    const saved = await saveMacro();
    if (!saved) return;
    id = saved.id;
  }
  socket.emit('macro:run', { id }, (res) => {
    if (!res || !res.ok) {
      toast((res && res.errors && res.errors[0]) || 'Could not run', 'error');
    }
  });
});
els.btnStop.addEventListener('click', () => {
  socket.emit('macro:stop', {}, (res) => {
    if (!res || !res.ok) toast((res && res.errors && res.errors[0]) || 'Nothing running');
  });
});
function setPill(text, badge) {
  els.pill.textContent = text;
  els.pill.className = 'badge shrink-0 ' + badge;
}
function setRunButtons(running) {
  els.btnRun.disabled = running;
  els.btnStop.disabled = !running;
}
function setRunningNode(nodeId) {
  runningNode = nodeId || null;
  document.querySelectorAll('.mnode.running').forEach((n) => n.classList.remove('running'));
  if (nodeId) document.querySelector('.mnode[data-id="' + nodeId + '"]')?.classList.add('running');
}
function logLine(text, cls) {
  const first = els.log.querySelector('.text-slate-500');
  if (first && els.log.children.length === 1) els.log.innerHTML = '';
  const d = document.createElement('div');
  if (cls) d.className = cls;
  d.textContent = new Date().toLocaleTimeString() + '  ' + text;
  els.log.prepend(d);
  while (els.log.children.length > 60) els.log.lastChild.remove();
}
function onMacroStatus(s) {
  if (!s) return;
  if (s.state === 'started') {
    setPill('running', 'badge-green');
    setRunButtons(true);
    els.statusbar.textContent = 'Running: ' + (s.macroName || 'macro') + ' ...';
    logLine('Started ' + (s.macroName || 'macro'), 'text-emerald-300');
  } else if (s.state === 'node') {
    setRunningNode(s.nodeId);
    els.statusbar.textContent = (s.macroName || '') + ' > ' + (s.label || s.nodeId || '');
  } else if (s.state === 'note') {
    logLine(s.message || '', 'text-amber-300');
  } else if (s.state === 'done') {
    setRunningNode(null);
    setPill('idle', 'badge-slate');
    setRunButtons(false);
    els.statusbar.textContent = s.message || 'Finished.';
    logLine(s.message || 'Finished.', 'text-emerald-300');
  } else if (s.state === 'stopped') {
    setRunningNode(null);
    setPill('idle', 'badge-slate');
    setRunButtons(false);
    els.statusbar.textContent = s.message || 'Stopped.';
    logLine(s.message || 'Stopped.', 'text-slate-400');
  } else if (s.state === 'error') {
    setRunningNode(s.nodeId);
    setPill('error', 'badge-red');
    setRunButtons(false);
    els.statusbar.textContent = 'Error: ' + (s.message || 'unknown');
    logLine('Error: ' + (s.message || 'unknown'), 'text-red-300');
  }
}
/* ---------- auth / shell ---------- */
fetch('/api/auth/me')
  .then((r) => r.json())
  .then((d) => {
    if (!d.ok) { window.location.replace('/login.html'); return; }
    currentUser = d.user;
    applyAuthUI();
  })
  .catch(() => window.location.replace('/login.html'));
function applyAuthUI() {
  els.userBadge.innerHTML = currentUser
    ? mbIco('user') + ' ' + escapeHtml(currentUser.username + ' - ' + (currentUser.role === 'admin' ? 'Admin' : 'Guest'))
    : '...';
  if (isGuest()) {
    els.name.disabled = true;
    els.autorun.disabled = true;
    els.btnNew.disabled = true;
    els.btnSave.disabled = true;
    els.btnRun.disabled = true;
    els.btnRun.title = 'Only admins can run macros.';
    els.btnDelete.disabled = true;
    els.palette.style.opacity = '0.45';
    els.palette.style.pointerEvents = 'none';
    document.querySelectorAll('.mnode input,.mnode select,.mnode button').forEach((i) => { i.disabled = true; });
  }
}
els.logoutBtn.addEventListener('click', async () => {
  await fetch('/api/auth/logout', { method: 'POST' });
  window.location.replace('/login.html');
});
function closeSidebar() {
  els.sidebar.classList.add('-translate-x-full');
  els.sidebar.classList.remove('translate-x-0');
  els.overlay.classList.add('hidden');
}
els.menuBtn.addEventListener('click', () => {
  const isOpen = els.sidebar.classList.contains('translate-x-0');
  if (isOpen) closeSidebar();
  else {
    els.sidebar.classList.remove('-translate-x-full');
    els.sidebar.classList.add('translate-x-0');
    els.overlay.classList.remove('hidden');
  }
});
els.overlay.addEventListener('click', closeSidebar);
document.querySelectorAll('[data-nav]').forEach((link) => {
  link.addEventListener('click', () => {
    document.querySelectorAll('[data-nav]').forEach((n) => n.classList.remove('active'));
    link.classList.add('active');
    closeSidebar();
  });
});
function setConnPills(online) {
  const cls = online ? 'text-emerald-400' : 'text-slate-500';
  els.connPillSidebar.textContent = online ? 'Online' : 'o Offline';
  els.connPillSidebar.className = 'text-xs font-bold ' + cls;
  els.connPillMobile.textContent = online ? '' : 'o';
  els.connPillMobile.className = 'text-xs font-bold ' + cls;
}
function toast(message, type = 'info') {
  const icon = mbIco(type === 'success' ? 'circle-check' : type === 'error' ? 'x' : 'info-circle');
  const el = document.createElement('div');
  el.className = 'toast ' + type;
  el.innerHTML = '<span class="select-none">' + icon + '</span><span></span>';
  el.lastChild.textContent = message;
  els.toasts.appendChild(el);
  setTimeout(() => {
    el.classList.add('out');
    setTimeout(() => el.remove(), 320);
  }, 3200);
}
function escapeHtml(str) {
  return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
/* ---------- boot ---------- */
renderPalette();
clearCanvas();
addNode('start', 120, 120);
setDirty(false);
setRunButtons(false);
