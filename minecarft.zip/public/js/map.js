'use strict';

/* ============================================================
   MineBot — 3D Map page logic
   ============================================================ */

const $ = (id) => document.getElementById(id);

const els = {
  viewerFrame: $('viewer-frame'),
  viewerPlaceholder: $('viewer-placeholder'),
  viewerError: $('viewer-error'),
  viewerErrorText: $('viewer-error-text'),
  viewerUrl: $('viewer-url'),
  openFull: $('open-full'),
  refreshBtn: $('refresh-btn'),
  holesBtn: $('holes-btn'),
  statusPill: $('status-pill'),
  statusText: $('status-text'),
  targetLine: $('target-line'),
  sidebar: $('sidebar'),
  overlay: $('sidebar-overlay'),
  menuBtn: $('menu-btn'),
  connPillSidebar: $('conn-pill-sidebar'),
  connPillMobile: $('conn-pill-mobile'),
  userBadge: $('user-badge'),
  logoutBtn: $('logout-btn')
};

const STATE_META = {
  stopped:      { text: 'STOPPED',      pill: '' },
  connecting:   { text: 'CONNECTING',   pill: 'connecting' },
  connected:    { text: 'IN SERVER',    pill: 'connected' },
  disconnected: { text: 'DISCONNECTED', pill: 'disconnected' },
  error:        { text: 'ERROR',        pill: 'error' }
};

/* ---------- Auth ---------- */

fetch('/api/auth/me')
  .then((r) => r.json())
  .then((d) => {
    if (!d.ok) {
      window.location.replace('/login.html');
      return;
    }
    driveRole = d.user && d.user.role === 'admin' ? 'admin' : 'guest';
    if (driveRole !== 'admin') els.holesBtn.style.display = 'none';
    els.userBadge.innerHTML = mbIco('user') + ' ';
    els.userBadge.appendChild(document.createTextNode(d.user.username + ' · ' + (d.user.role === 'admin' ? 'Admin' : 'Guest')));
  })
  .catch(() => window.location.replace('/login.html'));

els.logoutBtn.addEventListener('click', async () => {
  await fetch('/api/auth/logout', { method: 'POST' });
  window.location.replace('/login.html');
});

/* ---------- Socket.io ---------- */

const socket = io();

socket.on('connect', () => setConnPills(true));
socket.on('disconnect', () => setConnPills(false));

socket.on('bot:state', (snap) => {
  botConnected = snap.state === 'connected';
  if (!botConnected) releaseDrive(); // never leave keys held across a disconnect
  const meta = STATE_META[snap.state] || STATE_META.stopped;
  els.statusPill.className = 'status-pill animate-fade-up ' + meta.pill;
  els.statusText.textContent = meta.text;
  els.targetLine.textContent = snap.config
    ? `${snap.config.botName} → ${snap.config.serverIp}:${snap.config.serverPort}`
    : 'No bot configured yet';
});

socket.on('viewer:state', (snap) => updateViewer(snap));

/* ---------- Viewer ---------- */

// The viewer lives on the SAME origin as the dashboard (single port), so the
// URL is simply our own origin + the viewer path — works locally AND on
// Render (where only one port is exposed).
function viewerUrl(snap) {
  return window.location.origin + (snap.url || '/viewer/');
}

function updateViewer(snap) {
  els.viewerUrl.textContent = snap.running ? '● Viewer active' : 'Viewer off';
  els.viewerUrl.className = 'badge ' + (snap.running ? 'badge-emerald' : 'badge-slate');
  els.openFull.classList.toggle('hidden', !snap.running);
  els.refreshBtn.classList.toggle('hidden', !snap.running);
  els.holesBtn.classList.toggle('hidden', !snap.running);
  if (snap.running) {
    const url = viewerUrl(snap);
    els.openFull.href = url;
    els.viewerError.classList.add('hidden');
    els.viewerPlaceholder.classList.add('hidden');
    const frame = els.viewerFrame;
    if (frame.dataset.src !== url) {
      frame.dataset.src = url;
      frame.src = url;
    }
    frame.classList.remove('hidden');
  } else if (snap.error) {
    els.viewerFrame.classList.add('hidden');
    els.viewerPlaceholder.classList.add('hidden');
    els.viewerErrorText.textContent = snap.error;
    els.viewerError.classList.remove('hidden');
  } else {
    els.viewerFrame.classList.add('hidden');
    els.viewerError.classList.add('hidden');
    els.viewerPlaceholder.classList.remove('hidden');
  }
}

/* ---------- Hole highlighter ---------- */

let holesOn = false;

function renderHoles(s) {
  holesOn = !!(s && s.enabled);
  els.holesBtn.textContent = holesOn ? `\u25c9 Holes (${(s && s.count) || 0})` : '\u25c9 Holes';
  els.holesBtn.style.color = holesOn ? '#fcd34d' : '';
  els.holesBtn.title = holesOn ? 'Hide the red hole outlines' : 'Outline nearby holes and pits in red';
}

socket.on('holes:status', (s) => {
  if (s) renderHoles(s);
});
socket.emit('holes:get', (d) => {
  if (d && d.ok && d.holes) renderHoles(d.holes);
});

els.holesBtn.addEventListener('click', () => {
  if (driveRole !== 'admin') return;
  socket.emit('holes:set', { enabled: !holesOn }, (res) => {
    if (res && res.ok && res.holes) renderHoles(res.holes);
  });
});

els.refreshBtn.addEventListener('click', () => {
  const frame = els.viewerFrame;
  // Same-origin iframe → a direct reload works.
  try {
    frame.contentWindow.location.reload();
    return;
  } catch (_) {
    /* cross-origin fallback below */
  }
  // Fallback: reset the src to force a full reload.
  const url = frame.dataset.src;
  if (!url) return;
  frame.src = 'about:blank';
  frame.dataset.src = '';
  frame.classList.add('hidden');
  setTimeout(() => {
    frame.dataset.src = url;
    frame.src = url;
    frame.classList.remove('hidden');
  }, 120);
});

/* ---------- Split controls: arrows = camera, WASD = bot ----------
   The 3D canvas lives in an iframe. Keyboard events only reach it when the
   iframe has focus, so camera keys are forwarded from this page via
   postMessage ({ __mbCtrl }). WASD + Space + C drive the BOT instead — this
   page owns the server socket, so it emits bot:drive directly (the iframe
   posts its own drive keys back up as { __mbDrive }). */

const CAM_KEYS = ['arrowup', 'arrowdown', 'arrowleft', 'arrowright', 'shift'];
const DRIVE_KEYS = { w: 'forward', s: 'back', a: 'left', d: 'right', ' ': 'jump', space: 'jump', c: 'sneak' };
const driveState = { forward: false, back: false, left: false, right: false, jump: false, sneak: false };
let botConnected = false;
let driveRole = 'guest';

function forwardCamKey(key, down) {
  const frame = els.viewerFrame;
  if (frame && frame.contentWindow) {
    frame.contentWindow.postMessage({ __mbCtrl: { key, down: !!down } }, '*');
  }
}

function emitDrive() {
  if (!botConnected || driveRole !== 'admin') return;
  socket.emit('bot:drive', { keys: { ...driveState } }, () => {});
}

function setDriveKey(key, down) {
  const name = DRIVE_KEYS[String(key || '').toLowerCase()];
  if (!name) return false;
  down = !!down;
  if (driveState[name] === down) return true; // no edge — no traffic
  driveState[name] = down;
  emitDrive();
  return true;
}

function releaseDrive() {
  let held = false;
  for (const k of Object.keys(driveState)) {
    if (driveState[k]) held = true;
    driveState[k] = false;
  }
  if (held) emitDrive();
}

function releaseCam() {
  for (const k of CAM_KEYS) forwardCamKey(k, false);
}

function isTypingTarget(e) {
  const t = e.target;
  return !!t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable);
}

function onParentKey(e, down) {
  if (isTypingTarget(e)) return;
  const k = e.key.toLowerCase();
  if (CAM_KEYS.includes(k)) {
    forwardCamKey(k, down);
    if (k !== 'shift') e.preventDefault();
  } else if (setDriveKey(k, down)) {
    e.preventDefault();
  }
}

window.addEventListener('keydown', (e) => {
  if (e.repeat && DRIVE_KEYS[e.key.toLowerCase()] !== undefined) return; // edge-triggered
  onParentKey(e, true);
});
window.addEventListener('keyup', (e) => onParentKey(e, false));
window.addEventListener('blur', () => {
  releaseCam();
  releaseDrive();
});

// Drive keys pressed while the IFRAME has focus come back up here.
window.addEventListener('message', (e) => {
  const d = e.data && e.data.__mbDrive;
  if (d && typeof d.key === 'string') setDriveKey(d.key, d.down);
});

/* ---------- Mobile sidebar ---------- */

function closeSidebar() {
  els.sidebar.classList.add('-translate-x-full');
  els.sidebar.classList.remove('translate-x-0');
  els.overlay.classList.add('hidden');
}

els.menuBtn.addEventListener('click', () => {
  if (els.sidebar.classList.contains('translate-x-0')) closeSidebar();
  else {
    els.sidebar.classList.remove('-translate-x-full');
    els.sidebar.classList.add('translate-x-0');
    els.overlay.classList.remove('hidden');
  }
});

els.overlay.addEventListener('click', closeSidebar);

document.querySelectorAll('[data-nav]').forEach((link) => {
  link.addEventListener('click', () => closeSidebar());
});

/* ---------- Helpers ---------- */

function setConnPills(online) {
  const cls = online ? 'text-emerald-400' : 'text-slate-500';
  els.connPillSidebar.textContent = online ? '● Online' : '○ Offline';
  els.connPillSidebar.className = 'text-xs font-bold ' + cls;
  els.connPillMobile.textContent = online ? '●' : '○';
  els.connPillMobile.className = 'text-xs font-bold ' + cls;
}

/* ---------- Boot ---------- */

updateViewer({ running: false, url: '/viewer/', error: null });
