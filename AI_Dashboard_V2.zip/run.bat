@echo off
setlocal enabledelayedexpansion
title AI Dashboard - Launcher
cd /d "%~dp0"

echo ==========================================================
echo    AI Dashboard V2  -  one-click launcher
echo ==========================================================
echo.

REM ---------- 1/4  find a working Python 3 ----------
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY (where python >nul 2>nul && set "PY=python")
if not defined PY goto :nopython

REM The Windows Store "python.exe" stub answers `where` but does nothing - verify it runs.
%PY% -c "import sys" >nul 2>nul
if errorlevel 1 set "PY="
if not defined PY goto :nopython

%PY% -c "import sys; sys.exit(0 if sys.version_info[0] >= 3 else 1)" >nul 2>nul
if errorlevel 1 goto :oldpython

echo [1/4] Python 3 found:
%PY% --version
echo.

REM ---------- 2/4  install dependencies ----------
echo [2/4] Installing dependencies (first run may take a minute)...
%PY% -m pip install --upgrade pip >nul 2>nul
%PY% -m pip install -r requirements.txt
if errorlevel 1 (
  echo       Normal install failed - retrying for the current user only...
  %PY% -m pip install --user -r requirements.txt
)
if errorlevel 1 goto :pipfail
echo.

REM ---------- 3/4  start the server in its own window ----------
echo [3/4] Starting the server...
start "AI Dashboard Server" cmd /k "%PY% server.py"
echo.

REM ---------- 4/4  open the dashboard ----------
echo [4/4] Opening http://localhost:5000 ...
timeout /t 3 /nobreak >nul
start "" http://localhost:5000

echo.
echo ==========================================================
echo   The dashboard is starting in your browser.
echo   Keep the "AI Dashboard Server" window open while you use it;
echo   close that window (or press Ctrl+C in it) to stop the app.
echo ==========================================================
echo.
pause
exit /b 0

:nopython
echo [X] Python 3 was not found on this PC.
echo.
echo     1. Download it from  https://www.python.org/downloads/
echo     2. During setup, TICK the box "Add python.exe to PATH"
echo     3. Close this window and run run.bat again.
echo.
pause
exit /b 1

:oldpython
echo [X] This PC has an old Python. AI Dashboard needs Python 3.9 or newer.
echo     Install the latest Python 3 from https://www.python.org/downloads/
echo.
pause
exit /b 1

:pipfail
echo.
echo [X] Could not install the Python packages (requirements.txt).
echo     Check your internet connection, or if you are on a locked-down PC,
echo     run this from a folder you own and try again.
echo.
pause
exit /b 1
