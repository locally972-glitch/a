#!/usr/bin/env python3
"""Standalone check for any OpenAI-compatible endpoint (your snippet format).

Fill in BASE_URL / MODEL / API_KEY / STREAM below, then run:
    python test_custom_provider.py

STREAM = True  -> curl -N style: POST with {"stream": true} and read the SSE
                  chunks as they arrive.
STREAM = False -> one plain JSON reply, parsed cleanly:
                  POST {BASE_URL}/chat/completions
                  {"model": MODEL, "messages": [...], "stream": False}

The dashboard sends the same request and has a per-provider "Stream responses"
toggle (Settings -> AI Providers), so a provider that works here with STREAM on
should be left streaming on.
"""
import json

import requests

# ---- Fill these in ----
BASE_URL = ""   # e.g. "https://api.atria-asi.ai/v1" (no trailing /chat/completions needed)
MODEL = ""      # e.g. "Atria-Dawn-Preview"
API_KEY = ""    # leave "" if your endpoint needs no key
STREAM = True   # False = single JSON reply, True = live SSE streaming
# -----------------------

headers = {"Content-Type": "application/json"}
if API_KEY:
    headers["Authorization"] = f"Bearer {API_KEY}"
url = BASE_URL.rstrip("/") if BASE_URL.endswith("/chat/completions") else f"{BASE_URL.rstrip('/')}/chat/completions"

payload = {
    "model": MODEL,
    "messages": [
        {"role": "user", "content": "Confirm that you are online and working!"}
    ],
    "stream": STREAM,
}

try:
    print(f"Sending request to model (stream={STREAM})...")
    if not STREAM:
        response = requests.post(url, headers=headers, json=payload, timeout=120)
        print("Inference Status:", response.status_code)
        print("Model Response:", response.json()['choices'][0]['message']['content'])
    else:
        with requests.post(url, headers=headers, json=payload, stream=True, timeout=120) as response:
            print("Inference Status:", response.status_code)
            if response.status_code != 200:
                print("Model Response:", response.text[:400])
            else:
                print("Model Response: ", end="", flush=True)
                for line in response.iter_lines(decode_unicode=True):
                    if not line or not line.startswith("data: "):
                        continue
                    data = line[6:].strip()
                    if data == "[DONE]":
                        break
                    try:
                        delta = (json.loads(data).get("choices") or [{}])[0].get("delta") or {}
                    except json.JSONDecodeError:
                        continue
                    if delta.get("reasoning_content"):
                        print(delta["reasoning_content"], end="", flush=True)
                    if delta.get("content"):
                        print(delta["content"], end="", flush=True)
                print()
except Exception as e:
    print("Failed to run inference:", e)
