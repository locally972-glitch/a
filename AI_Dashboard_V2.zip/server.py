#!/usr/bin/env python3
"""AI Dashboard Backend v5 - Research IDs, tool memory, agent selection, built-in browser research"""
import json, os, subprocess, re, shutil, threading, time, hashlib, glob, signal, contextlib
from pathlib import Path
from datetime import datetime
from urllib.parse import quote_plus, unquote
from flask import Flask, request, jsonify, Response, send_from_directory
from flask_cors import CORS
import requests as http_requests

# ==================== BACKGROUND PROCESS REGISTRY ====================
# Long-running processes started with run_command(action="start", ...) — also the
# legacy background=true form. Kept in a pid -> info map so the AI can list them,
# read their logs (even sleeping until output appears) and stop them later.
# Processes are detached from this server, so they keep running when the app
# restarts or the browser closes. The log file is the durable record of output.
_bg_procs = {}
_bg_lock = threading.Lock()


def _bg_key(pid):
    try:
        return int(pid)
    except Exception:
        return pid


def _bg_entry(pid=None, name=None):
    """Look up a tracked process by pid (preferred) or by its label."""
    with _bg_lock:
        snapshot = list(_bg_procs.items())
    if pid is not None:
        return _bg_procs.get(_bg_key(pid))
    if name:
        for _p, info in snapshot:
            if info.get("name") == name:
                return info
    return None


def _bg_status(pid):
    """'running' | 'exited(N)' | 'unknown' (unknown = started before a restart)."""
    info = _bg_procs.get(_bg_key(pid))
    proc = info.get("proc") if info else None
    if proc is None:
        return "unknown"
    rc = proc.poll()
    return "running" if rc is None else f"exited({rc})"


def _bg_snapshot():
    items = []
    with _bg_lock:
        snapshot = list(_bg_procs.items())
    for pid, info in snapshot:
        status = _bg_status(pid)
        items.append({
            "pid": pid,
            "name": info.get("name"),
            "command": info.get("command"),
            "status": status,
            "running": status == "running",
            "log_file": info.get("log_file"),
            "started": info.get("started"),
            "uptime_s": max(0, int(time.time() - info.get("started_ts", time.time()))),
        })
    return items


def _kill_tree(pid, force=True):
    """Kill a process and its children. Returns (ok, error_message)."""
    try:
        pid = int(pid)
    except Exception:
        return False, f"invalid pid {pid!r}"
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"],
                           capture_output=True, timeout=20)
        else:
            sig = signal.SIGKILL if force else signal.SIGTERM
            pgid = None
            with contextlib.suppress(Exception):
                pgid = os.getpgid(pid)
            if pgid is not None:
                with contextlib.suppress(ProcessLookupError):
                    os.killpg(pgid, sig)
            else:
                os.kill(pid, sig)
        return True, None
    except Exception as e:
        return False, str(e)


def _log_tail(log_path, lines=40):
    try:
        if not log_path or not os.path.exists(log_path):
            return ""
        with open(log_path, "r", encoding="utf-8", errors="replace") as f:
            data = f.read()
        try:
            n = max(1, min(int(lines or 40), 500))
        except Exception:
            n = 40
        return "\n".join(data.splitlines()[-n:])
    except Exception as e:
        return f"(could not read log: {e})"


def _start_bg(command, name, workspace):
    """Launch a detached background process writing to <name>.log. Returns its registry info."""
    base = re.sub(r"[^A-Za-z0-9_.-]", "", (name or "bg").strip().replace(" ", "_")) or "bg"
    wp = Path(workspace) if workspace else Path.cwd()
    # Never clobber the log of a process that is still running under the same label
    running_names = {i.get("name") for i in _bg_snapshot() if i.get("running")}
    safe, n = base[:56], 1
    while safe in running_names:
        n += 1
        safe = f"{base[:52]}-{n}"
    log_path = wp / f"{safe}.log"
    # Unbuffered Python so `python server.py` output lands in the log immediately
    # (a redirected stdout is block-buffered otherwise, so the log looks empty).
    child_env = os.environ.copy()
    child_env["PYTHONUNBUFFERED"] = "1"
    kwargs = dict(shell=True, cwd=str(wp), stdout=subprocess.DEVNULL,
                  stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, env=child_env)
    if os.name == "nt":
        kwargs["creationflags"] = 0x00000008  # DETACHED_PROCESS — survives this server
    else:
        kwargs["start_new_session"] = True    # own session/process group — survives this server
    with open(log_path, "w", encoding="utf-8") as lf:
        kwargs["stdout"] = lf
        proc = subprocess.Popen(command, **kwargs)
    info = {
        "pid": proc.pid,
        "name": safe,
        "command": command,
        "log_file": str(log_path),
        "workspace": str(wp),
        "proc": proc,
        "started": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "started_ts": time.time(),
    }
    with _bg_lock:
        _bg_procs[proc.pid] = info
    return info


def summarize_tool_args(name, args):
    """Short, human-readable target of a tool call (a path, command, query...).
    Saved with the message so the dashboard can show "Read server.py" style rows
    after a refresh instead of a raw Python dict."""
    if not isinstance(args, dict):
        return str(args)[:120]
    if name == "run_command":
        act = str(args.get("action") or ("start" if args.get("background") else "run"))[:10]
        tgt = args.get("command") or args.get("name") or (f"pid {args.get('pid')}" if args.get("pid") is not None else "")
        tgt = str(tgt).replace("\n", " ").strip()
        return f"{act}: {tgt}"[:160] if tgt else act
    for k in ("path", "file", "filepath", "remote_path", "command", "query",
              "pattern", "url", "task", "name", "old_text", "content"):
        v = args.get(k)
        if v:
            s = str(v).replace("\n", " ").strip()
            return s[:160]
    return ", ".join(f"{k}={str(v)[:40]}" for k, v in list(args.items())[:3])[:160]


def summarize_tool_result(name, result):
    """One-line human summary of a tool result, reused for chat + saved history."""
    if not isinstance(result, dict):
        return str(result)[:100]
    if name == "run_command":
        act = result.get("action", "run")
        if result.get("timed_out"):
            return f"timed out after {result.get('timeout')}s"
        if act == "list":
            return f"{result.get('count', 0)} process(es)"
        if act == "start":
            return f"started pid {result.get('pid')} ({result.get('name')}) — {result.get('status', 'running')}"
        if act == "log":
            return ("running" if result.get("running") else str(result.get("status", "stopped"))) + (
                " · matched" if result.get("matched") else (" · no match" if result.get("wait_for") else ""))
        if act == "stop":
            return "stopped" if result.get("success") else str(result.get("error", "stop failed"))[:60]
        return f"exit: {result.get('exit_code', '?')}"
    if result.get("error"):
        return f"error: {str(result['error'])[:100]}"
    if name == "deep_research":
        return f"Research ID: {result.get('research_id', 'N/A')}, {result.get('total_sources', 0)} sources"
    if name == "web_search":
        return f"{result.get('total', 0)} results"
    if name == "read_file":
        return f"{result.get('lines', 0)} lines"
    if name == "list_files":
        return f"{result.get('count', 0)} items"
    if name == "search_files":
        return f"{result.get('total', 0)} matches"
    return "success" if result.get("success") else "done"

app = Flask(__name__, static_folder="static", static_url_path="")
CORS(app)

CONFIG_DIR = Path.home() / ".ai-dashboard"
CONFIG_DIR.mkdir(exist_ok=True)
CONFIG_FILE = CONFIG_DIR / "config.json"
SESSIONS_FILE = CONFIG_DIR / "sessions.json"
RESEARCH_DIR = CONFIG_DIR / "research"
RESEARCH_DIR.mkdir(exist_ok=True)

# WebGL debugger state - stores data from connected WebGL pages
webgl_sessions = {}
webgl_lock = threading.Lock()

# V2 live request registry
chat_cancel_events = {}
chat_cancel_lock = threading.Lock()
APP_VERSION = '2.0.0'
APP_STARTED_TS = time.time()

BUILTIN_PROVIDERS = {"abliteration", "openai", "anthropic", "gemini"}

DEFAULT_CONFIG = {
    "providers": {
        "abliteration": {"name": "Abliteration.ai", "base_url": "https://api.abliteration.ai/v1", "api_keys": [], "model": "abliterated-model", "enabled": True, "type": "openai", "custom": False, "stream": True},
        "openai": {"name": "OpenAI", "base_url": "https://api.openai.com/v1", "api_keys": [], "model": "gpt-4o", "enabled": False, "type": "openai", "custom": False, "stream": True},
        "anthropic": {"name": "Anthropic (Claude)", "base_url": "https://api.anthropic.com/v1", "api_keys": [], "model": "claude-sonnet-4-20250514", "enabled": False, "type": "anthropic", "custom": False, "stream": True},
        "gemini": {"name": "Google Gemini", "base_url": "https://generativelanguage.googleapis.com/v1beta", "api_keys": [], "model": "gemini-2.5-flash", "enabled": False, "type": "gemini", "custom": False, "stream": True}
    },
    "active_provider": "abliteration",
    "active_api_key_name": {},
    "workspaces": [],
    "active_workspace": "",
    "context_limit": 4000,
    "gemini_research_keys": [],
    "research_agent_provider": "gemini",
    "research_agent_key_index": 0,
    "multibot_force_research": True
}

# ==================== CONFIG ====================
def load_config():
    cfg = None
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            cfg = json.load(f)
    if cfg is None:
        cfg = json.loads(json.dumps(DEFAULT_CONFIG))
    _ensure_defaults(cfg)
    return cfg

def _ensure_defaults(cfg):
    for k, v in DEFAULT_CONFIG.items():
        if k not in cfg:
            cfg[k] = json.loads(json.dumps(v)) if not isinstance(v, (list, dict)) else v
    if "providers" not in cfg: cfg["providers"] = {}
    for pk, pv in DEFAULT_CONFIG["providers"].items():
        if pk not in cfg["providers"]:
            cfg["providers"][pk] = json.loads(json.dumps(pv))
        else:
            if "api_keys" not in cfg["providers"][pk]: cfg["providers"][pk]["api_keys"] = []
            for field in ["name", "base_url", "model", "enabled", "stream"]:
                if field not in cfg["providers"][pk]: cfg["providers"][pk][field] = pv[field]
            if "type" not in cfg["providers"][pk]:
                cfg["providers"][pk]["type"] = pv.get("type", "openai")
            if "custom" not in cfg["providers"][pk]:
                cfg["providers"][pk]["custom"] = (pk not in BUILTIN_PROVIDERS)
    # Custom providers added by the user: make sure they have all fields so the
    # generic OpenAI-compatible path works (same format as the user's snippet).
    for pk, pv in cfg["providers"].items():
        if pk not in DEFAULT_CONFIG["providers"]:
            pv.setdefault("name", pk)
            pv.setdefault("base_url", "")
            pv.setdefault("api_keys", [])
            pv.setdefault("model", "")
            pv.setdefault("enabled", True)
            pv.setdefault("type", "openai")
            pv.setdefault("custom", True)
        # Every OpenAI-compatible provider streams unless the user turns it off.
        # Providers saved before this setting existed get it enabled here, so all
        # existing custom keys start with streaming on.
        if pv.get("type", "openai") == "openai":
            pv["stream"] = _as_bool(pv.get("stream"), True)


def _as_bool(value, default=True):
    """Config-safe boolean: accepts real bools and the strings the UI/JSON send."""
    if value is None: return default
    if isinstance(value, bool): return value
    if isinstance(value, (int, float)): return bool(value)
    text = str(value).strip().lower()
    if text in ("true", "1", "yes", "on"): return True
    if text in ("false", "0", "no", "off", ""): return False
    return default


def provider_stream_enabled(provider):
    """True = request the provider with \"stream\": true, False = plain JSON request."""
    return _as_bool((provider or {}).get("stream"), True)

# ==================== CUSTOM (OpenAI-compatible) PROVIDER HELPERS ====================
def get_provider_type(provider_key, provider=None):
    """Return 'anthropic' | 'gemini' | 'openai'. Custom providers default to openai."""
    pv = provider or config["providers"].get(provider_key, {})
    t = (pv.get("type") or "").lower()
    if t in ("anthropic", "gemini", "openai"):
        return t
    if provider_key == "anthropic": return "anthropic"
    if provider_key == "gemini": return "gemini"
    return "openai"

def chat_completions_url(base_url):
    """Build the POST URL for an OpenAI-compatible endpoint.

    Accepts either the API root (https://host/v1) or the full path
    (https://host/v1/chat/completions) and never doubles the suffix.
    """
    base = (base_url or "").strip().rstrip("/")
    if base.lower().endswith("/chat/completions"):
        return base
    return f"{base}/chat/completions"

def openai_headers(api_key):
    headers = {"Content-Type": "application/json"}
    if api_key:  # local servers (Ollama/LM Studio) often need no auth
        headers["Authorization"] = f"Bearer {api_key}"
    return headers

def openai_chat_payload(model, messages, stream=False, extra=None):
    """Non-streaming payload in exactly the user's snippet format."""
    payload = {"model": model, "messages": messages, "stream": stream}
    if extra:
        payload.update(extra)
    return payload

def slugify_provider_id(name):
    slug = re.sub(r"[^a-z0-9]+", "_", (name or "").lower()).strip("_")
    return slug or f"custom_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

def save_config(cfg):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)

def load_sessions():
    if SESSIONS_FILE.exists():
        try:
            with open(SESSIONS_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except: pass
    return {}

def save_sessions(sessions):
    # Strip base64 image data from the on-disk copy (keeps sessions.json small).
    # The in-memory session keeps full data URLs so follow-up messages still see the images.
    disk = {}
    for sid, s in sessions.items():
        if isinstance(s, dict) and s.get("messages"):
            s = json.loads(json.dumps(s))
            for m in s["messages"]:
                if m.get("images"):
                    m["images"] = [(i[:120] + "…") if i else "" for i in m["images"]]
        disk[sid] = s
    with open(SESSIONS_FILE, "w", encoding="utf-8") as f:
        json.dump(disk, f, indent=2)

config = load_config()
sessions = load_sessions()

print(f"[CONFIG] Providers: {list(config['providers'].keys())}")
for pk, pv in config["providers"].items():
    print(f"  {pk}: {len(pv.get('api_keys',[]))} key(s), enabled={pv.get('enabled',False)}")
print(f"[SESSIONS] {len(sessions)} session(s)")
gkeys = config.get("gemini_research_keys", [])
print(f"[RESEARCH] {len(gkeys)} Gemini research key(s)")
print(f"[RESEARCH] Agent provider: {config.get('research_agent_provider', 'gemini')}, key index: {config.get('research_agent_key_index', 0)}")

# ==================== RESEARCH STORAGE ====================
def save_research(research_id, data):
    path = RESEARCH_DIR / f"{research_id}.json"
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def load_research(research_id):
    path = RESEARCH_DIR / f"{research_id}.json"
    if path.exists():
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return None

def list_research():
    results = []
    for f in sorted(RESEARCH_DIR.glob("research_*.json"), reverse=True):
        try:
            with open(f, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            results.append({
                "id": data.get("id", f.stem),
                "query": data.get("query", ""),
                "depth": data.get("depth", ""),
                "sources": data.get("total_sources", 0),
                "created": data.get("created", ""),
            })
        except: pass
    return results[:50]

# ==================== TOOLS ====================
TOOLS = [
    {"type": "function", "function": {"name": "read_file", "description": "Read file contents from the active workspace", "parameters": {"type": "object", "properties": {"path": {"type": "string", "description": "File path relative to workspace root"}}, "required": ["path"]}}},
    {"type": "function", "function": {"name": "write_file", "description": "Create or overwrite a file", "parameters": {"type": "object", "properties": {"path": {"type": "string"}, "content": {"type": "string"}}, "required": ["path", "content"]}}},
    {"type": "function", "function": {"name": "edit_file", "description": "Find and replace text in a file", "parameters": {"type": "object", "properties": {"path": {"type": "string"}, "old_text": {"type": "string"}, "new_text": {"type": "string"}}, "required": ["path", "old_text", "new_text"]}}},
    {"type": "function", "function": {"name": "list_files", "description": "List files and folders", "parameters": {"type": "object", "properties": {"path": {"type": "string", "default": "."}}}}},
    {"type": "function", "function": {"name": "run_command", "description": "Run a shell command in the workspace root AND manage the long-running processes it starts. action='run' (default): block up to `timeout` seconds and return stdout/stderr/exit_code. action='start': launch detached in the background and return immediately with a pid + log file (survives app restarts). action='log': tail a background process log, optionally sleeping until `wait_for` appears. action='list': show every background process with its status. action='stop': kill one by pid or name.", "parameters": {"type": "object", "properties": {"action": {"type": "string", "enum": ["run", "start", "log", "list", "stop"], "description": "run (default) | start | log | list | stop"}, "command": {"type": "string", "description": "Shell command to run (required for action='run'/'start')"}, "name": {"type": "string", "description": "Short label for a background process, e.g. 'dev-server'. Used by start/log/stop; output is written to <name>.log in the workspace"}, "pid": {"type": "integer", "description": "Process id for action='log'/'stop' (alternative to name)"}, "timeout": {"type": "number", "description": "action='run': seconds to wait before giving up and stopping the command (default 120, max 600)"}, "background": {"type": "boolean", "description": "Legacy alias for action='start'"}, "wait": {"type": "number", "description": "action='start': seconds to sleep before returning the first log output (default 0, max 60)"}, "lines": {"type": "integer", "description": "action='log'/'start': trailing log lines to return (default 40)"}, "wait_for": {"type": "string", "description": "action='log': text/regex to sleep for in the log, e.g. 'ready|listening|error'"}, "wait_timeout": {"type": "number", "description": "action='log': max seconds to wait for wait_for (default 0 = no wait, max 120)"}, "force": {"type": "boolean", "description": "action='stop': force kill (default true)"}}, "required": []}}},
    {"type": "function", "function": {"name": "stop_process", "description": "Stop a background process by pid. Prefer run_command(action='stop').", "parameters": {"type": "object", "properties": {"pid": {"type": "integer", "description": "The pid returned when the background process was started"}}, "required": ["pid"]}}},
    {"type": "function", "function": {"name": "delete_file", "description": "Delete a file or directory", "parameters": {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]}}},
    {"type": "function", "function": {"name": "search_files", "description": "Search for text in files", "parameters": {"type": "object", "properties": {"pattern": {"type": "string"}, "path": {"type": "string", "default": "."}}, "required": ["pattern"]}}},
    {"type": "function", "function": {"name": "web_search", "description": "Quick web search. Returns titles, URLs, snippets.", "parameters": {"type": "object", "properties": {"query": {"type": "string", "description": "Search query"}}, "required": ["query"]}}},
    {"type": "function", "function": {"name": "deep_research", "description": "Comprehensive research: generates sub-questions, searches Google for each, fetches top pages, reads content, synthesizes report with sources. Returns a research_id to reference later. USE THIS for ANY research task.", "parameters": {"type": "object", "properties": {"query": {"type": "string", "description": "The research topic or question"}, "depth": {"type": "string", "enum": ["quick", "standard", "deep"], "description": "quick=3 searches, standard=5, deep=7. Default: standard"}}, "required": ["query"]}}},
    {"type": "function", "function": {"name": "fetch_page", "description": "Fetch a webpage and extract its main text content.", "parameters": {"type": "object", "properties": {"url": {"type": "string", "description": "URL to fetch"}}, "required": ["url"]}}},
    {"type": "function", "function": {"name": "view_research", "description": "View a previously saved research by its ID. Use this to recall research results from earlier.", "parameters": {"type": "object", "properties": {"research_id": {"type": "string", "description": "The research ID (e.g. research_20260908_123456)"}}, "required": ["research_id"]}}},
    {"type": "function", "function": {"name": "list_research", "description": "List all saved research with IDs, queries, and dates. Use this to find past research.", "parameters": {"type": "object", "properties": {}}}},
    {"type": "function", "function": {"name": "webgl_list_sessions", "description": "List all connected WebGL pages being debugged. Returns URLs, titles, and basic stats.", "parameters": {"type": "object", "properties": {}}}},
    {"type": "function", "function": {"name": "webgl_get_state", "description": "Get full WebGL state from a connected page: GL info, shaders, programs, textures, draw calls, errors.", "parameters": {"type": "object", "properties": {"url": {"type": "string", "description": "URL of the connected page (from webgl_list_sessions)"}}, "required": ["url"]}}},
    {"type": "function", "function": {"name": "webgl_get_shaders", "description": "Get shader source code from a connected WebGL page.", "parameters": {"type": "object", "properties": {"url": {"type": "string", "description": "URL of the connected page"}, "shader_index": {"type": "integer", "description": "Shader index (0-based). Omit to get all."}}, "required": ["url"]}}},
    {"type": "function", "function": {"name": "webgl_get_errors", "description": "Get all WebGL errors captured from a connected page.", "parameters": {"type": "object", "properties": {"url": {"type": "string", "description": "URL of the connected page"}}, "required": ["url"]}}},
    {"type": "function", "function": {"name": "webgl_get_draw_calls", "description": "Get recent WebGL draw calls from a connected page.", "parameters": {"type": "object", "properties": {"url": {"type": "string", "description": "URL of the connected page"}, "count": {"type": "integer", "description": "Number of draw calls to return (default 50)"}}, "required": ["url"]}}},
    {"type": "function", "function": {"name": "webgl_get_textures", "description": "Get texture information from a connected WebGL page.", "parameters": {"type": "object", "properties": {"url": {"type": "string", "description": "URL of the connected page"}}, "required": ["url"]}}},
    {"type": "function", "function": {"name": "webgl_get_injector", "description": "Get the JavaScript injector script to paste in browser DevTools console on any WebGL page to start debugging.", "parameters": {"type": "object", "properties": {}}}}
]

# VPS (SSH) tools — registered only when at least one VPS connection exists.
VPS_TOOLS = [
    {"type": "function", "function": {"name": "vps_status", "description": "Check which VPS servers are configured and which one is active. Call this first when the user asks to work with their VPS/server.", "parameters": {"type": "object", "properties": {}}}},
    {"type": "function", "function": {"name": "vps_run", "description": "Run a shell command on the active VPS over SSH and get stdout/stderr/exit_code. Use for anything: check services, install packages, git, logs, processes, etc.", "parameters": {"type": "object", "properties": {"command": {"type": "string", "description": "Shell command to run on the VPS"}, "timeout": {"type": "number", "description": "Seconds to wait (default 60, max 600)"}}, "required": ["command"]}}},
    {"type": "function", "function": {"name": "vps_list_files", "description": "List files and folders on the active VPS at a path. Root folders like /, /var/www, /home are fine.", "parameters": {"type": "object", "properties": {"path": {"type": "string", "description": "Absolute path on the VPS (default: home directory)"}}}}},
    {"type": "function", "function": {"name": "vps_read_file", "description": "Read a file's content from the active VPS.", "parameters": {"type": "object", "properties": {"path": {"type": "string", "description": "Absolute path on the VPS"}}, "required": ["path"]}}},
    {"type": "function", "function": {"name": "vps_write_file", "description": "Create or overwrite a file on the active VPS. Creates parent directories automatically.", "parameters": {"type": "object", "properties": {"path": {"type": "string", "description": "Absolute path on the VPS"}, "content": {"type": "string"}}, "required": ["path", "content"]}}},
    {"type": "function", "function": {"name": "vps_edit_file", "description": "Find and replace text in a file on the active VPS.", "parameters": {"type": "object", "properties": {"path": {"type": "string"}, "old_text": {"type": "string"}, "new_text": {"type": "string"}}, "required": ["path", "old_text", "new_text"]}}},
    {"type": "function", "function": {"name": "vps_download", "description": "Download a file from the active VPS into the active workspace (same filename). Tell the user where it was saved.", "parameters": {"type": "object", "properties": {"path": {"type": "string", "description": "Remote path on the VPS"}}, "required": ["path"]}}},
    {"type": "function", "function": {"name": "vps_upload", "description": "Upload a file from the active workspace to the active VPS.", "parameters": {"type": "object", "properties": {"path": {"type": "string", "description": "File path in the workspace"}, "remote_path": {"type": "string", "description": "Destination path on the VPS (default: same name in home)"}}, "required": ["path"]}}}
]

def _vps_tools_for_request():
    return list(VPS_TOOLS) if _vps_active_conn() else []

def get_agent_tools():
    total_keys = sum(len(p.get("api_keys", [])) for p in config["providers"].values() if p.get("enabled"))
    if total_keys < 1: return []
    agents = [f"{pv['name']} ({pk})" for pk, pv in config["providers"].items() if pv.get("enabled") and pv.get("api_keys")]
    # Also add research keys as agent options
    rkeys = config.get("gemini_research_keys", [])
    if rkeys:
        for i, k in enumerate(rkeys):
            agents.append(f"Gemini Research Key {i+1} ({k[:8]}...)")
    return [{"type": "function", "function": {"name": "spawn_agent", "description": f"Spawn a specialized mini-agent. Available: {', '.join(agents)}.", "parameters": {"type": "object", "properties": {"task": {"type": "string", "description": "The specific task for the agent"}, "role": {"type": "string", "description": "web_researcher, code_reviewer, file_analyzer, debugger, general"}, "provider": {"type": "string", "description": "Which provider (optional)"}, "key_index": {"type": "integer", "description": "Which key index if provider has multiple (optional, default 0)"}}, "required": ["task", "role"]}}}]

# ==================== TEXTUAL TOOL-CALL FALLBACK ====================
# Some OpenAI-compatible models (small / custom / abliterated ones) cannot emit
# native `tool_calls` — instead they DESCRIBE the call in chat text, e.g.:
#   Sure, here's the function call correctly formatted in JSON:
#   ```json
#   {"name": "list_files", "arguments": {"path": ""}}
#   ```
# Detect that shape (fenced block only, to avoid firing on prose/examples) and
# execute it for real so tools work on EVERY model, not just ones with
# function-calling support.
def _extract_fenced_json_objects(text):
    """Brace-match every { ... } object inside ``` fences. Robust to nested
    braces (e.g. write_file content) unlike regex approaches."""
    objs = []
    for m in re.finditer(r"```(?:json)?\s*([\s\S]*?)\s*```", text or "", re.IGNORECASE):
        body = m.group(1)
        for start in [mm.start() for mm in re.finditer(r"\{", body)]:
            depth, in_str, esc, end = 0, False, False, -1
            for i in range(start, len(body)):
                ch = body[i]
                if in_str:
                    if esc: esc = False
                    elif ch == "\\": esc = True
                    elif ch == '"': in_str = False
                else:
                    if ch == '"': in_str = True
                    elif ch == "{": depth += 1
                    elif ch == "}":
                        depth -= 1
                        if depth == 0:
                            end = i
                            break
            if end != -1:
                objs.append(body[start:end + 1])
    return objs

def parse_textual_tool_calls(text):
    """Return [{"name","arguments"}] for valid tool JSON found in fenced blocks."""
    calls = []
    if not text or '"name"' not in text:
        return calls
    valid_names = {t["function"]["name"] for t in TOOLS} | {t["function"]["name"] for t in VPS_TOOLS} | {"spawn_agent"}
    seen = set()
    for cand in _extract_fenced_json_objects(text)[:8]:
        if cand in seen:
            continue
        seen.add(cand)
        try:
            obj = json.loads(cand)
        except Exception:
            continue
        if not isinstance(obj, dict):
            continue
        name = obj.get("name", "")
        if name not in valid_names:
            continue
        args = obj.get("arguments", {})
        if isinstance(args, str):
            try: args = json.loads(args)
            except Exception: args = {}
        if not isinstance(args, dict):
            args = {}
        calls.append({"name": name, "arguments": args})
        if len(calls) >= 5:
            break
    return calls

def textual_tool_results_prompt(executed):
    lines = ["Tool results — use them to answer. If you need another tool, emit it the same way (ONE fenced json block per message):"]
    for name, args, result in executed:
        try:
            summary = json.dumps(result, ensure_ascii=False)[:3000]
        except Exception:
            summary = str(result)[:3000]
        try:
            arg_str = json.dumps(args, ensure_ascii=False)[:300]
        except Exception:
            arg_str = str(args)[:300]
        lines.append(f"- {name}({arg_str}) => {summary}")
    return "\n".join(lines)

# ==================== TOOL EXECUTION ====================
_WS_PREFIX_RE = re.compile(r"^ws(\d+)(?:[/\\](.*))?$", re.IGNORECASE)

def resolve_ws_path(path, workspace, workspaces=None):
    """Resolve a tool path against attached workspaces.
    'wsN' or 'wsN/xxx' targets the Nth attached workspace (1-based); no prefix → primary.
    Returns (root_path, remaining_relative_path)."""
    if not path:
        return (workspace, ".")
    norm = str(path).replace("\\", "/")
    m = _WS_PREFIX_RE.match(norm)
    if m and workspaces:
        idx = int(m.group(1)) - 1
        if 0 <= idx < len(workspaces):
            return (workspaces[idx], m.group(2) or ".")
    return (workspace, str(path))

def execute_tool(name, args, workspace, workspaces=None):
    if not workspace and name not in ["web_search", "deep_research", "fetch_page", "spawn_agent", "view_research", "list_research", "run_command",
        "webgl_list_sessions", "webgl_get_state", "webgl_get_shaders", "webgl_get_errors", "webgl_get_draw_calls", "webgl_get_textures", "webgl_get_injector",
        "vps_status", "vps_run", "vps_list_files", "vps_read_file", "vps_write_file", "vps_edit_file", "vps_download", "vps_upload"]:
        return {"error": "No workspace selected — tell the user to add one via Workspaces → + Add in the sidebar, then retry"}
    wp = Path(workspace) if workspace else None
    wss = [Path(w) for w in (workspaces or ([workspace] if workspace else []))]
    def _root_for(path):
        """Returns the Path root a given relative path belongs to (handles wsN/ prefixes)."""
        if wp is None: return None
        root_str, _rel = resolve_ws_path(path, workspace, [str(w) for w in wss])
        return Path(root_str)
    try:
        if name == "read_file":
            root = _root_for(args["path"])
            rel = resolve_ws_path(args["path"], workspace, [str(w) for w in wss])[1]
            fp = root / rel
            if not fp.exists(): return {"error": f"File not found: {args['path']}"}
            content = fp.read_text(encoding="utf-8", errors="replace")
            return {"success": True, "path": args["path"], "content": content, "lines": len(content.splitlines())}
        elif name == "write_file":
            root = _root_for(args["path"])
            rel = resolve_ws_path(args["path"], workspace, [str(w) for w in wss])[1]
            fp = root / rel
            fp.parent.mkdir(parents=True, exist_ok=True)
            fp.write_text(args["content"], encoding="utf-8")
            return {"success": True, "path": args["path"], "message": f"Written ({len(args['content'])} chars)"}
        elif name == "edit_file":
            root = _root_for(args["path"])
            rel = resolve_ws_path(args["path"], workspace, [str(w) for w in wss])[1]
            fp = root / rel
            if not fp.exists(): return {"error": "File not found"}
            content = fp.read_text(encoding="utf-8", errors="replace")
            if args["old_text"] in content:
                content = content.replace(args["old_text"], args["new_text"], 1)
                fp.write_text(content, encoding="utf-8")
                return {"success": True, "message": "Edited"}
            return {"error": "Text not found"}
        elif name == "list_files":
            # list_files("") with multiple workspaces: list every attached workspace root
            raw = args.get("path", ".")
            if str(raw).strip() in ("", ".") and len(wss) > 1:
                tops = []
                for i, w in enumerate(wss, 1):
                    entry = {"workspace": str(w), "index": f"ws{i}", "items": []}
                    try:
                        for item in sorted(w.iterdir()):
                            if item.name.startswith("."): continue
                            entry["items"].append({"name": item.name, "type": "folder" if item.is_dir() else "file"})
                    except Exception as e:
                        entry["error"] = str(e)
                    tops.append(entry)
                return {"success": True, "workspaces": tops, "count": len(tops), "note": "Paths starting with wsN/ target that workspace. Use list_files('wsN') or list_files('wsN/sub') for details."}
            root = _root_for(raw)
            rel = resolve_ws_path(raw, workspace, [str(w) for w in wss])[1]
            dp = root / rel
            if not dp.exists(): return {"error": f"Directory not found: {raw}"}
            items = []
            for item in sorted(dp.iterdir()):
                if item.name.startswith("."): continue
                info = {"name": item.name, "type": "folder" if item.is_dir() else "file"}
                if item.is_file():
                    try: info["size"] = item.stat().st_size
                    except: info["size"] = 0
                items.append(info)
            return {"success": True, "items": items, "count": len(items)}
        elif name == "stop_process":
            # Kept for backwards compatibility with older chats — run_command(action="stop") is preferred.
            pid = args.get("pid")
            if not pid: return {"error": "pid required"}
            info = _bg_entry(pid=pid)
            ok, err = _kill_tree(pid, force=True)
            with _bg_lock:
                _bg_procs.pop(_bg_key(pid), None)
            if not ok and err:
                return {"error": f"Failed to stop pid {pid}: {err}"}
            return {"success": True, "message": f"Stopped pid {pid}" + (f" ({info.get('name')})" if info else "")}
        elif name == "run_command":
            action = str(args.get("action") or "").strip().lower()
            if not action:
                action = "start" if args.get("background") else "run"

            # ---- list: every process this server has started ----
            if action in ("list", "ps", "status"):
                procs = _bg_snapshot()
                return {"success": True, "action": "list", "processes": procs, "count": len(procs),
                        "message": "No background processes started yet." if not procs
                                   else f"{len(procs)} tracked process(es). Use action='log' with a name/pid to see output."}

            # ---- stop: kill a tracked process by pid or name ----
            if action in ("stop", "kill"):
                pid = args.get("pid")
                if pid is None and args.get("name"):
                    found = _bg_entry(name=args["name"])
                    pid = found.get("pid") if found else None
                if pid is None:
                    return {"error": "action='stop' needs a pid or a name of a process started with action='start'. Use action='list' to see them."}
                info = _bg_entry(pid=pid)
                ok, err = _kill_tree(pid, force=bool(args.get("force", True)))
                with _bg_lock:
                    _bg_procs.pop(_bg_key(pid), None)
                if not ok and err:
                    return {"error": f"Failed to stop pid {pid}: {err}"}
                label = info.get("name") if info else None
                return {"success": True, "action": "stop", "pid": pid, "name": label,
                        "message": f"Stopped pid {pid}" + (f" ('{label}')" if label else "") +"."}

            # ---- log: tail a process log, optionally sleeping until output appears ----
            if action in ("log", "logs", "tail", "check"):
                info = _bg_entry(pid=args.get("pid"), name=args.get("name"))
                if not info:
                    return {"error": "Unknown process — use action='list' to see tracked processes, then pass its pid or name."}
                log_path, bpid = info.get("log_file"), info.get("pid")
                wait_for = args.get("wait_for")
                try:
                    wait_timeout = min(max(float(args.get("wait_timeout") or 0), 0), 120)
                except Exception:
                    wait_timeout = 0
                deadline, output, matched = time.time() + wait_timeout, "", False
                while True:
                    output = _log_tail(log_path, args.get("lines", 40))
                    if not wait_for:
                        break
                    with contextlib.suppress(re.error):
                        matched = bool(re.search(str(wait_for), output))
                    if matched:
                        break
                    if time.time() >= deadline:
                        break
                    time.sleep(0.5)
                status = _bg_status(bpid)
                msg = f"Log of '{info.get('name')}' (pid {bpid}, {status})."
                if wait_for:
                    msg += " Found the expected output." if matched else f" '{wait_for}' did not appear within {wait_timeout}s."
                return {"success": True, "action": "log", "pid": bpid, "name": info.get("name"),
                        "status": status, "running": status == "running", "log_file": log_path,
                        "output": output or "(no output yet)", "lines": args.get("lines", 40),
                        "wait_for": wait_for, "matched": matched if wait_for else None,
                        "timed_out": bool(wait_for) and not matched, "message": msg}

            if action in ("run", "start", "background", "bg") and wp is None:
                return {"error": "No workspace selected — tell the user to add one via Workspaces → + Add in the sidebar, then retry"}
            if not args.get("command"):
                return {"error": "'command' is required for action='run'/'start'. Other actions: 'list', 'log', 'stop'."}

            # ---- start: launch detached, return immediately ----
            if action in ("start", "background", "bg"):
                info = _start_bg(args["command"], args.get("name"), str(wp) if wp else None)
                try:
                    wait = min(max(float(args.get("wait") or 0), 0), 60)
                except Exception:
                    wait = 0
                initial = ""
                if wait > 0:
                    time.sleep(wait)
                    initial = _log_tail(info["log_file"], args.get("lines", 40))
                status = _bg_status(info["pid"])
                return {"success": True, "action": "start", "background": True, "pid": info["pid"],
                        "name": info["name"], "log_file": info["log_file"], "status": status,
                        "running": status == "running", "output": initial,
                        "message": (f"Started '{info['name']}' in background (pid {info['pid']}, {status}). "
                                    f"It keeps running even if this app restarts. "
                                    f"Check it any time with run_command(action='log', name='{info['name']}', wait_for='ready|listening|started', wait_timeout=30); "
                                    f"see all with action='list'; stop it with action='stop', name='{info['name']}'.")}

            # ---- run: blocking, with a real timeout that doesn't hang the chat ----
            try:
                timeout = min(max(float(args.get("timeout") or 120), 1), 600)
            except Exception:
                timeout = 120
            popen_kwargs = dict(shell=True, cwd=str(wp), stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                stdin=subprocess.DEVNULL, text=True, encoding="utf-8", errors="replace")
            if os.name == "nt":
                popen_kwargs["creationflags"] = 0x00000200  # CREATE_NEW_PROCESS_GROUP, so we can kill the tree
            else:
                popen_kwargs["start_new_session"] = True
            proc = subprocess.Popen(args["command"], **popen_kwargs)
            try:
                out, err = proc.communicate(timeout=timeout)
            except subprocess.TimeoutExpired:
                # Always stop the command we started: a still-running child would keep
                # writing into our pipes and block the stream. Long-running work belongs
                # in action='start', which returns immediately and logs to a file.
                _kill_tree(proc.pid, force=True)
                out, err = "", ""
                with contextlib.suppress(Exception):
                    out, err = proc.communicate(timeout=5)
                with contextlib.suppress(Exception):
                    if proc.poll() is None:
                        proc.kill()
                return {"success": False, "action": "run", "timed_out": True, "timeout": timeout,
                        "killed": True, "pid": proc.pid, "exit_code": proc.poll(),
                        "stdout": (out or "")[:50000], "stderr": (err or "")[:10000],
                        "message": (f"Command exceeded its {timeout}s timeout and was stopped. "
                                    "For long-running processes use action='start' (returns a pid + log file) "
                                    "and then action='log' to watch it, or raise `timeout` (max 600s).")}
            return {"success": proc.returncode == 0, "action": "run", "ok": proc.returncode == 0,
                    "stdout": (out or "")[:50000], "stderr": (err or "")[:10000], "exit_code": proc.returncode}
        elif name == "delete_file":
            root = _root_for(args["path"])
            rel = resolve_ws_path(args["path"], workspace, [str(w) for w in wss])[1]
            fp = root / rel
            if not fp.exists(): return {"error": "Not found"}
            if fp.is_file(): fp.unlink()
            else: shutil.rmtree(str(fp))
            return {"success": True, "message": "Deleted"}
        elif name == "search_files":
            pattern = args["pattern"]
            raw = args.get("path", ".") or "."
            root = _root_for(raw)
            rel = resolve_ws_path(raw, workspace, [str(w) for w in wss])[1]
            sp = root / rel
            results, count = [], 0
            for froot, dirs, files in os.walk(str(sp)):
                dirs[:] = [d for d in dirs if not d.startswith(".") and d != "node_modules"]
                for fname in files:
                    fpath = os.path.join(froot, fname)
                    try:
                        with open(fpath, "r", encoding="utf-8", errors="replace") as f:
                            for ln, line in enumerate(f, 1):
                                if pattern.lower() in line.lower():
                                    results.append({"file": os.path.relpath(fpath, str(root)), "line": ln, "content": line.strip()[:200]})
                                    count += 1
                                    if count > 100: break
                    except: pass
                if count > 100: break
            return {"success": True, "matches": results, "total": len(results)}
        elif name == "web_search":
            return do_web_search(args.get("query", ""))
        elif name == "deep_research":
            return do_deep_research(args.get("query", ""), args.get("depth", "standard"))
        elif name == "fetch_page":
            return do_fetch_page(args.get("url", ""))
        elif name == "view_research":
            rid = args.get("research_id", "")
            data = load_research(rid)
            if data:
                return {"success": True, "research": data}
            return {"error": f"Research '{rid}' not found"}
        elif name == "list_research":
            return {"success": True, "research_list": list_research()}
        elif name == "spawn_agent":
            return do_spawn_agent(args)
        elif name == "webgl_list_sessions":
            with webgl_lock:
                result = []
                for url, data in webgl_sessions.items():
                    result.append({
                        "url": url,
                        "title": data.get("title", ""),
                        "canvas": data.get("canvas"),
                        "shader_count": len(data.get("shaders", [])),
                        "texture_count": len(data.get("textures", [])),
                        "error_count": len(data.get("errors", [])),
                        "draw_call_count": len(data.get("drawCalls", [])),
                        "frame_count": data.get("frameCount", 0),
                        "last_update": data.get("timestamp", 0),
                    })
                return {"success": True, "sessions": result, "count": len(result)}
        elif name == "webgl_get_state":
            url = args.get("url", "")
            with webgl_lock:
                data = webgl_sessions.get(url)
                if not data:
                    return {"error": f"No WebGL session for '{url}'. Use webgl_list_sessions to see connected pages."}
                return {"success": True, **data}
        elif name == "webgl_get_shaders":
            url = args.get("url", "")
            shader_index = args.get("shader_index")
            with webgl_lock:
                data = webgl_sessions.get(url)
                if not data:
                    return {"error": f"No WebGL session for '{url}'"}
                shaders = data.get("shaders", [])
                if shader_index is not None:
                    if 0 <= shader_index < len(shaders):
                        return {"success": True, "shader": shaders[shader_index]}
                    return {"error": f"Shader index {shader_index} out of range (0-{len(shaders)-1})"}
                return {"success": True, "shaders": shaders, "count": len(shaders)}
        elif name == "webgl_get_errors":
            url = args.get("url", "")
            with webgl_lock:
                data = webgl_sessions.get(url)
                if not data:
                    return {"error": f"No WebGL session for '{url}'"}
                return {"success": True, "errors": data.get("errors", []), "count": len(data.get("errors", []))}
        elif name == "webgl_get_draw_calls":
            url = args.get("url", "")
            count = args.get("count", 50)
            with webgl_lock:
                data = webgl_sessions.get(url)
                if not data:
                    return {"error": f"No WebGL session for '{url}'"}
                calls = data.get("drawCalls", [])
                return {"success": True, "draw_calls": calls[-count:], "total": len(calls)}
        elif name == "webgl_get_textures":
            url = args.get("url", "")
            with webgl_lock:
                data = webgl_sessions.get(url)
                if not data:
                    return {"error": f"No WebGL session for '{url}'"}
                return {"success": True, "textures": data.get("textures", []), "count": len(data.get("textures", []))}
        elif name == "webgl_get_injector":
            return {"success": True, "script": get_webgl_injector_script()}
        elif name in ("vps_status", "vps_run", "vps_list_files", "vps_read_file", "vps_write_file", "vps_edit_file", "vps_download", "vps_upload"):
            conn = _vps_active_conn()
            if name == "vps_status":
                conns = [{"id": c["id"], "name": c["name"], "host": c["host"], "port": c["port"], "username": c["username"], "active": c["id"] == config.get("active_vps")} for c in _vps_connections()]
                if not conns:
                    return {"success": False, "error": "No VPS connections configured. Tell the user to open Settings → VPS and add the server (IP, username, password)."}
                active = _vps_active_conn()
                return {"success": True, "connections": conns, "active": {"id": active["id"], "host": active["host"], "username": active["username"]} if active else None}
            if not conn:
                return {"error": "No active VPS — tell the user to open Settings → VPS, add their server (IP, username, password) and set it active."}
            try:
                if name == "vps_run":
                    return _vps_sanitize_out(vps_run_command(conn, args["command"], args.get("timeout", 60)))
                if name == "vps_list_files":
                    return _vps_sanitize_out(vps_list_dir(conn, args.get("path", ".")))
                if name == "vps_read_file":
                    return _vps_sanitize_out(vps_read_file(conn, args["path"]))
                if name == "vps_write_file":
                    return _vps_sanitize_out(vps_write_file(conn, args["path"], args["content"]))
                if name == "vps_edit_file":
                    return _vps_sanitize_out(vps_edit_file(conn, args["path"], args["old_text"], args["new_text"]))
                if name == "vps_download":
                    ws = config.get("active_workspace")
                    if not ws: return {"error": "No active workspace to download into — ask the user to add one."}
                    local = str(Path(ws) / Path(args["path"]).name)
                    return _vps_sanitize_out(vps_download_file(conn, args["path"], local))
                if name == "vps_upload":
                    root, rel = resolve_ws_path(args["path"], workspace, [str(w) for w in wss])
                    lp = Path(root) / rel
                    if not lp.exists(): return {"error": f"File not found in workspace: {args['path']}"}
                    remote = args.get("remote_path") or f"~/{lp.name}"
                    if remote.startswith("~/"):
                        home = vps_run_command(conn, "echo $HOME").get("stdout", "").strip() or "/root"
                        remote = home + remote[1:]
                    return _vps_sanitize_out(vps_upload_file(conn, str(lp), remote))
            except Exception as e:
                _vps_close(conn["id"])
                msg = str(e)
                if conn.get("password"): msg = msg.replace(conn["password"], "***")
                return {"error": f"VPS error (connection reset — it will reconnect automatically next time): {msg}"}
        else:
            return {"error": f"Unknown tool: {name}"}
    except Exception as e:
        return {"error": f"Tool error: {str(e)}"}

# ==================== WEBGL DEBUGGER ====================
def get_webgl_injector_script():
    """Generate the WebGL debugger injection script"""
    return """// WebGL Debugger - Paste this in DevTools console on any WebGL page
(function(){
  if(window.__WEBGL_DEBUGGER__){console.log('WebGL Debugger already active');return;}
  window.__WEBGL_DEBUGGER__=true;
  const DASH=location.protocol+'//'+location.hostname+':5000';
  const STATE={shaders:[],programs:[],textures:[],drawCalls:[],errors:[],frameCount:0,webgl:null,canvas:null};
  let pollInterval=null;
  
  function init(){
    const canvases=document.querySelectorAll('canvas');
    canvases.forEach(c=>{
      const gl=c.getContext('webgl2')||c.getContext('webgl')||c.getContext('experimental-webgl');
      if(gl){
        STATE.webgl=gl;
        STATE.canvas=c;
        hookWebGL(gl,c);
        console.log('[WebGL Debugger] Hooked canvas:',c.width+'x'+c.height);
        reportState();
      }
    });
    // Watch for new canvases
    const observer=new MutationObserver(m=>{
      document.querySelectorAll('canvas').forEach(c=>{
        if(!c.__hooked){
          const gl=c.getContext('webgl2')||c.getContext('webgl')||c.getContext('experimental-webgl');
          if(gl){hookWebGL(gl,c);c.__hooked=true;console.log('[WebGL Debugger] New canvas hooked');}
        }
      });
    });
    observer.observe(document.body,{childList:true,subtree:true});
    pollInterval=setInterval(reportState,2000);
  }
  
  function hookWebGL(gl,canvas){
    const origCreateShader=gl.createShader.bind(gl);
    const origShaderSource=gl.shaderSource.bind(gl);
    const origCompileShader=gl.compileShader.bind(gl);
    const origCreateProgram=gl.createProgram.bind(gl);
    const origLinkProgram=gl.linkProgram.bind(gl);
    const origDrawArrays=gl.drawArrays.bind(gl);
    const origDrawElements=gl.drawElements.bind(gl);
    const origTexImage2D=gl.texImage2D.bind(gl);
    
    gl.createShader=function(type){
      const s=origCreateShader(type);
      if(s)s.__debugType=type===gl.VERTEX_SHADER?'vertex':'fragment';
      return s;
    };
    
    gl.shaderSource=function(shader,src){
      shader.__debugSource=src;
      return origShaderSource(shader,src);
    };
    
    gl.compileShader=function(shader){
      origCompileShader(shader);
      const success=gl.getShaderParameter(shader,gl.COMPILE_STATUS);
      const log=gl.getShaderInfoLog(shader);
      STATE.shaders.push({type:shader.__debugType||'unknown',success:!!success,log:log||'',source:(shader.__debugSource||'').substring(0,2000),id:STATE.shaders.length});
      if(!success){
        STATE.errors.push({type:'shader_compile',log:log,shaderType:shader.__debugType});
        console.error('[WebGL Debugger] Shader compile error:',shader.__debugType,log);
      }
    };
    
    gl.createProgram=function(){
      const p=origCreateProgram();
      if(p)p.__debugId=STATE.programs.length;
      return p;
    };
    
    gl.linkProgram=function(program){
      origLinkProgram(program);
      const success=gl.getProgramParameter(program,gl.LINK_STATUS);
      const log=gl.getProgramInfoLog(program);
      STATE.programs.push({id:program.__debugId||STATE.programs.length,success:!!success,log:log||'',uniforms:[],attributes:[]});
      if(!success){
        STATE.errors.push({type:'program_link',log:log});
        console.error('[WebGL Debugger] Program link error:',log);
      }
    };
    
    gl.drawArrays=function(mode,first,count){
      STATE.drawCalls.push({type:'drawArrays',mode,first,count,frame:STATE.frameCount,time:performance.now()});
      if(STATE.drawCalls.length>500)STATE.drawCalls.shift();
      return origDrawArrays(mode,first,count);
    };
    
    gl.drawElements=function(mode,count,type,offset){
      STATE.drawCalls.push({type:'drawElements',mode,count,type,offset,frame:STATE.frameCount,time:performance.now()});
      if(STATE.drawCalls.length>500)STATE.drawCalls.shift();
      return origDrawElements(mode,count,type,offset);
    };
    
    gl.texImage2D=function(){
      const args=Array.from(arguments);
      STATE.textures.push({width:args[3]||0,height:args[4]||0,format:args[2]||'unknown',frame:STATE.frameCount,id:STATE.textures.length});
      if(STATE.textures.length>200)STATE.textures.shift();
      return origTexImage2D.apply(gl,arguments);
    };
  }
  
  function reportState(){
    STATE.frameCount++;
    const gl=STATE.webgl;
    const data={
      url:location.href,
      title:document.title,
      canvas:STATE.canvas?{width:STATE.canvas.width,height:STATE.canvas.height}:null,
      glInfo:gl?{
        vendor:gl.getParameter(gl.VENDOR),
        renderer:gl.getParameter(gl.RENDERER),
        version:gl.getParameter(gl.VERSION),
        shadingLang:gl.getParameter(gl.SHADING_LANGUAGE_VERSION),
        maxTextureSize:gl.getParameter(gl.MAX_TEXTURE_SIZE),
        maxViewportDims:gl.getParameter(gl.MAX_VIEWPORT_DIMS),
      }:null,
      shaders:STATE.shaders.slice(-10),
      programs:STATE.programs.slice(-10),
      textures:STATE.textures.slice(-20),
      drawCalls:STATE.drawCalls.slice(-50),
      errors:STATE.errors.slice(-20),
      frameCount:STATE.frameCount,
      timestamp:Date.now()
    };
    fetch(DASH+'/api/webgl/data',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}).catch(e=>console.warn('[WebGL Debugger] Report failed:',e));
  }
  
  window.__WEBGL_DEBUGGER_REPORT__=reportState;
  init();
  console.log('[WebGL Debugger] Active. Reporting to',DASH);
})();"""

# ==================== WEB SEARCH ====================
def do_web_search(query):
    results = _search_google(query)
    if results:
        return {"success": True, "query": query, "results": results, "total": len(results), "engine": "google"}
    results = _search_ddg(query)
    if results:
        return {"success": True, "query": query, "results": results, "total": len(results), "engine": "duckduckgo"}
    results = _search_bing(query)
    if results:
        return {"success": True, "query": query, "results": results, "total": len(results), "engine": "bing"}
    return {"success": True, "query": query, "results": [], "message": "No results from any engine"}

def _search_google(query):
    try:
        url = f"https://www.google.com/search?q={quote_plus(query)}&num=10&hl=en"
        resp = http_requests.get(url, headers=SEARCH_HEADERS, timeout=15)
        if resp.status_code != 200: return None
        html = resp.text
        results = []
        # Try multiple patterns
        patterns = [
            r'<a href="/url\?q=(https?://[^"&]+)[^"]*"[^>]*><h3[^>]*>(.*?)</h3>',
            r'<a href="(https?://[^"]+)"[^>]*data-ved[^>]*><h3[^>]*>(.*?)</h3>',
        ]
        for pattern in patterns:
            matches = re.findall(pattern, html, re.DOTALL)
            for url_match, title in matches[:10]:
                if 'google.com' in url_match: continue
                clean_title = re.sub(r'<[^>]+>', '', title).strip()
                results.append({"title": clean_title, "url": unquote(url_match), "snippet": ""})
            if results: break
        
        # Get snippets
        snippet_patterns = [
            r'<div class="VwiC3b[^"]*"[^>]*>(.*?)</div>',
            r'<span class="aCOpRe[^"]*"[^>]*>(.*?)</span>',
        ]
        snippets = []
        for sp in snippet_patterns:
            snippets = [re.sub(r'<[^>]+>', '', s).strip() for s in re.findall(sp, html, re.DOTALL)]
            if snippets: break
        
        for i, r in enumerate(results):
            if i < len(snippets):
                r["snippet"] = snippets[i]
        
        return results if results else None
    except: return None

def _search_ddg(query):
    try:
        resp = http_requests.get("https://html.duckduckgo.com/html/", params={"q": query}, headers=SEARCH_HEADERS, timeout=15)
        if resp.status_code != 200: return None
        html = resp.text
        results = []
        titles = re.findall(r'<a rel="nofollow" class="result__a" href="([^"]+)"[^>]*>(.*?)</a>', html, re.DOTALL)
        snippets = re.findall(r'<a class="result__snippet"[^>]*>(.*?)</a>', html, re.DOTALL)
        for i, (url, title) in enumerate(titles[:10]):
            clean_title = re.sub(r'<[^>]+>', '', title).strip()
            clean_snippet = re.sub(r'<[^>]+>', '', snippets[i]).strip() if i < len(snippets) else ""
            if "//duckduckgo.com/l/?" in url:
                uddg = re.search(r'uddg=([^&]+)', url)
                if uddg: url = unquote(uddg.group(1))
            results.append({"title": clean_title, "url": url, "snippet": clean_snippet})
        return results if results else None
    except: return None

def _search_bing(query):
    try:
        url = f"https://www.bing.com/search?q={quote_plus(query)}&count=10"
        resp = http_requests.get(url, headers=SEARCH_HEADERS, timeout=15)
        if resp.status_code != 200: return None
        html = resp.text
        results = []
        matches = re.findall(r'<li class="b_algo"[^>]*>.*?<a href="([^"]+)"[^>]*>(.*?)</a>.*?<p[^>]*>(.*?)</p>', html, re.DOTALL)
        for url_match, title, snippet in matches[:10]:
            clean_title = re.sub(r'<[^>]+>', '', title).strip()
            clean_snippet = re.sub(r'<[^>]+>', '', snippet).strip()
            results.append({"title": clean_title, "url": url_match, "snippet": clean_snippet})
        return results if results else None
    except: return None

# ==================== FETCH PAGE ====================
def do_fetch_page(url):
    try:
        resp = http_requests.get(url, headers=SEARCH_HEADERS, timeout=20)
        if resp.status_code != 200: return {"error": f"HTTP {resp.status_code}"}
        html = resp.text
        for tag in ['script', 'style', 'nav', 'footer', 'header', 'aside']:
            html = re.sub(f'<{tag}[^>]*>.*?</{tag}>', '', html, flags=re.DOTALL | re.IGNORECASE)
        title_match = re.search(r'<title[^>]*>(.*?)</title>', html, re.DOTALL | re.IGNORECASE)
        title = re.sub(r'<[^>]+>', '', title_match.group(1)).strip() if title_match else ""
        content_html = html
        for sel in ['article', 'main', 'div[role="main"]']:
            match = re.search(f'<{sel}[^>]*>(.*?)</{sel}>', html, re.DOTALL | re.IGNORECASE)
            if match: content_html = match.group(1); break
        text = re.sub(r'<br\s*/?>', '\n', content_html)
        text = re.sub(r'</p>', '\n\n', text)
        text = re.sub(r'<[^>]+>', '', text)
        text = re.sub(r'&nbsp;', ' ', text)
        text = re.sub(r'&amp;', '&', text)
        text = re.sub(r'&lt;', '<', text)
        text = re.sub(r'&gt;', '>', text)
        text = re.sub(r'\n{3,}', '\n\n', text)
        text = '\n'.join(line.strip() for line in text.split('\n') if line.strip())
        if len(text) > 8000: text = text[:8000] + "\n\n...(truncated)"
        return {"success": True, "url": url, "title": title, "content": text, "chars": len(text)}
    except Exception as e:
        return {"error": f"Fetch failed: {str(e)}"}

# ==================== DEEP RESEARCH ====================
def do_deep_research(query, depth="standard"):
    sub_q_count = {"quick": 3, "standard": 5, "deep": 7}.get(depth, 5)
    research_id = f"research_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    
    print(f"[RESEARCH] Starting: '{query[:60]}...' depth={depth} id={research_id}")
    
    # Step 1: Generate sub-questions
    sub_questions = _generate_subquestions(query, sub_q_count)
    print(f"[RESEARCH] Generated {len(sub_questions)} sub-questions")
    
    # Step 2: Search for each sub-question and fetch content
    all_results = []
    for i, sq in enumerate(sub_questions):
        print(f"[RESEARCH] Searching {i+1}/{len(sub_questions)}: {sq[:50]}...")
        search_result = do_web_search(sq)
        search_results = search_result.get("results", [])
        
        # Fetch top 2 pages for each sub-question
        for r in search_results[:2]:
            r["sub_question"] = sq
            page = do_fetch_page(r["url"])
            if page.get("success") and page.get("content"):
                r["page_content"] = page["content"][:3000]
                r["page_title"] = page.get("title", "")
        
        all_results.extend(search_results[:3])
    
    print(f"[RESEARCH] Collected {len(all_results)} results")
    
    # Step 3: Synthesize with selected research agent
    synthesis = _synthesize_research(query, sub_questions, all_results)
    
    # Build report
    report = synthesis if synthesis else _build_fallback_report(query, sub_questions, all_results)
    
    # Save research to disk
    research_data = {
        "id": research_id,
        "query": query,
        "depth": depth,
        "sub_questions": sub_questions,
        "results": all_results[:15],
        "synthesis": synthesis or "",
        "report": report,
        "total_sources": len(set(r.get("url", "") for r in all_results)),
        "created": datetime.now().isoformat(),
    }
    save_research(research_id, research_data)
    print(f"[RESEARCH] Saved: {research_id}")
    
    return {
        "success": True,
        "research_id": research_id,
        "query": query,
        "depth": depth,
        "sub_questions": sub_questions,
        "total_sources": research_data["total_sources"],
        "synthesis": synthesis or "Could not synthesize",
        "report": report,
        "message": f"Research saved as {research_id}. Use view_research('{research_id}') to recall later."
    }

def _generate_subquestions(query, count):
    gemini_keys = config.get("gemini_research_keys", [])
    
    # Try Gemini first
    if gemini_keys:
        prompt = f"""Generate {count} specific sub-questions to research: "{query}"

Rules:
- Each sub-question should be searchable via Google
- Cover different angles: what, how, features, comparisons, use cases
- Return ONLY a JSON array of strings
- Example: ["What is X?", "How does X work?"]"""
        
        for i, key in enumerate(gemini_keys):
            try:
                url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={key}"
                payload = {"contents": [{"parts": [{"text": prompt}]}], "generationConfig": {"temperature": 0.7, "maxOutputTokens": 1024}}
                resp = http_requests.post(url, json=payload, headers={"Content-Type": "application/json"}, timeout=30)
                if resp.status_code != 200: continue
                text = resp.json().get("candidates", [{}])[0].get("content", {}).get("parts", [{}])[0].get("text", "")
                match = re.search(r'\[[\s\S]*?\]', text)
                if match:
                    questions = json.loads(match.group())
                    if isinstance(questions, list) and len(questions) >= 2:
                        return [q for q in questions if isinstance(q, str)][:count]
            except: continue
    
    # Template fallback
    topic = re.sub(r'^(what is|how does|tell me about|explain|research|find|search for|about)\s+', '', query.lower()).strip('?.,!')
    return [
        f"What is {topic}?",
        f"How does {topic} work?",
        f"What are the key features of {topic}?",
        f"What are advantages and disadvantages of {topic}?",
        f"What are common use cases of {topic}?",
        f"How does {topic} compare to alternatives?",
        f"What are latest developments in {topic}?",
    ][:count]

def _synthesize_research(query, sub_questions, results):
    """Use the selected research agent provider/key to synthesize"""
    # Get research keys
    gemini_keys = config.get("gemini_research_keys", [])
    provider = config.get("research_agent_provider", "gemini")
    key_index = config.get("research_agent_key_index", 0)
    
    # Build context
    context_parts = []
    for i, r in enumerate(results[:12]):
        part = f"[{i+1}] {r.get('title', 'No title')}\nURL: {r.get('url', '')}\n"
        if r.get('snippet'): part += f"Snippet: {r['snippet']}\n"
        if r.get('page_content'): part += f"Content: {r['page_content'][:1500]}\n"
        context_parts.append(part)
    context = "\n---\n".join(context_parts)
    
    prompt = f"""Synthesize these search results into a comprehensive answer.

Question: "{query}"
Sub-questions researched: {chr(10).join(f'- {sq}' for sq in sub_questions)}

Results:
{context}

Write a comprehensive markdown answer (300-600 words):
- Use headers (## for sections)
- Cite sources as [1], [2] etc
- Include Sources section at end with URLs
- Be factual, specific
- If results conflict, mention both perspectives"""

    # Try Gemini research keys first
    if provider == "gemini" or not gemini_keys:
        keys_to_try = gemini_keys[key_index:] + gemini_keys[:key_index] if gemini_keys else []
        for i, key in enumerate(keys_to_try):
            try:
                url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={key}"
                payload = {"contents": [{"parts": [{"text": prompt}]}], "generationConfig": {"temperature": 0.5, "maxOutputTokens": 4096}}
                resp = http_requests.post(url, json=payload, headers={"Content-Type": "application/json"}, timeout=60)
                if resp.status_code == 200:
                    text = resp.json().get("candidates", [{}])[0].get("content", {}).get("parts", [{}])[0].get("text", "")
                    if text and len(text) > 100:
                        return text
            except: continue
    
    # Try main provider keys as fallback
    for pk, pv in config["providers"].items():
        if not pv.get("enabled"): continue
        keys = pv.get("api_keys", [])
        if not keys: continue
        api_key = keys[0]["key"]
        base_url = pv["base_url"].rstrip("/")
        model = pv["model"]
        try:
            messages = [{"role": "user", "content": prompt}]
            ptype = get_provider_type(pk, pv)
            if ptype == "anthropic":
                url = f"{base_url}/messages"
                headers = {"Content-Type": "application/json", "x-api-key": api_key, "anthropic-version": "2023-06-01"}
                resp = http_requests.post(url, headers=headers, json={"model": model, "max_tokens": 4096, "messages": messages}, timeout=60)
                if resp.status_code == 200:
                    text = resp.json()["content"][0]["text"]
                    if len(text) > 100: return text
            elif ptype == "gemini":
                url = f"{base_url}/models/{model}:generateContent?key={api_key}"
                resp = http_requests.post(url, headers={"Content-Type": "application/json"}, json={"contents": [{"parts": [{"text": prompt}]}]}, timeout=60)
                if resp.status_code == 200:
                    text = resp.json()["candidates"][0]["content"]["parts"][0]["text"]
                    if len(text) > 100: return text
            else:
                url = chat_completions_url(base_url)
                headers = openai_headers(api_key)
                resp = http_requests.post(url, headers=headers, json={"model": model, "messages": messages, "max_tokens": 4096}, timeout=60)
                if resp.status_code == 200:
                    text = resp.json()["choices"][0]["message"]["content"]
                    if len(text) > 100: return text
        except: continue
    
    return None

def _build_fallback_report(query, sub_questions, results):
    report = f"# Research: {query}\n\n"
    report += f"Researched {len(sub_questions)} sub-questions, {len(results)} sources.\n\n"
    by_sq = {}
    for r in results:
        sq = r.get("sub_question", "General")
        by_sq.setdefault(sq, []).append(r)
    for sq, sq_results in by_sq.items():
        report += f"## {sq}\n\n"
        for r in sq_results[:3]:
            if r.get("title"):
                report += f"- **{r['title']}**: {r.get('snippet', 'No description')}\n"
            if r.get("page_content"):
                report += f"  > {r['page_content'][:300]}...\n"
        report += "\n## Sources\n\n"
    seen = set()
    idx = 1
    for r in results:
        url = r.get("url", "")
        if url and url not in seen:
            seen.add(url)
            report += f"[{idx}] [{r.get('title', 'Source')}]({url})\n"
            idx += 1
    return report

# ==================== MULTI-AGENT ====================
AGENT_ROLES = {
    "web_researcher": "You are a web research specialist. Analyze the given information and provide a comprehensive, well-structured answer. Cite sources.",
    # Code reviewer works purely from the code pasted into the task - it has NO file/workspace access.
    "code_reviewer": "You are a code review expert. You receive code or diffs directly inside the task text - you have NO access to the filesystem, workspace, or tools. Review ONLY the code provided in the task: analyze it for bugs, security issues, performance problems, and style. Give specific, actionable feedback with line references to the provided snippet. Never claim you cannot access files; if context is missing, say what to paste.",
    "file_analyzer": "You analyze file contents and understand structure, dependencies, relationships. The file contents are provided directly in the task text.",
    "debugger": "You are a debugging specialist. Analyze the errors, stack traces, and code provided in the task text and identify root causes.",
    "general": "You are a helpful specialist. Complete the task thoroughly using only the information provided in the task text."
}

def do_spawn_agent(args):
    task = args.get("task", "")
    role = args.get("role", "general")
    provider_key = args.get("provider", "")
    key_index = args.get("key_index", 0)
    
    if not task: return {"error": "No task specified"}
    
    # If provider matches a research key pattern
    gemini_keys = config.get("gemini_research_keys", [])
    
    if not provider_key:
        provider_key = config.get("research_agent_provider", config.get("active_provider", "abliteration"))
    
    # Check if they want a research Gemini key
    if provider_key == "gemini_research" and gemini_keys:
        key_idx = min(key_index, len(gemini_keys) - 1)
        api_key = gemini_keys[key_idx]
        base_url = "https://generativelanguage.googleapis.com/v1beta"
        model = "gemini-2.5-flash"
    elif provider_key in config["providers"]:
        provider = config["providers"][provider_key]
        keys = provider.get("api_keys", [])
        if not keys: return {"error": f"No keys for '{provider_key}'"}
        key_idx = min(key_index, len(keys) - 1)
        api_key = keys[key_idx]["key"]
        base_url = provider["base_url"].rstrip("/")
        model = provider["model"]
    else:
        return {"error": f"Provider '{provider_key}' not found"}
    
    system_prompt = AGENT_ROLES.get(role, AGENT_ROLES["general"])
    messages = [{"role": "system", "content": system_prompt}, {"role": "user", "content": task}]
    ptype = get_provider_type(provider_key, provider if provider_key in config["providers"] else None)
    
    try:
        # ---- Key failover: try every key of the chosen provider before failing ----
        def try_agent_call(api_key):
            nonlocal resp_ok, result_text, err_text
            resp_ok, result_text, err_text = False, None, None
            try:
                if ptype == "gemini" or provider_key == "gemini_research":
                    url = f"{base_url}/models/{model}:generateContent?key={api_key}"
                    r = http_requests.post(url, headers={"Content-Type": "application/json"}, json={"contents": [{"parts": [{"text": task}]}], "generationConfig": {"maxOutputTokens": 4096}}, timeout=60)
                    if r.status_code != 200:
                        err_text = f"HTTP {r.status_code}: {r.text[:200]}"
                        return
                    result_text = r.json()["candidates"][0]["content"]["parts"][0]["text"]
                elif provider_key == "anthropic" or ptype == "anthropic":
                    url = f"{base_url}/messages"
                    hdrs = {"Content-Type": "application/json", "x-api-key": api_key, "anthropic-version": "2023-06-01"}
                    r = http_requests.post(url, headers=hdrs, json={"model": model, "max_tokens": 4096, "messages": messages}, timeout=60)
                    if r.status_code != 200:
                        err_text = f"HTTP {r.status_code}: {r.text[:200]}"
                        return
                    result_text = r.json()["content"][0]["text"]
                else:
                    url = chat_completions_url(base_url)
                    hdrs = openai_headers(api_key)
                    r = http_requests.post(url, headers=hdrs, json={"model": model, "messages": messages, "max_tokens": 4096}, timeout=60)
                    if r.status_code != 200:
                        err_text = f"HTTP {r.status_code}: {r.text[:200]}"
                        return
                    result_text = r.json()["choices"][0]["message"]["content"]
                resp_ok = True
            except Exception as e:
                err_text = str(e)
        resp_ok, result_text, err_text = False, None, None
        # Determine which keys belong to this provider (research keys count as gemini keys)
        if provider_key == "gemini_research":
            agent_keys = list(gemini_keys) if gemini_keys else []
        elif provider_key == "gemini":
            # Prefer the gemini provider's own keys, fall back to research keys
            agent_keys = [k["key"] for k in provider.get("api_keys", [])]
            if not agent_keys:
                agent_keys = list(gemini_keys)
        else:
            agent_keys = [k["key"] for k in provider.get("api_keys", [])]
        if not agent_keys:
            return {"error": f"No keys available for '{provider_key}'"}
        for ai, ak in enumerate(agent_keys):
            try_agent_call(ak)
            if resp_ok:
                break
            if ai < len(agent_keys) - 1:
                print(f"[AGENT] {provider_key} key #{ai+1} failed ({str(err_text)[:100]}), failing over...")
        if not resp_ok:
            return {"error": f"Agent failed on all {len(agent_keys)} key(s). Last error: {err_text}"}
        
        return {"success": True, "role": role, "provider": provider_key, "response": result_text}
    except Exception as e:
        return {"error": f"Agent failed: {str(e)}"}

# ==================== KEY MANAGEMENT ====================
def get_api_key(provider_key, key_name=None):
    provider = config["providers"].get(provider_key)
    if not provider: return None, f"Provider '{provider_key}' not found"
    keys = provider.get("api_keys", [])
    if not keys:
        # Custom OpenAI-compatible endpoints (Ollama, LM Studio, private
        # gateways like the user's snippet) often need no API key at all.
        if get_provider_type(provider_key, provider) == "openai":
            return "", None
        return None, f"No API keys for {provider.get('name', provider_key)}"
    if key_name:
        for k in keys:
            if k["name"] == key_name: return k["key"], None
    active_name = config.get("active_api_key_name", {}).get(provider_key, "")
    if active_name:
        for k in keys:
            if k["name"] == active_name: return k["key"], None
    return keys[0]["key"], None

def get_api_key_with_index(provider_key, key_name=None):
    """Like get_api_key but also returns the index of the key used (for failover)."""
    provider = config["providers"].get(provider_key)
    if not provider: return None, f"Provider '{provider_key}' not found", 0
    keys = provider.get("api_keys", [])
    if not keys:
        if get_provider_type(provider_key, provider) == "openai":
            return "", None, 0
        return None, f"No API keys for {provider.get('name', provider_key)}", 0
    if key_name:
        for i, k in enumerate(keys):
            if k["name"] == key_name: return k["key"], None, i
    active_name = config.get("active_api_key_name", {}).get(provider_key, "")
    if active_name:
        for i, k in enumerate(keys):
            if k["name"] == active_name: return k["key"], None, i
    return keys[0]["key"], None, 0

def test_api_key(provider_key, api_key):
    provider = config["providers"].get(provider_key)
    if not provider: return {"valid": False, "error": "Provider not found"}
    base_url = provider["base_url"].rstrip("/")
    model = provider["model"]
    ptype = get_provider_type(provider_key, provider)
    try:
        if ptype == "anthropic":
            url = f"{base_url}/messages"
            headers = {"Content-Type": "application/json", "x-api-key": api_key, "anthropic-version": "2023-06-01"}
            resp = http_requests.post(url, headers=headers, json={"model": model, "max_tokens": 10, "messages": [{"role": "user", "content": "hi"}]}, timeout=15)
        elif ptype == "gemini":
            url = f"{base_url}/models/{model}:generateContent?key={api_key}"
            resp = http_requests.post(url, headers={"Content-Type": "application/json"}, json={"contents": [{"parts": [{"text": "hi"}]}]}, timeout=15)
        else:
            # Same non-streaming format as the user's snippet so any
            # OpenAI-compatible server validates cleanly.
            url = chat_completions_url(base_url)
            resp = http_requests.post(url, headers=openai_headers(api_key),
                                      json=openai_chat_payload(model, [{"role": "user", "content": "hi"}], stream=False),
                                      timeout=20)
        if resp.status_code == 200:
            try:
                data = resp.json()
                if ptype not in ("anthropic", "gemini"):
                    # Accept both OpenAI shape and simple {content}/{message} shapes
                    choices = data.get("choices") if isinstance(data, dict) else None
                    if choices is not None and not choices:
                        return {"valid": False, "error": "Empty choices", "provider": provider_key}
            except Exception:
                pass
            return {"valid": True, "provider": provider_key}
        return {"valid": False, "error": f"HTTP {resp.status_code}: {resp.text[:200]}", "provider": provider_key}
    except Exception as e:
        return {"valid": False, "error": str(e), "provider": provider_key}

def test_custom_endpoint(base_url, model, api_key=""):
    """Test an arbitrary OpenAI-compatible endpoint (user's snippet format).

    POST {BASE_URL}/chat/completions with
    {"model": ..., "messages": [...], "stream": False} and report cleanly.
    """
    if not base_url: return {"valid": False, "error": "Base URL required"}
    if not model: return {"valid": False, "error": "Model required"}
    try:
        print("Sending request to model...")
        resp = http_requests.post(chat_completions_url(base_url), headers=openai_headers(api_key),
                                  json=openai_chat_payload(model, [{"role": "user", "content": "Confirm that you are online and working!"}], stream=False),
                                  timeout=30)
        print("Inference Status:", resp.status_code)
        if resp.status_code != 200:
            return {"valid": False, "error": f"HTTP {resp.status_code}: {resp.text[:300]}"}
        try:
            content = resp.json()["choices"][0]["message"]["content"]
        except Exception:
            try:
                content = resp.json()
                content = json.dumps(content)[:500]
            except Exception:
                content = resp.text[:500]
        print("Model Response:", content)
        return {"valid": True, "response": str(content)[:1000]}
    except Exception as e:
        print("Failed to run inference:", e)
        return {"valid": False, "error": str(e)}

def test_research_keys():
    results = []
    for i, key in enumerate(config.get("gemini_research_keys", [])):
        try:
            url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={key}"
            resp = http_requests.post(url, json={"contents": [{"parts": [{"text": "hi"}]}]}, headers={"Content-Type": "application/json"}, timeout=10)
            results.append({"index": i, "valid": resp.status_code == 200, "key_preview": key[:8] + "****" + key[-4:]})
        except Exception as e:
            results.append({"index": i, "valid": False, "error": str(e), "key_preview": key[:8] + "****" + key[-4:]})
    return results

# ==================== ROUTES ====================
@app.route("/")
def index():
    return send_from_directory("static", "index.html")

@app.route("/api/settings", methods=["GET"])
def get_settings():
    safe = json.loads(json.dumps(config))
    for k in safe["providers"]:
        if "api_keys" in safe["providers"][k]:
            for key_obj in safe["providers"][k]["api_keys"]:
                ak = key_obj.get("key", "")
                if ak and len(ak) > 8: key_obj["key"] = ak[:4] + "****" + ak[-4:]
                elif ak: key_obj["key"] = "****"
    if "gemini_research_keys" in safe:
        safe["gemini_research_keys"] = [k[:8] + "****" + k[-4:] if len(k) > 12 else "****" for k in safe["gemini_research_keys"]]
    return jsonify(safe)

@app.route("/api/settings", methods=["POST"])
def update_settings():
    global config
    data = request.json
    if "providers" in data:
        for k, v in data["providers"].items():
            if k not in config["providers"]:
                # Allow the UI to create custom OpenAI-compatible providers.
                config["providers"][k] = {"name": v.get("name", k), "base_url": v.get("base_url", ""),
                                          "api_keys": v.get("api_keys", []), "model": v.get("model", ""),
                                          "enabled": v.get("enabled", True), "type": v.get("type", "openai"),
                                          "custom": True, "stream": _as_bool(v.get("stream"), True)}
            else:
                if "api_keys" in v:
                    new_keys = []
                    for key_obj in v["api_keys"]:
                        if key_obj.get("key", "").find("****") != -1:
                            for orig_key in config["providers"][k].get("api_keys", []):
                                if orig_key["name"] == key_obj["name"]:
                                    new_keys.append(orig_key); break
                        else:
                            new_keys.append(key_obj)
                    v["api_keys"] = new_keys
                if "stream" in v: v["stream"] = _as_bool(v["stream"], provider_stream_enabled(config["providers"][k]))
                config["providers"][k].update(v)
    if "active_provider" in data: config["active_provider"] = data["active_provider"]
    if "active_api_key_name" in data: config["active_api_key_name"] = data["active_api_key_name"]
    if "context_limit" in data: config["context_limit"] = data["context_limit"]
    if "gemini_research_keys" in data:
        new_keys = []
        for k in data["gemini_research_keys"]:
            if "****" in k:
                idx = data["gemini_research_keys"].index(k)
                if idx < len(config.get("gemini_research_keys", [])):
                    new_keys.append(config["gemini_research_keys"][idx])
            else:
                new_keys.append(k)
        config["gemini_research_keys"] = new_keys
    if "research_agent_provider" in data: config["research_agent_provider"] = data["research_agent_provider"]
    if "research_agent_key_index" in data: config["research_agent_key_index"] = data["research_agent_key_index"]
    if "multibot_force_research" in data: config["multibot_force_research"] = data["multibot_force_research"]
    save_config(config)
    return jsonify({"success": True})

@app.route("/api/settings/test-keys", methods=["POST"])
def test_all_keys():
    results = []
    for pk, pv in config["providers"].items():
        keys = pv.get("api_keys", [])
        if not keys and get_provider_type(pk, pv) == "openai" and pv.get("base_url"):
            # No-auth custom endpoint (Ollama / LM Studio / private gateway):
            # still report status so the UI Test button is meaningful.
            r = test_custom_endpoint(pv.get("base_url", ""), pv.get("model", ""), "")
            r["provider"] = pk
            r["key_name"] = "(no key)"
            results.append(r)
            continue
        for key_obj in keys:
            r = test_api_key(pk, key_obj["key"])
            r["key_name"] = key_obj["name"]
            results.append(r)
    return jsonify({"results": results, "research_keys": test_research_keys()})

@app.route("/api/providers", methods=["POST"])
def add_custom_provider():
    """Add (or update) a custom OpenAI-compatible provider.

    Body: {"name": "My GPU", "base_url": "https://host/v1", "model": "my-model",
           "api_key": "optional", "api_key_name": "Default", "enabled": true}
    Works with the exact format from the user's snippet:
    POST {BASE_URL}/chat/completions {"model","messages","stream": False}
    """
    global config
    data = request.json or {}
    name = (data.get("name") or "").strip()
    base_url = (data.get("base_url") or "").strip().rstrip("/")
    model = (data.get("model") or "").strip()
    if not name: return jsonify({"error": "Provider name required"}), 400
    if not base_url: return jsonify({"error": "Base URL required (e.g. https://your-host/v1)"}), 400
    if not model: return jsonify({"error": "Model name required"}), 400
    pid = (data.get("id") or "").strip() or slugify_provider_id(name)
    if pid in BUILTIN_PROVIDERS and pid not in config["providers"]:
        pid = f"custom_{pid}"
    if pid in config["providers"] and pid in BUILTIN_PROVIDERS and not config["providers"][pid].get("custom"):
        return jsonify({"error": f"'{pid}' is a built-in provider; pick a different name"}), 400
    api_key = (data.get("api_key") or "").strip()
    key_name = (data.get("api_key_name") or "Default").strip() or "Default"
    existing_keys = config["providers"].get(pid, {}).get("api_keys", []) if pid in config["providers"] else []
    if api_key and not any(k.get("name") == key_name for k in existing_keys):
        existing_keys = existing_keys + [{"name": key_name, "key": api_key}]
    # Stream = send "stream": true upstream (default). Off = one plain JSON request,
    # useful for gateways that only answer the non-streaming format. When the UI
    # omits the field, an existing provider keeps its current setting.
    existing_stream = config["providers"].get(pid, {}).get("stream", True) if pid in config["providers"] else True
    config["providers"][pid] = {
        "name": name,
        "base_url": base_url,
        "api_keys": existing_keys,
        "model": model,
        "enabled": bool(data.get("enabled", True)),
        "type": "openai",
        "custom": True,
        "stream": _as_bool(data.get("stream"), existing_stream),
    }
    if data.get("make_active"):
        config["active_provider"] = pid
    save_config(config)
    return jsonify({"success": True, "provider_id": pid, "provider": config["providers"][pid]})

@app.route("/api/providers/<provider_id>", methods=["DELETE"])
def delete_custom_provider(provider_id):
    global config
    pv = config["providers"].get(provider_id)
    if not pv: return jsonify({"error": "Not found"}), 404
    if provider_id in BUILTIN_PROVIDERS and not pv.get("custom"):
        return jsonify({"error": "Built-in providers cannot be deleted (disable them instead)"}), 400
    del config["providers"][provider_id]
    if config.get("active_provider") == provider_id:
        config["active_provider"] = "abliteration" if "abliteration" in config["providers"] else next(iter(config["providers"]), "")
    save_config(config)
    return jsonify({"success": True})

@app.route("/api/providers/test", methods=["POST"])
def test_provider_endpoint():
    """Test any OpenAI-compatible endpoint without saving it first.

    Body: {"base_url": "...", "model": "...", "api_key": "optional"}
    Uses the user's exact non-streaming snippet format.
    """
    data = request.json or {}
    if data.get("provider"):
        pv = config["providers"].get(data["provider"])
        if not pv: return jsonify({"valid": False, "error": "Provider not found"}), 404
        keys = pv.get("api_keys", [])
        key = data.get("api_key", keys[0]["key"] if keys else "")
        return jsonify(test_custom_endpoint(pv.get("base_url", ""), pv.get("model", ""), key or ""))
    return jsonify(test_custom_endpoint(data.get("base_url", ""), data.get("model", ""), data.get("api_key", "") or ""))

@app.route("/api/settings/api-key/<provider_key>/<key_name>", methods=["DELETE"])
def delete_api_key(provider_key, key_name):
    if provider_key in config["providers"]:
        config["providers"][provider_key]["api_keys"] = [k for k in config["providers"][provider_key].get("api_keys", []) if k["name"] != key_name]
        save_config(config)
        return jsonify({"success": True})
    return jsonify({"error": "Not found"}), 404

@app.route("/api/research-keys", methods=["GET"])
def get_research_keys():
    keys = config.get("gemini_research_keys", [])
    masked = [k[:8] + "****" + k[-4:] if len(k) > 12 else "****" for k in keys]
    return jsonify({"keys": masked})

@app.route("/api/research-keys", methods=["POST"])
def update_research_keys():
    data = request.json
    action = data.get("action", "")
    if action == "add":
        key = data.get("key", "").strip()
        if not key: return jsonify({"error": "Key required"}), 400
        if "gemini_research_keys" not in config: config["gemini_research_keys"] = []
        if key not in config["gemini_research_keys"]:
            config["gemini_research_keys"].append(key)
            save_config(config)
    elif action == "delete":
        idx = data.get("index", -1)
        if "gemini_research_keys" in config and 0 <= idx < len(config["gemini_research_keys"]):
            config["gemini_research_keys"].pop(idx)
            save_config(config)
    return jsonify({"success": True})

# ==================== RESEARCH ROUTES ====================
@app.route("/api/research", methods=["GET"])
def api_list_research():
    return jsonify(list_research())

@app.route("/api/research/<research_id>", methods=["GET"])
def api_get_research(research_id):
    data = load_research(research_id)
    if data: return jsonify(data)
    return jsonify({"error": "Not found"}), 404

# ==================== WEBGL DEBUGGER ROUTES ====================
@app.route("/api/webgl/data", methods=["POST"])
def webgl_receive_data():
    """Receive WebGL state data from injected pages"""
    data = request.json
    if not data:
        return jsonify({"error": "No data"}), 400
    url = data.get("url", "unknown")
    with webgl_lock:
        webgl_sessions[url] = data
    return jsonify({"success": True})

@app.route("/api/webgl/sessions", methods=["GET"])
def webgl_list_sessions_api():
    """List all connected WebGL pages"""
    with webgl_lock:
        # Clean up stale sessions (older than 30 seconds)
        now = time.time() * 1000
        stale = [url for url, data in webgl_sessions.items() if now - data.get("timestamp", 0) > 30000]
        for url in stale:
            del webgl_sessions[url]
        
        result = {}
        for url, data in webgl_sessions.items():
            result[url] = {
                "url": url,
                "title": data.get("title", ""),
                "canvas": data.get("canvas"),
                "shaders": len(data.get("shaders", [])),
                "textures": len(data.get("textures", [])),
                "errors": len(data.get("errors", [])),
                "drawCalls": len(data.get("drawCalls", [])),
                "frameCount": data.get("frameCount", 0),
            }
        return jsonify(result)

@app.route("/api/webgl/state", methods=["GET"])
def webgl_get_state_api():
    """Get full WebGL state for a specific page"""
    url = request.args.get("url", "")
    with webgl_lock:
        data = webgl_sessions.get(url)
        if data:
            return jsonify(data)
        return jsonify({"error": "Not found"}), 404

@app.route("/api/webgl/injector", methods=["GET"])
def webgl_get_injector():
    """Get the injector script"""
    return jsonify({"script": get_webgl_injector_script()})

# ==================== SESSIONS ====================
@app.route("/api/sessions", methods=["GET"])
def get_sessions():
    result = []
    for sid, s in sessions.items():
        result.append({"id": sid, "name": s.get("name", "Untitled"), "workspace": s.get("workspace", ""), "workspaces": s.get("workspaces", []), "system_prompt": s.get("system_prompt", ""),
                       "message_count": len(s.get("messages", [])), "created": s.get("created", ""),
                       "api_key_name": s.get("api_key_name", "")})
    return jsonify({"sessions": result})

@app.route("/api/sessions", methods=["POST"])
def create_session():
    data = request.json
    sid = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    # workspace: single (legacy) or workspaces: list (multi). Empty list = pure chat (no tools).
    ws_list = data.get("workspaces")
    if ws_list is None:
        single = data.get("workspace", config.get("active_workspace", ""))
        ws_list = [single] if single else []
    sessions[sid] = {"name": data.get("name", f"Chat {len(sessions)+1}"), "messages": [],
                     "workspaces": ws_list,
                     "workspace": ws_list[0] if ws_list else "",  # legacy field (active one)
                     "system_prompt": (data.get("system_prompt") or "").strip(),
                     "created": datetime.now().isoformat(), "api_key_name": data.get("api_key_name", "")}
    save_sessions(sessions)
    return jsonify({"success": True, "session_id": sid})

@app.route("/api/sessions/<sid>", methods=["GET"])
def get_session(sid):
    if sid in sessions: return jsonify(sessions[sid])
    return jsonify({"error": "Not found"}), 404

@app.route("/api/sessions/<sid>", methods=["PUT"])
def update_session(sid):
    if sid not in sessions: return jsonify({"error": "Not found"}), 404
    data = request.json
    if "name" in data: sessions[sid]["name"] = data["name"]
    if "workspace" in data:
        sessions[sid]["workspace"] = data["workspace"]
        # Keep legacy single-workspace semantics working when only "workspace" is sent
        lst = sessions[sid].get("workspaces") or []
        if data["workspace"] and data["workspace"] not in lst:
            lst.insert(0, data["workspace"])
            sessions[sid]["workspaces"] = lst
        elif not data["workspace"]:
            sessions[sid]["workspaces"] = []
    if "workspaces" in data:
        sessions[sid]["workspaces"] = data["workspaces"]
        if data["workspaces"]:
            sessions[sid]["workspace"] = data["workspaces"][0]
        else:
            sessions[sid]["workspace"] = ""
    if "system_prompt" in data: sessions[sid]["system_prompt"] = (data.get("system_prompt") or "").strip()
    if "api_key_name" in data: sessions[sid]["api_key_name"] = data["api_key_name"]
    save_sessions(sessions)
    return jsonify({"success": True})



@app.route("/api/sessions/<sid>/ops", methods=["POST"])
def session_ops(sid):
    """Apply a batch of message edits to a chat.

    ops: [{type: 'edit'|'delete'|'truncate', index: int, content: str}]
      edit     - replace the message text
      delete   - remove that one message
      truncate - revert: keep everything up to and including `index`, drop the rest

    Ops are applied highest-index-first so every index in the batch still refers
    to the message the user actually picked in the UI.
    """
    if sid not in sessions:
        return jsonify({"error": "Session not found"}), 404
    data = request.json or {}
    raw_ops = data.get("ops") or []
    msgs = sessions[sid].setdefault("messages", [])
    priority = {"edit": 0, "delete": 1, "truncate": 2}
    ops = [o for o in raw_ops if isinstance(o, dict) and isinstance(o.get("index"), int)]
    ops.sort(key=lambda o: (-o["index"], priority.get(o.get("type"), 3)))
    applied = 0
    for o in ops:
        i, t = o["index"], o.get("type")
        if not (0 <= i < len(msgs)):
            continue
        if t == "edit":
            msgs[i]["content"] = o.get("content") or ""
            # An edited turn no longer matches the tool results recorded with it,
            # so drop the stale attachment/replay data for that message.
            for k in ("tool_results", "tool_calls", "tools_used", "images", "usage"):
                msgs[i].pop(k, None)
            applied += 1
        elif t == "delete":
            msgs.pop(i)
            applied += 1
        elif t == "truncate":
            del msgs[i + 1:]
            applied += 1
    save_sessions(sessions)
    return jsonify({"success": True, "applied": applied, "message_count": len(msgs)})

@app.route("/api/sessions/<sid>/fork", methods=["POST"])
def fork_session(sid):
    """Branch this chat: copy messages up to (and including) `index` into a new session."""
    if sid not in sessions:
        return jsonify({"error": "Session not found"}), 404
    data = request.json or {}
    idx = data.get("index")
    src = sessions[sid]
    msgs = src.get("messages", [])
    if isinstance(idx, int) and 0 <= idx < len(msgs):
        kept = json.loads(json.dumps(msgs[:idx + 1]))
    else:
        kept = json.loads(json.dumps(msgs))
    new_id = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    sessions[new_id] = {
        "name": f"{src.get('name', 'Chat')} (fork)",
        "messages": kept,
        "workspaces": list(src.get("workspaces") or []),
        "workspace": src.get("workspace", ""),
        "system_prompt": src.get("system_prompt", ""),
        "created": datetime.now().isoformat(),
        "api_key_name": src.get("api_key_name", ""),
    }
    save_sessions(sessions)
    return jsonify({"success": True, "session_id": new_id, "message_count": len(kept)})

@app.route("/api/sessions/<sid>", methods=["DELETE"])
def delete_session(sid):
    if sid in sessions:
        del sessions[sid]
        save_sessions(sessions)
    return jsonify({"success": True})

# ==================== FOLDER BROWSER (pick a workspace folder) ====================
@app.route("/api/fs/browse", methods=["GET"])
def fs_browse():
    """List sub-folders of a directory so the UI can offer a real folder picker.
    With no `path`, return the starting points (home, drives, known workspaces)."""
    import string
    raw = (request.args.get("path") or "").strip().strip('"')
    if not raw:
        roots = []
        home = str(Path.home())
        if os.path.isdir(home):
            roots.append({"name": "Home - " + home, "path": home})
        if os.name == "nt":
            for letter in string.ascii_uppercase:
                drive = f"{letter}:\\"
                if os.path.exists(drive):
                    roots.append({"name": drive, "path": drive})
        else:
            roots.append({"name": "/", "path": "/"})
        for w in config.get("workspaces", []) or []:
            if os.path.isdir(w):
                roots.append({"name": str(w), "path": str(w)})
        return jsonify({"path": "", "parent": "", "roots": True, "dirs": roots})
    p = Path(raw)
    if not p.exists():
        return jsonify({"error": "Folder does not exist: " + raw}), 400
    if not p.is_dir():
        return jsonify({"error": "Not a folder: " + raw}), 400
    dirs = []
    try:
        with os.scandir(p) as it:
            entries = sorted(it, key=lambda e: e.name.lower())
        for entry in entries:
            try:
                if entry.is_dir() and not entry.name.startswith(".") and entry.name != "__pycache__":
                    dirs.append({"name": entry.name, "path": entry.path})
            except OSError:
                continue
            if len(dirs) >= 500:
                break
    except PermissionError:
        return jsonify({"error": "Permission denied: " + raw + " (try running as admin)"}), 403
    except OSError as e:
        return jsonify({"error": str(e)}), 400
    parent = str(p.parent) if str(p.parent) != str(p) else ""
    return jsonify({"path": str(p), "parent": parent, "roots": False, "dirs": dirs})

# ==================== WORKSPACES ====================
@app.route("/api/workspaces", methods=["GET"])
def get_workspaces():
    return jsonify({"workspaces": config.get("workspaces", []), "active": config.get("active_workspace", "")})

@app.route("/api/workspaces", methods=["POST"])
def add_workspace():
    path = request.json.get("path", "")
    if not path: return jsonify({"error": "Path required"}), 400
    p = Path(path)
    if not p.exists(): return jsonify({"error": "Not found"}), 400
    if not p.is_dir(): return jsonify({"error": "Not a directory"}), 400
    if path not in config["workspaces"]:
        config["workspaces"].append(path)
        save_config(config)
    return jsonify({"success": True, "workspaces": config["workspaces"]})

@app.route("/api/workspaces/activate", methods=["POST"])
def activate_workspace():
    path = request.json.get("path", "")
    if path in config["workspaces"] or path == "":
        config["active_workspace"] = path
        save_config(config)
        return jsonify({"success": True, "active": path})
    return jsonify({"error": "Not found"}), 404

@app.route("/api/workspaces/remove", methods=["POST"])
def remove_workspace():
    path = request.json.get("path", "")
    if path in config["workspaces"]:
        config["workspaces"].remove(path)
        if config["active_workspace"] == path:
            config["active_workspace"] = config["workspaces"][0] if config["workspaces"] else ""
        save_config(config)
        return jsonify({"success": True, "workspaces": config["workspaces"], "active": config["active_workspace"]})
    return jsonify({"error": "Not found"}), 404

@app.route("/api/workspaces/browse", methods=["GET"])
def browse_workspace():
    path = request.args.get("path", "")
    if not path:
        ws = config.get("active_workspace", "")
        if not ws: return jsonify({"error": "No workspace"}), 400
        path = ws
    p = Path(path)
    if not p.exists(): return jsonify({"error": "Not found"}), 404
    items = []
    try:
        for item in sorted(p.iterdir()):
            if item.name.startswith("."): continue
            info = {"name": item.name, "path": str(item), "type": "folder" if item.is_dir() else "file"}
            if item.is_file():
                try: info["size"] = item.stat().st_size
                except: info["size"] = 0
            items.append(info)
    except PermissionError:
        return jsonify({"error": "Permission denied"}), 403
    return jsonify({"path": str(p), "items": items})

# ==================== VPS / SSH (built-in) ====================
try:
    import paramiko
    _HAS_PARAMIKO = True
except ImportError:
    _HAS_PARAMIKO = False

_vps_clients = {}          # conn_id -> paramiko.SSHClient (cached, reused)
_vps_locks = {}            # conn_id -> threading.Lock (serialize ops per server)
_vps_master_lock = threading.Lock()

def _vps_connections():
    return config.setdefault("vps_connections", [])

def _vps_get_conn(conn_id):
    for c in _vps_connections():
        if c["id"] == conn_id:
            return c
    return None

def _vps_active_conn():
    return _vps_get_conn(config.get("active_vps", ""))

def _vps_lock(conn_id):
    with _vps_master_lock:
        if conn_id not in _vps_locks:
            _vps_locks[conn_id] = threading.Lock()
        return _vps_locks[conn_id]

def _vps_parse_host(raw):
    """Accept '1.2.3.4' or '1.2.3.4:2222' or 'host.example.com:2200' → (host, port)."""
    raw = (raw or "").strip()
    if ":" in raw:
        host, _, port = raw.rpartition(":")
        if host and port.isdigit() and 1 <= int(port) <= 65535:
            return host.strip(), int(port)
    return raw, None

def _vps_client(conn, timeout=20):
    """Return a cached, connected SSHClient for a connection (reconnects if dead)."""
    global _HAS_PARAMIKO
    if not _HAS_PARAMIKO:
        import subprocess as _sp
        r = _sp.run(["pip", "install", "paramiko"], capture_output=True, text=True, timeout=120)
        import importlib
        try:
            importlib.import_module("paramiko")
            _HAS_PARAMIKO = True
        except ImportError:
            raise RuntimeError("paramiko not installed and auto-install failed: " + (r.stderr or r.stdout or "")[-300:])
    client = _vps_clients.get(conn["id"])
    if client is not None:
        try:
            tr = client.get_transport()
            if tr is not None and tr.is_active():
                return client
        except Exception:
            pass
        try: client.close()
        except Exception: pass
        client = None
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    kwargs = {"hostname": conn["host"], "port": int(conn.get("port") or 22), "username": conn["username"], "timeout": timeout, "banner_timeout": timeout, "auth_timeout": timeout}
    if conn.get("key_path"):
        kwargs["key_filename"] = conn["key_path"]
    elif conn.get("password"):
        kwargs["password"] = conn["password"]
        kwargs["allow_agent"] = False
        kwargs["look_for_keys"] = False
    try:
        client.connect(**kwargs)
    except Exception as e:
        # Some servers disable the plain "password" auth method and only accept
        # keyboard-interactive — retry that way before giving up.
        if conn.get("password") and "Authentication failed" in str(e):
            try:
                tr = client.get_transport()
                if tr is not None:
                    def _ki(title, instructions, prompts):
                        return [conn["password"]] * len(prompts)
                    tr.auth_interactive(conn["username"], _ki)
                    _vps_clients[conn["id"]] = client
                    return client
            except Exception:
                pass
        try: client.close()
        except Exception: pass
        msg = str(e)
        if "timed out" in msg or "unreachable" in msg or "refused" in msg:
            msg += f" — check the IP '{conn['host']}:{conn.get('port', 22)}' is correct and SSH (port open, firewall) is reachable from this machine"
        elif "Authentication" in msg or "Permission" in msg:
            msg += " — username or password/key is wrong (try root + the VPS provider's initial password)"
        raise RuntimeError(msg)
    _vps_clients[conn["id"]] = client
    return client

def _vps_close(conn_id):
    client = _vps_clients.pop(conn_id, None)
    if client:
        try: client.close()
        except Exception: pass

def vps_run_command(conn, command, timeout=60):
    """Run a shell command on the VPS. Returns dict with stdout/stderr/exit_code."""
    timeout = min(max(int(timeout or 60), 1), 600)
    with _vps_lock(conn["id"]):
        client = _vps_client(conn)
        stdin, stdout, stderr = client.exec_command(command, timeout=timeout)
        chan = stdout.channel
        start = time.time()
        out, err = "", ""
        while True:
            while chan.recv_ready():
                out += chan.recv(65536).decode("utf-8", errors="replace")
            while chan.recv_stderr_ready():
                err += chan.recv_stderr(65536).decode("utf-8", errors="replace")
            if chan.exit_status_ready() and not chan.recv_ready() and not chan.recv_stderr_ready():
                break
            if time.time() - start > timeout:
                chan.close()
                return {"success": False, "error": f"Command timed out after {timeout}s", "stdout": out[-8000:], "stderr": err[-4000:]}
            time.sleep(0.05)
        while chan.recv_ready():
            out += chan.recv(65536).decode("utf-8", errors="replace")
        while chan.recv_stderr_ready():
            err += chan.recv_stderr(65536).decode("utf-8", errors="replace")
        code = chan.recv_exit_status()
    return {"success": code == 0, "command": command, "stdout": out[-16000:], "stderr": err[-8000:], "exit_code": code}

def _vps_sftp(conn):
    return _vps_client(conn).open_sftp()

def vps_list_dir(conn, path="."):
    with _vps_lock(conn["id"]):
        sftp = _vps_sftp(conn)
        try:
            if not path or path == ".":
                try: path = sftp.normalize(".")
                except Exception: path = "/"
            items = []
            for entry in sorted(sftp.listdir_attr(path), key=lambda e: (not (e.st_mode or 0) & 0o40000, e.filename.lower())):
                if entry.filename.startswith("."): continue
                is_dir = (entry.st_mode or 0) & 0o40000
                item = {"name": entry.filename, "type": "folder" if is_dir else "file"}
                if not is_dir: item["size"] = entry.st_size or 0
                items.append(item)
            return {"success": True, "path": path, "items": items, "count": len(items)}
        finally:
            try: sftp.close()
            except Exception: pass

def vps_read_file(conn, path, max_bytes=200_000):
    with _vps_lock(conn["id"]):
        sftp = _vps_sftp(conn)
        try:
            with sftp.open(path, "r") as f:
                data = f.read(max_bytes + 1)
            truncated = len(data) > max_bytes
            content = data[:max_bytes].decode("utf-8", errors="replace")
            st = sftp.stat(path)
            return {"success": True, "path": path, "content": content, "size": st.st_size,
                    "truncated": truncated, "lines": len(content.splitlines())}
        finally:
            try: sftp.close()
            except Exception: pass

def vps_write_file(conn, path, content):
    with _vps_lock(conn["id"]):
        sftp = _vps_sftp(conn)
        try:
            # create parent dirs via shell (sftp can't mkdir -p)
            parent = path.rsplit("/", 1)[0] if "/" in path else "."
            try:
                _vps_client(conn).exec_command(f"mkdir -p '{parent}'")
            except Exception: pass
            with sftp.open(path, "w") as f:
                f.write(content.encode("utf-8"))
            return {"success": True, "path": path, "message": f"Written ({len(content)} chars)"}
        finally:
            try: sftp.close()
            except Exception: pass

def vps_edit_file(conn, path, old_text, new_text):
    res = vps_read_file(conn, path, max_bytes=2_000_000)
    content = res.get("content", "")
    if old_text not in content:
        return {"success": False, "error": "Text not found in file"}
    new_content = content.replace(old_text, new_text, 1)
    vps_write_file(conn, path, new_content)
    return {"success": True, "path": path, "message": "Edited"}

def vps_download_file(conn, remote_path, local_path):
    with _vps_lock(conn["id"]):
        sftp = _vps_sftp(conn)
        try:
            lp = Path(local_path)
            lp.parent.mkdir(parents=True, exist_ok=True)
            sftp.get(remote_path, str(lp))
            return {"success": True, "remote": remote_path, "local": str(lp), "size": lp.stat().st_size}
        finally:
            try: sftp.close()
            except Exception: pass

def vps_upload_file(conn, local_path, remote_path):
    with _vps_lock(conn["id"]):
        sftp = _vps_sftp(conn)
        try:
            sftp.put(local_path, remote_path)
            st = sftp.stat(remote_path)
            return {"success": True, "local": local_path, "remote": remote_path, "size": st.st_size}
        finally:
            try: sftp.close()
            except Exception: pass

def _vps_sanitize_out(res):
    """Strip password from any error strings before returning to AI/UI."""
    if isinstance(res, dict):
        pw = (config.get("active_vps") and "") or ""
        for c in _vps_connections():
            if c.get("password"):
                for k in ("error", "stdout", "stderr"):
                    if res.get(k): res[k] = res[k].replace(c["password"], "***")
    return res

@app.route("/api/vps", methods=["GET"])
def vps_list():
    conns = [{k: v for k, v in c.items() if k != "password"} for c in _vps_connections()]
    for c in conns:
        c["has_password"] = bool(_vps_get_conn(c["id"]).get("password"))
    return jsonify({"connections": conns, "active": config.get("active_vps", "")})

@app.route("/api/vps", methods=["POST"])
def vps_add():
    d = request.json or {}
    host_raw = (d.get("host") or "").strip()
    username = (d.get("username") or "").strip()
    if not host_raw or not username: return jsonify({"error": "IP/host and username required"}), 400
    host, port_from_host = _vps_parse_host(host_raw)
    conn = {"id": f"vps_{datetime.now().strftime('%Y%m%d_%H%M%S')}", "name": (d.get("name") or host).strip(),
            "host": host, "port": int(d.get("port") or port_from_host or 22), "username": username,
            "password": d.get("password") or "", "key_path": (d.get("key_path") or "").strip()}
    _vps_connections().append(conn)
    if not config.get("active_vps"): config["active_vps"] = conn["id"]
    save_config(config)
    return jsonify({"success": True, "id": conn["id"]})

@app.route("/api/vps/test", methods=["POST"])
def vps_test():
    d = request.json or {}
    cid = d.get("id")
    conn = _vps_get_conn(cid) if cid else None
    if not conn:
        host_raw = (d.get("host") or "").strip()
        host, port_from_host = _vps_parse_host(host_raw)
        conn = {"id": "_test", "host": host, "port": int(d.get("port") or port_from_host or 22),
                "username": (d.get("username") or "").strip(), "password": d.get("password") or "", "key_path": (d.get("key_path") or "").strip()}
        if not conn["host"] or not conn["username"]: return jsonify({"error": "IP/host and username required"}), 400
    try:
        with _vps_lock(conn["id"]):
            client = _vps_client(conn)
            _, stdout, _ = client.exec_command("echo ok && uname -s -r", timeout=10)
            out = stdout.read().decode().strip()
        return jsonify({"success": True, "message": f"Connected ✓ {out}"})
    except Exception as e:
        _vps_close(conn["id"])
        msg = str(e)
        if conn.get("password"): msg = msg.replace(conn["password"], "***")
        return jsonify({"success": False, "error": msg}), 200

@app.route("/api/vps/activate", methods=["POST"])
def vps_activate():
    cid = request.json.get("id", "")
    if cid and not _vps_get_conn(cid): return jsonify({"error": "Not found"}), 404
    config["active_vps"] = cid
    save_config(config)
    return jsonify({"success": True, "active": cid})

@app.route("/api/vps/<cid>", methods=["DELETE"])
def vps_delete(cid):
    conns = _vps_connections()
    conn = _vps_get_conn(cid)
    if not conn: return jsonify({"error": "Not found"}), 404
    _vps_close(cid)
    conns.remove(conn)
    if config.get("active_vps") == cid:
        config["active_vps"] = conns[0]["id"] if conns else ""
    save_config(config)
    return jsonify({"success": True})

@app.route("/api/vps/browse", methods=["GET"])
def vps_browse():
    conn = _vps_active_conn()
    if not conn: return jsonify({"error": "No active VPS — add one in Settings → VPS"}), 400
    try:
        return jsonify(_vps_sanitize_out(vps_list_dir(conn, request.args.get("path", "."))))
    except Exception as e:
        _vps_close(conn["id"])
        return jsonify({"error": str(e)}), 200

@app.route("/api/vps/file", methods=["GET"])
def vps_get_file():
    conn = _vps_active_conn()
    if not conn: return jsonify({"error": "No active VPS"}), 400
    try:
        return jsonify(_vps_sanitize_out(vps_read_file(conn, request.args.get("path", ""))))
    except Exception as e:
        _vps_close(conn["id"])
        return jsonify({"error": str(e)}), 200

@app.route("/api/vps/file", methods=["POST"])
def vps_save_file():
    conn = _vps_active_conn()
    if not conn: return jsonify({"error": "No active VPS"}), 400
    d = request.json or {}
    try:
        return jsonify(_vps_sanitize_out(vps_write_file(conn, d.get("path", ""), d.get("content", ""))))
    except Exception as e:
        _vps_close(conn["id"])
        return jsonify({"error": str(e)}), 200

@app.route("/api/vps/download", methods=["GET"])
def vps_download_route():
    conn = _vps_active_conn()
    if not conn: return jsonify({"error": "No active VPS"}), 400
    remote = request.args.get("path", "")
    ws = config.get("active_workspace") or (config.get("workspaces") or ["."])[0] if config.get("workspaces") else "."
    local = str(Path(ws) / Path(remote).name)
    try:
        res = vps_download_file(conn, remote, local)
        return jsonify(res)
    except Exception as e:
        _vps_close(conn["id"])
        return jsonify({"error": str(e)}), 200

# ==================== V2 RUNTIME ====================
@app.route('/api/health', methods=['GET'])
def health():
    active=config.get('active_provider',''); p=config.get('providers',{}).get(active,{}) if active else {}
    return jsonify({'ok':True,'version':APP_VERSION,'uptime_s':round(max(0,time.time()-APP_STARTED_TS),1),'active_provider':active,'active_model':p.get('model',''),'workspaces':len(config.get('workspaces',[]) or []),'sessions':len(sessions),'mcp_servers':len(config.get('mcp_servers',[]) or []),'vps_connections':len(config.get('vps_connections',[]) or [])})

@app.route('/api/runtime', methods=['GET'])
def runtime_info():
    with chat_cancel_lock: active_requests=len(chat_cancel_events)
    return jsonify({'version':APP_VERSION,'active_chats':active_requests,'time':datetime.now().isoformat()})

@app.route('/api/chat/cancel', methods=['POST'])
def cancel_chat():
    request_id=str((request.json or {}).get('request_id') or '').strip()
    if not request_id:return jsonify({'error':'request_id required'}),400
    with chat_cancel_lock:
        ev=chat_cancel_events.get(request_id)
        if not ev:return jsonify({'success':True,'cancelled':False,'message':'Request already finished'})
        ev.set()
    return jsonify({'success':True,'cancelled':True})

# ==================== CHAT ====================
@app.route("/api/chat", methods=["POST"])
def chat():
    data = request.json
    session_id = data.get("session_id")
    message = data.get("message", "")
    provider_key = data.get("provider", config.get("active_provider", "abliteration"))
    context_limit = data.get("context_limit", config.get("context_limit", 4000))
    key_name = data.get("key_name", "")
    multibot = data.get("multibot", False)
    webgl_debugger = data.get("webgl_debugger", False)
    plan_mode = bool(data.get("plan_mode", False))
    images = data.get("images") or []  # [{data_url: "data:image/png;base64,..."}]
    request_id = str(data.get("request_id") or uuid.uuid4().hex)[:96]
    cancel_event = threading.Event()
    with chat_cancel_lock:
        chat_cancel_events[request_id] = cancel_event

    if not message and not images:
        return jsonify({"error": "Message required"}), 400

    session = sessions.get(session_id) if session_id else None
    if not session:
        sid = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        session = {"name": "Chat", "messages": [], "workspaces": [], "workspace": "", "created": datetime.now().isoformat()}
        sessions[sid] = session
        session_id = sid

    workspaces = session.get("workspaces")
    if workspaces is None:
        # Legacy session: migrate from single workspace field
        single = session.get("workspace", config.get("active_workspace", ""))
        workspaces = [single] if single else []
    workspace = workspaces[0] if workspaces else ""
    has_workspace = bool(workspaces)
    custom_system_prompt = (session.get("system_prompt") or "").strip()
    # Pure-chat mode: no workspace AND no custom prompt → no system prompt, no tools at all.
    # Plan mode / images opt the message into a system prompt even without a workspace.
    pure_chat = not has_workspace and not custom_system_prompt and not plan_mode and not images

    api_key, error, active_idx = get_api_key_with_index(provider_key, key_name or session.get("api_key_name", ""))
    if error:
        with chat_cancel_lock: chat_cancel_events.pop(request_id,None)
        def error_gen():
            yield f"data: {json.dumps({'type': 'error', 'content': error})}\n\n"
        resp=Response(error_gen(),mimetype="text/event-stream");resp.headers['Cache-Control']='no-cache, no-transform';resp.headers['X-Accel-Buffering']='no';resp.headers['X-AI-Dashboard-Version']=APP_VERSION
        return resp

    provider = config["providers"][provider_key]
    base_url = provider["base_url"].rstrip("/")
    model = provider["model"]

    def generate():
        started_at=time.perf_counter(); first_event_ms=None
        yield f"data: {json.dumps({'type':'meta','request_id':request_id,'provider':provider_key,'model':model,'version':APP_VERSION})}\n\n"
        research_instruction = ""
        if multibot or config.get("multibot_force_research", False):
            research_instruction = """
CRITICAL - WEB RESEARCH RULES:
- When asked about ANY topic needing current info, you MUST use deep_research tool IMMEDIATELY
- Never answer research questions from memory
- deep_research gives you: sub-questions, web search results, page content, synthesized report
- After deep_research completes, you get a research_id - MENTION IT to user so they can recall later
- Use view_research(id) to recall previous research if needed
- Use list_research to see all past research
- ALWAYS use tools - never just describe what to do"""

        # Plan-mode instruction placeholder (set below when plan_mode is on)
        plan_instruction = ""
        if plan_mode:
            plan_instruction = """PLAN MODE IS ON. You MUST plan in EVERY reply, before doing anything else.

STEP 0 (mandatory, every reply): start your message with a PLAN BLOCK — a fenced block
tagged `plan` containing a short todo list, and NOTHING before it:
```plan
- [ ] first step (tool you will use / expected result)
- [ ] second step
- [ ] third step
```
Rules for the plan block:
- 2 to 6 steps, one per line, each starting with "- [ ]".
- NEVER put anything before the plan block. No greeting, no analysis, no prose.
- As soon as you finish a step, re-emit the SAME plan block with that step checked
  ("- [x] first step") so the user's todo list stays up to date.
- If the plan changes, re-emit the full updated block.

Then work the plan:
- Think through risks/trade-offs briefly BEFORE each action (use your reasoning).
- Execute ONE step at a time, inspect the tool result, and compare it to what the plan
  predicted. Do not skip verification.
- If a result is unexpected or fails, STOP, re-emit an updated plan, then continue.
- Keep executing until every box is checked, then give a short final answer.
Think more, rush less — correctness over speed."""

        # Build tool usage summary from history so the AI remembers what it already did/read
        tool_summary = ""
        msg_history = session.get("messages", [])
        tool_calls_summary = []
        for msg in msg_history:
            if msg.get("role") == "assistant" and msg.get("tools_used"):
                for tu in msg["tools_used"][-10:]:
                    if isinstance(tu, dict):
                        tool_calls_summary.append(f"- {tu.get('name', 'tool')}: {tu.get('args_summary', '')} -> {tu.get('result_summary', '')}")
        if tool_calls_summary:
            tool_summary = "\n\nTools you already used earlier in this conversation (you already know their results, do not repeat them):\n" + "\n".join(tool_calls_summary[-20:])

        if pure_chat:
            # No workspace + no custom prompt = plain chat: no system message at all
            system_prompt = ""
        else:
            ws_lines = "\n".join(f"- {Path(w).name} ({w}) — path root #1" for w in workspaces)
            system_prompt = f"""You are an AI coding assistant with tools. You help with code, files, commands, and web research.

===== HOW TO CALL TOOLS (READ THIS CAREFULLY) =====
You have TWO ways to call tools:

1. NATIVE tool calls: if your runtime supports function/tool calling, use it.
   NEVER print tool-call JSON as chat text when native calls work.

2. TEXT FALLBACK (only if native calls fail): output EXACTLY ONE fenced block
   per message, with NOTHING else in the message:
```json
{{"name": "tool_name", "arguments": {{...}}}}
```
Rules for the fallback:
- ONE call per message. The system executes it and sends you the result.
- NEVER write prose like "let me run this" or "here's the JSON" — emit the block silently.
- NEVER show a tool call to the user as text. Users hate seeing raw JSON.

===== TOOL USAGE RULES =====
- ALWAYS use tools to actually DO things — never just describe what you would do.
- File paths are RELATIVE to a workspace root. Use "." for a workspace root, NEVER "".
- read_file before edit_file: you must see the exact text before replacing it.
- After finishing tool calls, give the user a clean natural-language answer.
- NEVER print raw tool-call JSON or XML tags as chat text. Call tools silently - the UI
  already shows every tool call and its output, so repeating them in prose is noise.

===== WORKSPACES =====
This chat has MULTIPLE workspaces attached. Paths starting with "wsN/" target workspace N (1-based); no prefix = primary (first) workspace.
{ws_lines}
- e.g. read_file("ws2/src/app.js") reads src/app.js in the SECOND workspace.
- Commands run in the primary workspace — use "cd wsN && ..." or --prefix/--directory flags for others.

===== TOOL REFERENCE =====
File tools (all paths relative to a workspace root):
- read_file(path)                    — read a file's contents
- write_file(path, content)          — create or overwrite a file
- edit_file(path, old_text, new_text)— replace FIRST occurrence of old_text; old_text must match the file EXACTLY (copy it from read_file output, including whitespace)
- list_files(path)                   — list a directory; path="." lists root
- delete_file(path)                  — delete a file or folder
- search_files(pattern, path)        — case-insensitive text search in files
- run_command(action, command, ...) — run shell commands AND manage long-running processes:
  * action="run" (default / background=false): BLOCKS up to `timeout` seconds (default
    120, max 600) then returns stdout, stderr and exit_code. If it overruns, it is
    stopped and you get `timed_out: true` plus whatever output it produced. Use for
    one-shot commands: installs, builds, tests, git, listing files, one-off scripts.
  * action="start" (or background=true): starts the command DETACHED in the background and
    returns immediately with a pid + log file. Use for anything that never exits: dev
    servers, watchers, `python server.py`. These keep running even if this app restarts.
    Optional `wait` (seconds, max 60) sleeps first and returns the first log lines.
  * action="log": checks on a background process — returns the last `lines` (default 40)
    of its output. Pass `wait_for="ready|listening|started"` with `wait_timeout=30` to
    SLEEP and wait until the process is actually up instead of guessing. Use this instead
    of blind waiting; the call returns as soon as the output appears.
    If the log looks empty the program is buffering its output — start Python with
    `python -u app.py` (or add `flush=True`), and Node/Python servers usually log fine.
  * action="list": every background process with pid, status, command, log file, uptime.
  * action="stop": kills one by `pid` or `name` (force-kill by default).
  * NEVER run a server/long-running process with action="run" — it will hit the timeout.
    Start it, then poll its log.
  * Examples:
    - Install deps:     run_command("npm install")
    - Run tests:        run_command("npm test", timeout=300)
    - Start dev server: run_command("npm run dev", action="start", name="dev-server")
    - Wait until ready: run_command(action="log", name="dev-server", wait_for="ready|listening", wait_timeout=30)
    - See all:          run_command(action="list")
    - Stop it:          run_command(action="stop", name="dev-server")
  * The workspace root is the project root — do NOT cd elsewhere and do NOT pass a
    subdirectory as the target of package installs. Run "npm install" at root unless
    a package.json actually exists in a subfolder (check with list_files first).

Web & research tools:
- web_search(query)                  — quick web search
- deep_research(query, depth)        — deep research with sources; depth: quick|standard|deep
- fetch_page(url)                    — read one webpage
- view_research(research_id)         — recall a saved research by ID
- list_research()                    — list all saved research
- spawn_agent(task, role)            — delegate a subtask to a mini-agent
{research_instruction}
{plan_instruction}
{tool_summary}

Always mention research_id after deep_research so user can reference it later."""
            if custom_system_prompt:
                # User's own instructions come FIRST so they aren't buried under the tool docs
                system_prompt = custom_system_prompt + "\n\n===== RUNTIME INSTRUCTIONS (from the app) =====\n" + system_prompt
            primary = workspaces[0] if workspaces else ""
            if primary:
                system_prompt += f"\n\nPrimary workspace: {Path(primary).name} ({primary})"

        # VPS tools documentation (only when an active VPS exists)
        if _vps_active_conn():
            vc = _vps_active_conn()
            system_prompt += (system_prompt and "\n\n") + f"""===== VPS / SSH SERVER ACCESS (ACTIVE) =====
The user's VPS is connected: {vc['username']}@{vc['host']}:{vc.get('port', 22)}. You control it directly with these tools:
- vps_status()                      — list VPS connections and the active one
- vps_run(command, timeout)         — run any shell command on the VPS (systemd, docker, apt, logs, git...) and get stdout/stderr/exit_code
- vps_list_files(path)              — list a directory on the VPS
- vps_read_file(path)               — read a file on the VPS
- vps_write_file(path, content)     — create/overwrite a file (parent dirs auto-created)
- vps_edit_file(path, old, new)     — find & replace in a file
- vps_download(path)                — download a VPS file into the active workspace
- vps_upload(path, remote_path)     — upload a workspace file to the VPS
Rules: vps_read_file before vps_edit_file. Confirm before destructive commands (rm -rf, drop, format).
When the user mentions "my server / my VPS", USE these tools immediately — never say you cannot access it."""

        # Image awareness so the model knows it can truly see attachments
        if images:
            system_prompt += (system_prompt and "\n\n") + """===== IMAGES ATTACHED =====
The user attached image(s) to this message. You can SEE them. Read ALL text in the images (signs, UI, code, handwriting) and report WHERE each piece of text/object is positioned (top-left, center, which panel, color, size, layout order). Be precise about positions and layout, not just content."""

        if webgl_debugger:
            system_prompt += """

WEBGL DEBUGGER MODE - ACTIVE
You have access to WebGL debugging tools. Connected WebGL pages report their state to you.

Available tools:
- webgl_list_sessions: See which WebGL pages are connected
- webgl_get_state(url): Get full GL state (vendor, renderer, shaders, textures, errors, draw calls)
- webgl_get_shaders(url, shader_index): Get shader source code (omit index for all)
- webgl_get_errors(url): Get all captured WebGL errors
- webgl_get_draw_calls(url, count): Get recent draw calls
- webgl_get_textures(url): Get texture information
- webgl_get_injector: Get the injection script for the user

When user asks about WebGL debugging:
1. First check webgl_list_sessions to see connected pages
2. Use webgl_get_state for overview, then specific tools for details
3. Analyze shaders for bugs, errors for issues, draw calls for performance
4. If no pages connected, use webgl_get_injector and tell user to paste it in DevTools console"""

        def build_context_messages():
            """Rebuild history including assistant tool_calls + paired tool results so the
            model remembers files it read, commands it ran, etc. across turns/refreshes."""
            ctx_msgs = []
            if system_prompt:
                ctx_msgs.append({"role": "system", "content": system_prompt})
            total_chars = 0
            included = []
            for msg in reversed(msg_history):
                mc = len(str(msg.get("content") or "")) + len(str(msg.get("thinking") or ""))
                if total_chars + mc <= context_limit * 4:
                    included.insert(0, msg)
                    total_chars += mc
                else:
                    break

            included_ids = set()
            for msg in included:
                if msg.get("role") == "assistant" and msg.get("tool_calls"):
                    for tc in msg["tool_calls"]:
                        try: included_ids.add(tc.get("id", ""))
                        except Exception: pass

            for msg in included:
                role = msg.get("role", "user")
                if role == "user":
                    if msg.get("images"):
                        ctx_msgs.append({"role": "user", "content": _image_user_content(msg["content"], msg["images"])})
                    else:
                        ctx_msgs.append({"role": "user", "content": msg["content"]})
                elif role == "assistant":
                    am = {"role": "assistant", "content": msg.get("content") or None}
                    if msg.get("tool_calls") and msg.get("tool_results"):
                        # Only replay tool_calls when we also saved their results (required pairing)
                        am["tool_calls"] = [{"id": tc.get("id", f"call_{i}"), "type": "function", "function": {"name": tc.get("name", ""), "arguments": tc.get("arguments", "")}} for i, tc in enumerate(msg["tool_calls"])]
                    if am["content"] is None and not am.get("tool_calls"):
                        continue
                    ctx_msgs.append(am)
                    # Replay the saved tool results right after their assistant tool_calls
                    for i, tr in enumerate(msg.get("tool_results") or []):
                        ctx_msgs.append({"role": "tool", "content": str(tr.get("content", "")), "tool_call_id": tr.get("id") or f"call_{i}"})
            return ctx_msgs

        def _parse_data_url(du):
            """'data:image/png;base64,AAAA' -> ('png', 'AAAA') or None."""
            m = re.match(r"^data:image/(\w+);base64,(.+)$", str(du or ""), re.DOTALL)
            return (m.group(1), m.group(2)) if m else None

        def _image_user_content(text, imgs):
            """Build multimodal user content: OpenAI-style parts list.
            Anthropic/Gemini stream fns convert this shape to their own format."""
            parts = []
            if text:
                parts.append({"type": "text", "text": text})
            for du in (imgs or [])[:4]:
                parsed = _parse_data_url(du)
                # len>200: skip truncated on-disk flags left after a restart
                if parsed and len(du) > 200:
                    parts.append({"type": "image_url", "image_url": {"url": du}})
            return parts if parts else text

        messages = build_context_messages()
        if images:
            img_note = message or ("What do you see in the attached image(s)? Describe all text and where it is positioned.")
            messages.append({"role": "user", "content": _image_user_content(img_note, images)})
        else:
            messages.append({"role": "user", "content": message})

        full_response = ""
        full_thinking = ""
        extra_tools_used = []  # textual-fallback calls (memory only, never sent as "tool" role)
        if pure_chat:
            # No workspace, no custom prompt → plain chat. No tools, no tool instructions.
            all_tools = []
        else:
            all_tools = list(TOOLS)
            total_keys = sum(len(p.get("api_keys", [])) for p in config["providers"].values() if p.get("enabled"))
            if total_keys > 0:
                all_tools.extend(get_agent_tools())

        # If WebGL debugger is not enabled, remove WebGL tools
        if not webgl_debugger:
            all_tools = [t for t in all_tools if not t.get("function", {}).get("name", "").startswith("webgl_")]
        # VPS tools only when an active VPS connection exists
        if not pure_chat:
            all_tools.extend(_vps_tools_for_request())

        use_stream = provider_stream_enabled(provider)

        def make_stream(key):
            meta = {}
            tool_buffer = {}
            ptype = get_provider_type(provider_key, provider)
            if ptype == "anthropic":
                gen = _stream_anthropic(key, base_url, model, messages, tool_buffer, all_tools if all_tools else None, meta)
            elif ptype == "gemini":
                gen = _stream_gemini(key, base_url, model, messages, tool_buffer, all_tools if all_tools else None, meta)
            else:
                # Providers with Stream off get a plain JSON request instead of SSE.
                gen = _stream_openai(key, base_url, model, messages, tool_buffer, all_tools if all_tools else None, meta, use_stream)
            return gen, tool_buffer, meta

        max_rounds = 10
        round_num = 0
        total_usage = {"prompt_tokens": 0, "completion_tokens": 0}
        while round_num < max_rounds:
            if cancel_event.is_set():
                yield f"data: {json.dumps({'type':'cancelled','content':'Generation stopped by user.'})}\n\n"
                break
            round_num += 1
            round_start = len(full_response)
            # ---- Key failover: try every key of THIS provider before showing an error ----
            provider_keys = provider.get("api_keys", []) or [{"name": "default", "key": api_key}]
            attempt_order = ([active_idx] + [i for i in range(len(provider_keys)) if i != active_idx]) if active_idx < len(provider_keys) else list(range(len(provider_keys)))
            tool_buffer = {}
            meta = {}
            for ki in attempt_order:
                if ki >= len(provider_keys):
                    continue
                k = provider_keys[ki]["key"]
                gen, tool_buffer, meta = make_stream(k)
                got_event = False
                err = None
                try:
                    for evline in gen:
                        if cancel_event.is_set():
                            try: gen.close()
                            except Exception: pass
                            break
                        if evline.startswith("data: "):
                            try:
                                ev = json.loads(evline[6:])
                            except Exception:
                                yield evline
                                continue
                            if ev.get("type") == "error":
                                # Hold API errors back so we can fail over to another key first
                                err = ev.get("content", "Unknown API error")
                                continue
                            if ev.get("type") == "text":
                                full_response += ev.get("content", "")
                            elif ev.get("type") == "thinking":
                                full_thinking += ev.get("content", "")
                            got_event = True
                            if first_event_ms is None:first_event_ms=round((time.perf_counter()-started_at)*1000,1)
                        yield evline
                except Exception as e:
                    err = err or str(e)
                if err and not got_event:
                    # This key failed before producing anything -> fail over to the next key of the same provider
                    remaining = attempt_order.index(ki) < len(attempt_order) - 1
                    if remaining:
                        yield f"data: {json.dumps({'type': 'retry', 'content': f'{provider_key} key #{ki+1} failed ({str(err)[:150]}). Retrying with another key of the same provider...'})}\n\n"
                        continue
                    yield f"data: {json.dumps({'type': 'error', 'content': f'{provider_key}: all {len(provider_keys)} key(s) failed. Last error: {err}'})}\n\n"
                    tool_buffer = {}
                    break
                if err:
                    # Partial response already streamed; surface the error after it
                    yield f"data: {json.dumps({'type': 'error', 'content': err})}\n\n"
                if meta.get("usage"):
                    total_usage["prompt_tokens"] += meta["usage"].get("prompt_tokens", 0)
                    total_usage["completion_tokens"] += meta["usage"].get("completion_tokens", 0)
                break

            if not tool_buffer:
                round_text = full_response[round_start:]
                # Textual fallback: model described the call in chat text instead
                # of emitting native tool_calls (common on custom/small models).
                # Execute it for real and feed results back as a user message
                # (plain roles only, so tool-less endpoints accept the history).
                text_calls = parse_textual_tool_calls(round_text)
                if text_calls:
                    yield f"data: {json.dumps({'type': 'tool_execution_start'})}\n\n"
                    messages.append({"role": "assistant", "content": round_text or None})
                    executed = []
                    for tc in text_calls:
                        if cancel_event.is_set(): break
                        targs = tc["arguments"]
                        yield f"data: {json.dumps({'type': 'tool_executing', 'name': tc['name'], 'arguments': targs})}\n\n"
                        result = execute_tool(tc["name"], targs, workspace, workspaces)
                        yield f"data: {json.dumps({'type': 'tool_result', 'name': tc['name'], 'result': result})}\n\n"
                        executed.append((tc["name"], targs, result))
                        # Memory only — NOT appended to `messages` as a "tool"
                        # role, so tool-less endpoints never see an unknown role.
                        extra_tools_used.append({"name": tc["name"],
                                                 "args_summary": summarize_tool_args(tc["name"], targs),
                                                 "result_summary": summarize_tool_result(tc["name"], result),
                                                 "tool_call_id": f"textcall_{round_num}_{len(executed)}"})
                    messages.append({"role": "user", "content": textual_tool_results_prompt(executed)})
                    yield f"data: {json.dumps({'type': 'tool_execution_end'})}\n\n"
                    continue
                # Auto-continue when the model was cut off by max_tokens instead of stopping mid-answer
                fr = (meta or {}).get("finish_reason")
                if fr == "length" and round_text.strip() and round_num < max_rounds:
                    messages.append({"role": "assistant", "content": round_text})
                    messages.append({"role": "user", "content": "Your previous reply was cut off mid-sentence by the token limit. Continue exactly where you stopped. Do NOT repeat anything you already said."})
                    yield f"data: {json.dumps({'type': 'retry', 'content': 'Response was cut off by the token limit. Continuing automatically...'})}\n\n"
                    continue
                break

            if tool_buffer:
                yield f"data: {json.dumps({'type': 'tool_execution_start'})}\n\n"
                am = {"role": "assistant", "content": full_response[round_start:] or None}
                am["tool_calls"] = [{"id": tc["id"] or f"call_{i}", "type": "function", "function": {"name": tc["name"], "arguments": tc["arguments"]}} for i, tc in sorted(tool_buffer.items())]
                messages.append(am)

                for i, tc in sorted(tool_buffer.items()):
                    if cancel_event.is_set(): break
                    try: targs = json.loads(tc["arguments"]) if tc["arguments"] else {}
                    except: targs = {}
                    yield f"data: {json.dumps({'type': 'tool_executing', 'name': tc['name'], 'arguments': targs})}\n\n"
                    result = execute_tool(tc["name"], targs, workspace, workspaces)
                    yield f"data: {json.dumps({'type': 'tool_result', 'name': tc['name'], 'result': result})}\n\n"
                    
                    # Save tool metadata for history memory
                    tool_msg = {"role": "tool", "content": json.dumps(result), "tool_call_id": tc["id"] or f"call_{i}"}
                    tool_msg["tool_name"] = tc["name"]
                    tool_msg["tool_args_summary"] = summarize_tool_args(tc["name"], targs)
                    tool_msg["tool_result_summary"] = summarize_tool_result(tc["name"], result)
                    
                    messages.append(tool_msg)

                yield f"data: {json.dumps({'type': 'tool_execution_end'})}\n\n"

        # Save to session with tool metadata so memory survives refresh/restart
        user_saved = {"role": "user", "content": message or "[image]"}
        if images:
            # Keep full data URLs in memory so FOLLOW-UP messages still see the images;
            # save_sessions() truncates them only in the on-disk copy.
            user_saved["images"] = list(images)
        session.setdefault("messages", []).append(user_saved)
        assistant_tool_calls = []
        assistant_tool_results = []
        for m in messages:
            if m.get("role") == "assistant" and m.get("tool_calls"):
                for tc in m["tool_calls"]:
                    fn = tc.get("function", {}) if isinstance(tc, dict) else {}
                    assistant_tool_calls.append({"id": tc.get("id", ""), "name": fn.get("name", ""), "arguments": fn.get("arguments", "")})
            elif m.get("role") == "tool":
                # Save a truncated copy of the actual result so it can be replayed into future context
                assistant_tool_results.append({"id": m.get("tool_call_id", ""), "content": str(m.get("content", ""))[:4000]})
        tool_info = []
        for m in messages:
            if m.get("role") == "tool" and m.get("tool_name"):
                tool_info.append({"name": m["tool_name"], "args_summary": m.get("tool_args_summary", ""), "result_summary": m.get("tool_result_summary", ""), "tool_call_id": m.get("tool_call_id", "")})
        tool_info.extend(extra_tools_used)
        if full_response or full_thinking or tool_info:
            assistant_msg = {"role": "assistant", "content": full_response, "thinking": full_thinking}
            if assistant_tool_calls:
                assistant_msg["tool_calls"] = assistant_tool_calls
            if assistant_tool_results:
                assistant_msg["tool_results"] = assistant_tool_results
            if tool_info:
                assistant_msg["tools_used"] = tool_info
            if total_usage["prompt_tokens"] or total_usage["completion_tokens"]:
                assistant_msg["usage"] = dict(total_usage)
            session["messages"].append(assistant_msg)
        save_sessions(sessions)
        done_payload={"type":"done","tokens":len(full_response)//4,"request_id":request_id,"elapsed_ms":round((time.perf_counter()-started_at)*1000,1),"time_to_first_event_ms":first_event_ms,"provider":provider_key,"model":model,"cancelled":cancel_event.is_set()}
        if total_usage["prompt_tokens"] or total_usage["completion_tokens"]: done_payload["usage"]=dict(total_usage)
        with chat_cancel_lock: chat_cancel_events.pop(request_id,None)
        yield f"data: {json.dumps(done_payload)}\n\n"

    response=Response(generate(),mimetype="text/event-stream");response.headers['Cache-Control']='no-cache, no-transform';response.headers['X-Accel-Buffering']='no';response.headers['X-AI-Dashboard-Version']=APP_VERSION;response.headers['Connection']='keep-alive'
    return response

# Params some minimal OpenAI-compatible gateways reject outright (function calling).
_TOOLS_REJECTED_RE = re.compile(r"tool_choice|function|tools?\b.{0,40}(support|recogn|allow|valid|unknown|anticip|expect)|unexpected.{0,40}tool|unrecognized.{0,40}tool", re.IGNORECASE)

def _stream_openai(api_key, base_url, model, messages, tool_buffer, all_tools=None, meta=None, stream=True):
    url = chat_completions_url(base_url)
    headers = openai_headers(api_key)
    payload = {"model": model, "messages": messages, "stream": bool(stream), "max_tokens": 8192}
    if all_tools:
        payload["tools"] = all_tools
        payload["tool_choice"] = "auto"

    def _plain_payload():
        return {k: v for k, v in payload.items() if k not in ("tools", "tool_choice")}

    if not stream:
        # Stream OFF for this provider: one plain JSON request (same shape as the
        # non-streaming snippet), emitted as a single text event so the rest of the
        # chat loop is untouched. Useful for gateways that only answer stream:false.
        try:
            resp = http_requests.post(url, headers=headers, json=payload, timeout=180)
            if resp.status_code != 200 and all_tools and _TOOLS_REJECTED_RE.search(resp.text or ""):
                resp = http_requests.post(url, headers=headers, json=_plain_payload(), timeout=180)
            if resp.status_code != 200:
                yield f"data: {json.dumps({'type': 'error', 'content': f'API Error {resp.status_code}: {resp.text[:300]}'})}\n\n"
                return
            data = resp.json()
            if not isinstance(data, dict):
                yield f"data: {json.dumps({'type': 'error', 'content': 'Unexpected response from provider: ' + str(data)[:200]})}\n\n"
                return
            if meta is not None and isinstance(data.get("usage"), dict):
                meta["usage"] = {"prompt_tokens": data["usage"].get("prompt_tokens") or 0, "completion_tokens": data["usage"].get("completion_tokens") or 0}
            choices = data.get("choices") or [{}]
            msg = (choices[0].get("message") or {}) if isinstance(choices[0], dict) else {}
            if meta is not None and isinstance(choices[0], dict): meta["finish_reason"] = choices[0].get("finish_reason")
            if msg.get("reasoning_content"):
                yield f"data: {json.dumps({'type': 'thinking', 'content': msg['reasoning_content']})}\n\n"
            if msg.get("content"):
                yield f"data: {json.dumps({'type': 'text', 'content': msg['content']})}\n\n"
            elif isinstance(data.get("content"), str) and data["content"]:
                # Bare {content: "..."} shape (some simple gateways)
                yield f"data: {json.dumps({'type': 'text', 'content': data['content']})}\n\n"
            for i, tc in enumerate(msg.get("tool_calls") or []):
                fn = tc.get("function") or {}
                tool_buffer[i] = {"name": fn.get("name", ""), "arguments": fn.get("arguments") or "", "id": tc.get("id", "")}
        except Exception as e:
            yield f"data: {json.dumps({'type': 'error', 'content': str(e)})}\n\n"
        return

    # Ask for real token usage; some OpenAI-compatible providers reject stream_options, so retry without it
    use_stream_options = True
    try:
        resp = http_requests.post(url, headers=headers, json={**payload, "stream_options": {"include_usage": True}}, stream=True, timeout=180)
        if resp.status_code != 200 and use_stream_options:
            use_stream_options = False
            resp = http_requests.post(url, headers=headers, json=payload, stream=True, timeout=180)
        if resp.status_code != 200 and all_tools and _TOOLS_REJECTED_RE.search(resp.text or ""):
            # Many minimal OpenAI-compatible servers (local / private gateways)
            # reject function-calling params — retry as plain chat. The textual
            # tool-call fallback below still lets the model use tools via text.
            resp = http_requests.post(url, headers=headers, json=_plain_payload(), stream=True, timeout=180)
        if resp.status_code != 200:
            yield f"data: {json.dumps({'type': 'error', 'content': f'API Error {resp.status_code}: {resp.text[:300]}'})}\n\n"
            return
        finish_reason = None
        for line in resp.iter_lines(decode_unicode=True):
            if not line or not line.startswith("data: "): continue
            d = line[6:]
            if d.strip() == "[DONE]": break
            try:
                chunk = json.loads(d)
                if meta is not None and isinstance(chunk.get("usage"), dict) and chunk["usage"].get("completion_tokens"):
                    meta["usage"] = {"prompt_tokens": chunk["usage"].get("prompt_tokens") or 0, "completion_tokens": chunk["usage"].get("completion_tokens") or 0}
                choices = chunk.get("choices") or [{}]
                delta = choices[0].get("delta", {}) or {}
                fr = choices[0].get("finish_reason")
                if fr: finish_reason = fr
                if delta.get("reasoning_content"):
                    yield f"data: {json.dumps({'type': 'thinking', 'content': delta['reasoning_content']})}\n\n"
                if delta.get("content"):
                    yield f"data: {json.dumps({'type': 'text', 'content': delta['content']})}\n\n"
                if "tool_calls" in delta:
                    for tc in delta["tool_calls"]:
                        idx = tc.get("index", 0)
                        if idx not in tool_buffer:
                            tool_buffer[idx] = {"name": "", "arguments": "", "id": ""}
                        fn = tc.get("function", {})
                        if "name" in fn: tool_buffer[idx]["name"] += fn["name"]
                        if "arguments" in fn: tool_buffer[idx]["arguments"] += fn["arguments"]
                        if "id" in tc: tool_buffer[idx]["id"] = tc["id"]
            except: continue
        if meta is not None: meta["finish_reason"] = finish_reason
    except Exception as e:
        yield f"data: {json.dumps({'type': 'error', 'content': str(e)})}\n\n"

def _parse_data_url(du):
    m = re.match(r"^data:image/(\w+);base64,(.+)$", str(du or ""), re.DOTALL)
    return (m.group(1), m.group(2)) if m else None

def _user_text_and_images(content):
    """Extract (text, [(mime, b64data)]) from a user content that may be a string
    or an OpenAI-style parts list with image_url entries."""
    text, imgs = "", []
    if isinstance(content, str):
        text = content
    elif isinstance(content, list):
        for p in content:
            if not isinstance(p, dict): continue
            if p.get("type") == "text": text += p.get("text", "")
            elif p.get("type") == "image_url":
                parsed = _parse_data_url((p.get("image_url") or {}).get("url", ""))
                if parsed: imgs.append(parsed)
    return text, imgs

def _stream_anthropic(api_key, base_url, model, messages, tool_buffer, all_tools=None, meta=None):
    url = f"{base_url}/messages"
    headers = {"Content-Type": "application/json", "x-api-key": api_key, "anthropic-version": "2023-06-01"}
    sys_msg, conv = "", []
    pending_tool_uses = []
    for m in messages:
        if m["role"] == "system":
            sys_msg = m["content"]
        elif m["role"] == "assistant":
            blocks = []
            if m.get("content"): blocks.append({"type": "text", "text": m["content"]})
            for tc in m.get("tool_calls") or []:
                fn = tc.get("function", {})
                try: args = json.loads(fn.get("arguments") or "{}")
                except: args = {}
                blocks.append({"type": "tool_use", "id": tc.get("id") or "call_0", "name": fn.get("name", ""), "input": args})
            conv.append({"role": "assistant", "content": blocks or [{"type": "text", "text": "(no content)"}]})
        elif m["role"] == "tool":
            pending_tool_uses.append({"type": "tool_result", "tool_use_id": m.get("tool_call_id") or "call_0", "content": str(m.get("content", ""))})
        elif m["role"] == "user":
            # Tool results must directly follow the assistant tool_use message
            if pending_tool_uses:
                conv.append({"role": "user", "content": pending_tool_uses})
                pending_tool_uses = []
            text, imgs = _user_text_and_images(m["content"])
            blocks = []
            for mime, b64 in imgs[:4]:
                blocks.append({"type": "image", "source": {"type": "base64", "media_type": mime if "/" in mime else f"image/{mime}", "data": b64}})
            if text: blocks.append({"type": "text", "text": text})
            if blocks: conv.append({"role": "user", "content": blocks})
    if pending_tool_uses:
        conv.append({"role": "user", "content": pending_tool_uses})
    payload = {"model": model, "max_tokens": 8192, "messages": conv, "stream": True}
    if sys_msg: payload["system"] = sys_msg
    if all_tools:
        payload["tools"] = [{"name": t["function"]["name"], "description": t["function"].get("description", ""), "input_schema": t["function"].get("parameters", {"type": "object", "properties": {}})} for t in all_tools]
    try:
        resp = http_requests.post(url, headers=headers, json=payload, stream=True, timeout=180)
        if resp.status_code != 200:
            yield f"data: {json.dumps({'type': 'error', 'content': f'API Error {resp.status_code}: {resp.text[:300]}'})}\n\n"; return
        finish_reason = None
        block_tools = {}
        for line in resp.iter_lines(decode_unicode=True):
            if not line or not line.startswith("data: "): continue
            try:
                ev = json.loads(line[6:])
                et = ev.get("type")
                if et == "message_start" and meta is not None:
                    u = ev.get("message", {}).get("usage", {})
                    if u.get("input_tokens"):
                        meta["usage"] = {"prompt_tokens": u.get("input_tokens", 0), "completion_tokens": 0}
                elif et == "message_delta" and meta is not None:
                    u = ev.get("usage", {})
                    if u.get("output_tokens"):
                        prev = meta.get("usage") or {}
                        meta["usage"] = {"prompt_tokens": prev.get("prompt_tokens", 0), "completion_tokens": u.get("output_tokens", 0)}
                if et == "content_block_delta":
                    delta = ev.get("delta", {})
                    if delta.get("type") == "text_delta":
                        yield f"data: {json.dumps({'type': 'text', 'content': delta['text']})}\n\n"
                    elif delta.get("type") == "thinking_delta":
                        yield f"data: {json.dumps({'type': 'thinking', 'content': delta['thinking']})}\n\n"
                elif et == "content_block_start" and ev.get("content_block", {}).get("type") == "tool_use":
                    blk = ev["content_block"]
                    block_tools[blk.get("id", "call_0")] = {"name": blk.get("name", ""), "arguments": "", "id": blk.get("id", "call_0")}
                elif et == "content_block_delta" and ev.get("delta", {}).get("type") == "input_json_delta":
                    if block_tools:
                        last_id = list(block_tools.keys())[-1]
                        block_tools[last_id]["arguments"] += ev["delta"].get("partial_json", "")
                elif et == "message_delta":
                    fr = ev.get("delta", {}).get("stop_reason")
                    if fr: finish_reason = "length" if fr == "max_tokens" else ("tool_calls" if fr == "tool_use" else fr)
            except: continue
        for i, tb in enumerate(block_tools.values()):
            tool_buffer[i] = tb
        if meta is not None: meta["finish_reason"] = finish_reason
    except Exception as e:
        yield f"data: {json.dumps({'type': 'error', 'content': str(e)})}\n\n"

def _stream_gemini(api_key, base_url, model, messages, tool_buffer, all_tools=None, meta=None):
    url = f"{base_url}/models/{model}:streamGenerateContent?alt=sse&key={api_key}"
    headers = {"Content-Type": "application/json"}
    contents, sys_instr = [], ""
    fn_name_by_id = {}
    call_counter = [0]
    for m in messages:
        if m["role"] == "system": sys_instr = m["content"]
        elif m["role"] == "assistant":
            parts = []
            if m.get("content"): parts.append({"text": m["content"]})
            for tc in m.get("tool_calls") or []:
                fn = tc.get("function", {})
                try: args = json.loads(fn.get("arguments") or "{}")
                except: args = {}
                parts.append({"functionCall": {"name": fn.get("name", ""), "args": args}})
            if parts: contents.append({"role": "model", "parts": parts})
        elif m["role"] == "tool":
            fn_resp = {"functionResponse": {"name": m.get("tool_name", "tool"), "response": {"result": str(m.get("content", ""))[:100000]}}}
            contents.append({"role": "user", "parts": [fn_resp]})
        elif m["role"] == "user":
            text, imgs = _user_text_and_images(m["content"])
            parts = [{"text": text or "(see image)"}]
            for mime, b64 in imgs[:4]:
                parts.append({"inline_data": {"mime_type": mime if "/" in mime else f"image/{mime}", "data": b64}})
            contents.append({"role": "user", "parts": parts})
    payload = {"contents": contents}
    if sys_instr: payload["system_instruction"] = {"parts": [{"text": sys_instr}]}
    if all_tools:
        payload["tools"] = [{"functionDeclarations": [{"name": t["function"]["name"], "description": t["function"].get("description", ""), "parameters": t["function"].get("parameters", {"type": "object", "properties": {}})} for t in all_tools]}]
    try:
        resp = http_requests.post(url, headers=headers, json=payload, stream=True, timeout=180)
        if resp.status_code != 200:
            yield f"data: {json.dumps({'type': 'error', 'content': f'API Error {resp.status_code}: {resp.text[:300]}'})}\n\n"; return
        finish_reason = None
        call_idx = 0
        for line in resp.iter_lines(decode_unicode=True):
            if not line or not line.startswith("data: "): continue
            try:
                chunk = json.loads(line[6:])
                if meta is not None and isinstance(chunk.get("usageMetadata"), dict):
                    um = chunk["usageMetadata"]
                    meta["usage"] = {"prompt_tokens": um.get("promptTokenCount", 0), "completion_tokens": um.get("candidatesTokenCount", 0)}
                for c in chunk.get("candidates", []):
                    fr = c.get("finishReason")
                    if fr: finish_reason = "length" if fr == "MAX_TOKENS" else ("tool_calls" if fr == "STOP" and call_idx > 0 else fr)
                    for part in c.get("content", {}).get("parts", []):
                        if part.get("thought"):
                            yield f"data: {json.dumps({'type': 'thinking', 'content': part.get('text', '')})}\n\n"
                        elif "functionCall" in part:
                            fc = part["functionCall"]
                            call_idx += 1
                            tool_buffer[call_idx - 1] = {"name": fc.get("name", ""), "arguments": json.dumps(fc.get("args", {})), "id": f"call_{call_idx}"}
                        elif "text" in part:
                            yield f"data: {json.dumps({'type': 'text', 'content': part['text']})}\n\n"
            except: continue
        if meta is not None: meta["finish_reason"] = finish_reason if call_idx == 0 else "tool_calls"
    except Exception as e:
        yield f"data: {json.dumps({'type': 'error', 'content': str(e)})}\n\n"

if __name__ == "__main__":
    print("=" * 60)
    print("  AI Dashboard Server v5")
    print(f"  Config: {CONFIG_FILE}")
    print(f"  Sessions: {SESSIONS_FILE}")
    print(f"  Research dir: {RESEARCH_DIR}")
    print(f"  Context limit: {config.get('context_limit', 4000)}")
    print(f"  Research keys: {len(config.get('gemini_research_keys', []))}")
    print(f"  Research agent: {config.get('research_agent_provider', 'gemini')}")
    print(f"  Force research: {config.get('multibot_force_research', True)}")
    total_keys = sum(len(p.get("api_keys",[])) for p in config["providers"].values())
    print(f"  Total API keys: {total_keys}")
    print("  Open http://localhost:5000")
    print("=" * 60)
    app.run(host="0.0.0.0", port=5000, debug=False)
