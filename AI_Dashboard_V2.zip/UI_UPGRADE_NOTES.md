# AI Dashboard UI Upgrade

This package keeps the existing Python/Flask backend and upgrades the frontend in `static/index.html`.

## Added / improved
- Premium dark workspace UI with glassy layered surfaces and better spacing.
- Richer top bar with live status, workspace context, token/context indicators, and provider visibility.
- Quick-action rail for Analyze, Audit, Search Code, Plan, and Command Palette.
- Expanded Tool Center for Multi-Agent and WebGL modes plus shortcuts to MCP, VPS/SSH, and AI provider settings.
- Command palette (`Ctrl+K` / `Cmd+K`) with searchable workspace, chat, connection, and utility actions.
- Improved empty-state / welcome screen.
- Cleaner chat message, code block, composer, modal, and responsive/mobile presentation.
- Preserved existing DOM IDs and backend-facing JavaScript flows so existing tools/settings continue to work.

## Run
Use the included `run.bat` on Windows, or start the existing backend with Python and open `http://localhost:5000`.
