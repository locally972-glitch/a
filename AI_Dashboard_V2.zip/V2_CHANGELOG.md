# AI Dashboard V2

This is a new V2 package, not the previous UI-only ZIP.

UI: live queued typewriter rendering, streaming cursor, live avatar/status animation, improved tool/thinking cards, composer focus effects, responsive polish.

Backend: version 2.0.0, `/api/health`, `/api/runtime`, request IDs, `/api/chat/cancel`, stream metadata, completion latency metadata, and SSE anti-buffering headers.

`run.bat` starts `server.py`; `server.py` serves `static/index.html`. `ai_dashboard_enhanced.html` is synchronized with that exact V2 frontend.
